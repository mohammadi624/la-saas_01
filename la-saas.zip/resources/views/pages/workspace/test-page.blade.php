{{-- title: Test --}}
{{-- icon: file --}}
{{-- access: all --}}

<div class="card">
    <h2>{{ $page['title'] }}</h2>
    <p class="desc">محتوای این صفحه را اینجا بنویسید. HTML و Blade کامل در دسترس است.</p>
    <p>کاربر جاری: <b>{{ auth()->user()->name }}</b> — نقش: <b>{{ $sazehCtx->role()?->title }}</b>
    @if ($sazehCtx->workspace()) — فضای کاری: <b>{{ $sazehCtx->workspace()->name }}</b> @endif</p>
</div>
