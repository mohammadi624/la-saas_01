{{-- title: خوش آمدید --}}
{{-- icon: home --}}
{{-- access: all --}}
{{-- sort: 2 --}}
@php
    $J = \Sazeh\Core\Support\Jalali::class;
    $u = auth()->user();
    $ws = $sazehCtx->workspace();
    $role = $sazehCtx->role();
    $hour = (int) now()->format('G');
    $greet = $hour < 12 ? 'صبح بخیر' : ($hour < 17 ? 'روز بخیر' : 'عصر بخیر');
    $pct = method_exists($u, 'profileCompletion') ? $u->profileCompletion() : null;
    $ownerLabel = config('sazeh.panels.workspace.owner_label', 'مالک');
@endphp

<style>
    .wl-hero{background:linear-gradient(135deg,var(--pri),#1d3a8a);color:#fff;border-radius:16px;padding:26px 28px;margin-bottom:16px;position:relative;overflow:hidden}
    .wl-hero h2{font-size:22px;margin:0 0 6px}
    .wl-hero p{margin:0;opacity:.9}
    .wl-hero .wl-date{position:absolute;left:24px;top:24px;background:rgba(255,255,255,.15);border-radius:20px;padding:3px 14px;font-size:12.5px}
    .wl-links{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px}
    .wl-link{display:flex;gap:10px;align-items:center;background:#fff;border:1px solid var(--line);border-radius:12px;padding:14px;text-decoration:none;color:var(--ink);transition:.15s}
    .wl-link:hover{border-color:var(--pri);transform:translateY(-2px)}
    .wl-link .ic{width:34px;height:34px;padding:7px;border-radius:10px;background:var(--pri2);color:var(--pri)}
    .wl-link small{display:block;color:var(--muted);font-size:12px}
    .wl-bar{height:8px;background:#eef1f6;border-radius:6px;overflow:hidden;margin:8px 0}
    .wl-bar div{height:100%;background:var(--pri)}
    @media (max-width:640px){.wl-hero .wl-date{position:static;display:inline-block;margin-bottom:10px}}
</style>

<div class="wl-hero">
    <span class="wl-date">{{ $J::format(now(), true) }}</span>
    <h2>{{ $greet }}، {{ $u->first_name ?? $u->name }} 👋</h2>
    <p>به «{{ $ws?->name ?? config('app.name') }}» خوش آمدید. شما با نقش <b>{{ $role?->title }}</b> وارد شده‌اید.</p>
</div>

<div class="grid g2">
    <div class="card">
        <h2>دسترسی سریع</h2>
        <p class="desc">فقط بخش‌هایی نمایش داده می‌شوند که نقش شما اجازه می‌دهد.</p>
        <div class="wl-links">
            @if (Route::has('profile.edit'))
                <a class="wl-link" href="{{ route('profile.edit') }}">@sazehIcon('users')<span>پروفایل من<small>اطلاعات شخصی و بانکی</small></span></a>
            @endif
            @can('members.view')
                <a class="wl-link" href="{{ route('sazeh.workspace.members') }}">@sazehIcon('list')<span>کاربران<small>کارمندان این فضا</small></span></a>
            @endcan
            <a class="wl-link" href="{{ route('sazeh.account.security') }}">@sazehIcon('lock')<span>امنیت حساب<small>تغییر رمز عبور</small></span></a>
            <a class="wl-link" href="{{ route('sazeh.workspace.dashboard') }}">@sazehIcon('grid')<span>داشبورد<small>خلاصهٔ وضعیت</small></span></a>
        </div>
    </div>

    <div class="card">
        <h2>وضعیت حساب شما</h2>
        <table>
            @if ($ws)
                <tr><td>{{ $ownerLabel }}</td><td><b>{{ $sazehCtx->isWorkspaceOwner() ? 'خود شما' : $ws->owner?->name }}</b></td></tr>
            @endif
            <tr><td>نقش</td><td>{{ $role?->title }}</td></tr>
            <tr><td>موبایل</td><td><code>{{ $u->mobile }}</code></td></tr>
            <tr><td>آخرین ورود</td><td>{{ $u->last_login_at ? $J::format($u->last_login_at) : '—' }}</td></tr>
        </table>
        @if ($pct !== null)
            <p style="margin:14px 0 0"><b>تکمیل پروفایل: {{ $J::digits($pct) }}٪</b></p>
            <div class="wl-bar"><div style="width:{{ $pct }}%"></div></div>
            @if ($pct < 100 && Route::has('profile.edit'))
                <a class="btn sm pri" href="{{ route('profile.edit') }}">تکمیل پروفایل</a>
            @endif
        @endif
    </div>
</div>
