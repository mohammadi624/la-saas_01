<?php

namespace Sazeh\Core\Tenancy;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Sazeh\Core\Models\Workspace;

/**
 * برای مدل‌های ماژول‌ها (محصول، نوبت، مطلب، …) که داده‌شان متعلق به یک فضای کاری است.
 * - هر Query خودکار به فضای جاری محدود می‌شود.
 * - workspace_id هنگام ایجاد خودکار از فضای جاری پر می‌شود و از ورودی کاربر پذیرفته نمی‌شود.
 * - Route Model Binding با رکورد فضای دیگر ← 404.
 * برای عبور عمدی از محدودیت: Model::withoutWorkspaceScope()
 */
trait BelongsToWorkspace
{
    public static function bootBelongsToWorkspace(): void
    {
        static::addGlobalScope('workspace', function (Builder $q) {
            $ctx = app(CurrentContext::class);
            if ($ctx->workspaceId()) {
                $q->where($q->getModel()->qualifyColumn('workspace_id'), $ctx->workspaceId());
            } elseif (! app()->runningInConsole()) {
                $q->whereRaw('1 = 0'); // بیرون از فضای کاری هیچ داده‌ای دیده نمی‌شود
            }
        });

        static::creating(function ($model) {
            $id = app(CurrentContext::class)->workspaceId();
            if ($id) {
                $model->workspace_id = $id;
            }
        });
    }

    public static function withoutWorkspaceScope(): Builder
    {
        return static::withoutGlobalScope('workspace');
    }

    public function workspace(): BelongsTo
    {
        return $this->belongsTo(Workspace::class);
    }
}
