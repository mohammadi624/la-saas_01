<?php

namespace Sazeh\Core\Tenancy;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Collection;
use Sazeh\Core\Access\AccessContext;
use Sazeh\Core\Billing\EntitlementService;
use Sazeh\Core\Models\Membership;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Models\Workspace;

/**
 * «کاربر الان در کدام بخش است؟» — پنل پلتفرم یا یک فضای کاری مشخص.
 * کلید بخش در Session ذخیره می‌شود و در هر درخواست با عضویت فعال اعتبارسنجی می‌شود.
 * workspace_id هرگز از ورودی کاربر پذیرفته نمی‌شود.
 */
class CurrentContext
{
    public const SESSION_KEY = 'sazeh.context';

    private ?Authenticatable $user = null;

    private ?string $key = null;

    private ?Workspace $workspace = null;

    private ?Membership $membership = null;

    private ?Role $role = null;

    public function __construct(private readonly EntitlementService $entitlements)
    {
    }

    /**
     * همهٔ بخش‌هایی که کاربر می‌تواند واردشان شود، با دلیل در صورت عدم امکان.
     *
     * @return Collection<int,array{key:string,panel:string,title:string,role:Role,workspace:?Workspace,membership:?Membership,ok:bool,why:?string}>
     */
    public function available(Authenticatable $user): Collection
    {
        $out = collect();
        if ($user->platform_role_id && ($role = Role::find($user->platform_role_id)) && $role->panel === 'platform') {
            $out->push(['key' => 'platform', 'panel' => 'platform', 'title' => config('sazeh.panels.platform.title'), 'role' => $role,
                'workspace' => null, 'membership' => null, 'ok' => true, 'why' => null]);
        }

        Membership::with(['workspace', 'role'])->where('user_id', $user->getKey())->get()
            ->filter(fn (Membership $m) => $m->workspace !== null)
            ->each(function (Membership $m) use ($out, $user) {
                $w = $m->workspace;
                [$ok, $why] = match (true) {
                    ! $m->isActive() => [false, 'عضویت شما در این بخش تعلیق شده است.'],
                    $w->status === 'suspended' && ! $w->isOwnedBy($user) => [false, 'اشتراک این فضای کاری معلق است.'],
                    default => [true, null],
                };
                $out->push(['key' => 'ws:'.$w->id, 'panel' => 'workspace', 'title' => $w->name, 'role' => $m->role,
                    'workspace' => $w, 'membership' => $m, 'ok' => $ok, 'why' => $why]);
            });

        return $out;
    }

    /** ورود به یک بخش (پس از اعتبارسنجی). false اگر مجاز نباشد. */
    public function enter(Authenticatable $user, string $key): bool
    {
        $ctx = $this->available($user)->first(fn ($c) => $c['key'] === $key && $c['ok']);
        if (! $ctx) {
            return false;
        }
        session([self::SESSION_KEY => $key]);
        $this->load($user, $ctx);

        return true;
    }

    /** بازیابی از Session و اعتبارسنجی مجدد در هر درخواست */
    public function restore(Authenticatable $user): bool
    {
        $key = session(self::SESSION_KEY);
        if (! $key) {
            return false;
        }
        $ctx = $this->available($user)->first(fn ($c) => $c['key'] === $key && $c['ok']);
        if (! $ctx) {
            session()->forget(self::SESSION_KEY);

            return false;
        }
        $this->load($user, $ctx);

        return true;
    }

    public function forget(): void
    {
        session()->forget(self::SESSION_KEY);
        $this->user = $this->workspace = $this->membership = $this->role = null;
        $this->key = null;
    }

    private function load(Authenticatable $user, array $ctx): void
    {
        $this->user = $user;
        $this->key = $ctx['key'];
        $this->workspace = $ctx['workspace'];
        $this->membership = $ctx['membership'];
        $this->role = $ctx['role']->loadMissing('permissions');
    }

    public function has(): bool
    {
        return $this->key !== null;
    }

    public function key(): ?string
    {
        return $this->key;
    }

    public function panel(): ?string
    {
        return $this->key === null ? null : ($this->workspace ? 'workspace' : 'platform');
    }

    public function user(): ?Authenticatable
    {
        return $this->user;
    }

    public function workspace(): ?Workspace
    {
        return $this->workspace;
    }

    public function workspaceId(): ?int
    {
        return $this->workspace?->id;
    }

    public function membership(): ?Membership
    {
        return $this->membership;
    }

    public function role(): ?Role
    {
        return $this->role;
    }

    public function isWorkspaceOwner(): bool
    {
        return $this->workspace?->isOwnedBy($this->user) ?? false;
    }

    public function toAccessContext(): AccessContext
    {
        $ws = $this->workspace;

        return new AccessContext(
            userActive: (bool) $this->user?->isActiveIdentity(),
            membershipActive: $this->membership ? $this->membership->isActive() : $this->key === 'platform',
            panel: $this->panel() ?? 'none',
            roleKey: $this->role?->key,
            roleGrantsAll: (bool) $this->role?->grants_all,
            permissions: $this->role ? $this->role->permissionKeys() : [],
            workspaceStatus: $ws?->status,
            isWorkspaceOwner: $this->isWorkspaceOwner(),
            entitled: $ws ? $this->entitlements->checker($ws) : null,
        );
    }
}
