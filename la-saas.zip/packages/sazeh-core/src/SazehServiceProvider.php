<?php

namespace Sazeh\Core;

use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Sazeh\Core\Access\Gatekeeper;
use Sazeh\Core\Billing\EntitlementService;
use Sazeh\Core\Console\InstallCommand;
use Sazeh\Core\Console\SyncCommand;
use Sazeh\Core\Http\Middleware\AuthorizePage;
use Sazeh\Core\Http\Middleware\AuthorizePermission;
use Sazeh\Core\Http\Middleware\EnsureContext;
use Sazeh\Core\Menu\MenuService;
use Sazeh\Core\Modules\ModuleRegistry;
use Sazeh\Core\Sms\LogSmsGateway;
use Sazeh\Core\Sms\SmsGateway;
use Sazeh\Core\Tenancy\CurrentContext;

class SazehServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__.'/../config/sazeh.php', 'sazeh');

        $this->app->singleton(ModuleRegistry::class, function ($app) {
            $registry = new ModuleRegistry;
            foreach (array_filter((array) config('sazeh.modules', [])) as $class) {
                $registry->register($app->make($class));
            }
            // صفحه‌های فایلی: resources/views/pages/{platform|workspace}/*.blade.php  (ساخت: php artisan sazeh:page)
            if (config('sazeh.file_pages.enabled', true)) {
                $registry->register(new \Sazeh\Core\Pages\PagesModule((string) config('sazeh.file_pages.path', resource_path('views/pages'))));
            }

            return $registry;
        });

        $this->app->singleton(EntitlementService::class);
        // وابسته به کاربر و درخواست: برای هر درخواست (و هر Job در Octane/Queue) نمونهٔ جدید
        $this->app->scoped(CurrentContext::class);
        $this->app->scoped(Gatekeeper::class);
        $this->app->scoped(MenuService::class);

        $this->app->bind(SmsGateway::class, function ($app) {
            $driver = config('sazeh.sms.driver', 'log');

            return $driver === 'log' ? new LogSmsGateway : $app->make($driver);
        });
    }

    public function boot(Router $router): void
    {
        $this->loadMigrationsFrom(__DIR__.'/../database/migrations');
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'sazeh');
        $this->loadViewsFrom((string) config('sazeh.file_pages.path', resource_path('views/pages')), 'pages');

        $router->aliasMiddleware('sazeh.context', EnsureContext::class);
        $router->aliasMiddleware('sazeh.page', AuthorizePage::class);
        $router->aliasMiddleware('sazeh.can', AuthorizePermission::class);
        $router->middlewareGroup('sazeh', [EnsureContext::class, AuthorizePage::class]);

        // ثبت Routeهای همهٔ ماژول‌ها (از جمله هسته)
        $moduleCommands = [];
        foreach ($this->app->make(ModuleRegistry::class)->all() as $module) {
            if ($views = $module->views()) {
                $this->loadViewsFrom($views, $module->key());
            }
            if ($migrations = $module->migrations()) {
                $this->loadMigrationsFrom($migrations);
            }
            $moduleCommands = array_merge($moduleCommands, $module->commands());
            $module->boot();
        }
        if (! $this->app->routesAreCached()) {
            foreach ($this->app->make(ModuleRegistry::class)->all() as $module) {
                if ($file = $module->routes()) {
                    Route::middleware((array) config('sazeh.route_middleware', ['web']))->group($file);
                }
            }
        }

        // استفادهٔ عادی Laravel:  @can('members.manage') یا $user->can('members.manage')
        Gate::before(function ($user, string $ability) {
            $catalog = app(ModuleRegistry::class)->permissionCatalog();
            if (! isset($catalog[$ability])) {
                return null; // Policyهای خود پروژه دست نمی‌خورند
            }
            $ctx = app(CurrentContext::class);
            if (! $ctx->has() || (int) $ctx->user()?->getKey() !== (int) $user->getKey()) {
                return false;
            }

            return app(Gatekeeper::class)->allows($ability);
        });

        // داده‌های مشترک داشبورد برای layout و همهٔ صفحه‌هایی که از آن ارث می‌برند (از جمله صفحه‌های ماژول‌ها)
        View::composer('*', fn ($view) => $view->with('sazehCtx', app(CurrentContext::class)));
        View::composer('sazeh::layouts.dashboard', function ($view) {
            $ctx = app(CurrentContext::class);
            $view->with('sazehMenu', app(MenuService::class)->tree())
                ->with('sazehContexts', $ctx->user() ? $ctx->available($ctx->user())->where('ok', true) : collect());
        });

        Blade::directive('sazehIcon', fn ($e) => "<?php echo \\Sazeh\\Core\\Support\\Icons::svg({$e}); ?>");

        if ($this->app->runningInConsole()) {
            $this->commands(array_merge([InstallCommand::class, SyncCommand::class, \Sazeh\Core\Console\MakePageCommand::class], $moduleCommands));
            $this->publishes([__DIR__.'/../config/sazeh.php' => config_path('sazeh.php')], 'sazeh-config');
            $this->publishes([__DIR__.'/../resources/views' => resource_path('views/vendor/sazeh')], 'sazeh-views');
        }
    }
}
