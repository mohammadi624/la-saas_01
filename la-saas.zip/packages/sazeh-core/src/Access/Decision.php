<?php

namespace Sazeh\Core\Access;

final class Decision
{
    public const MESSAGES = [
        'user_inactive' => 'حساب کاربری غیرفعال است.',
        'membership_inactive' => 'عضویت شما در این بخش فعال نیست.',
        'workspace_suspended' => 'اشتراک این فضای کاری معلق است.',
        'suspended_owner_only' => 'در اشتراک معلق فقط صفحات تمدید و پرداخت باز است.',
        'auth_only' => 'فقط ورود لازم است.',
        'unknown_permission' => 'مجوز ناشناخته است.',
        'wrong_panel' => 'این بخش متعلق به پنل دیگری است.',
        'read_only' => 'اشتراک در حالت فقط‌خواندنی است و این عمل مجاز نیست.',
        'not_entitled' => 'این قابلیت در پلن شما فعال نیست.',
        'grants_all' => 'نقش شما همهٔ مجوزهای این پنل را دارد.',
        'role' => 'از نقش شما.',
        'default_deny' => 'این مجوز در نقش شما تعریف نشده است.',
    ];

    public function __construct(public readonly bool $allowed, public readonly string $code)
    {
    }

    public static function allow(string $code): self
    {
        return new self(true, $code);
    }

    public static function deny(string $code): self
    {
        return new self(false, $code);
    }

    public function message(): string
    {
        return self::MESSAGES[$this->code] ?? $this->code;
    }
}
