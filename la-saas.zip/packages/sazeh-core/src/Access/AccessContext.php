<?php

namespace Sazeh\Core\Access;

/**
 * تصویر لحظه‌ای «چه کسی، در کدام پنل و فضا، با چه نقشی» — بدون وابستگی به Laravel.
 * در برنامه توسط ContextFactory از کاربر و فضای جاری ساخته می‌شود.
 */
final class AccessContext
{
    public const PANEL_PLATFORM = 'platform';
    public const PANEL_WORKSPACE = 'workspace';

    /**
     * @param  string[]  $permissions  کلید مجوزهای نقش
     * @param  (callable(string):bool)|null  $entitled  آیا قابلیت در پلن فضا هست؟ (null = اشتراک خاموش)
     */
    public function __construct(
        public readonly bool $userActive,
        public readonly bool $membershipActive,
        public readonly string $panel,
        public readonly ?string $roleKey,
        public readonly bool $roleGrantsAll,
        public readonly array $permissions,
        public readonly ?string $workspaceStatus = null,
        public readonly bool $isWorkspaceOwner = false,
        private readonly mixed $entitled = null,
    ) {
    }

    public function entitled(?string $feature): bool
    {
        if ($feature === null || $feature === '' || $this->entitled === null) {
            return true;
        }

        return (bool) ($this->entitled)($feature);
    }
}
