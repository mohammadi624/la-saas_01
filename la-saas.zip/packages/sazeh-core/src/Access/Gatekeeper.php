<?php

namespace Sazeh\Core\Access;

use Illuminate\Support\Facades\Route;
use Sazeh\Core\Modules\ModuleRegistry;
use Sazeh\Core\Tenancy\CurrentContext;

/** اتصال AccessResolver به برنامه: کاربر و فضای جاری + رجیستری ماژول‌ها */
class Gatekeeper
{
    private ?AccessResolver $resolver = null;

    public function __construct(private readonly ModuleRegistry $registry, private readonly CurrentContext $ctx)
    {
    }

    private function resolver(): AccessResolver
    {
        return $this->resolver ??= new AccessResolver(
            $this->registry->permissionCatalog(),
            (array) config('sazeh.billing.allowed_when_suspended', ['billing.view'])
        );
    }

    public function decide(?string $permission): Decision
    {
        if (! $this->ctx->has()) {
            return Decision::deny('membership_inactive');
        }

        return $this->resolver()->decide($this->ctx->toAccessContext(), $permission);
    }

    public function allows(?string $permission): bool
    {
        return $this->decide($permission)->allowed;
    }

    /** دسترسی به یک صفحهٔ ثبت‌شده (نام Route) */
    public function page(string $routeName, ?string $overridePermission = null): Decision
    {
        $page = $this->registry->page($routeName);
        if ($page === null || ! Route::has($routeName)) {
            return Decision::deny('unknown_permission');
        }
        if ($page['panel'] === 'any' && empty($page['permission'])) {
            // صفحه‌های حساب (امنیت، رمز) برای هر کاربر واردشدهٔ فعال، حتی در اشتراک معلق
            return $this->ctx->has() && $this->ctx->user()?->isActiveIdentity()
                ? Decision::allow('auth_only') : Decision::deny('user_inactive');
        }
        if ($page['panel'] !== 'any' && $page['panel'] !== $this->ctx->panel()) {
            return Decision::deny('wrong_panel');
        }
        $d = $this->decide($page['permission'] ?? null);
        if ($d->allowed && $overridePermission) {
            $d = $this->decide($overridePermission);
        }

        return $d;
    }

    /** آیا Route پارامتر اجباری دارد؟ (چنین صفحه‌ای نمی‌تواند مقصد منو یا صفحهٔ شروع باشد) */
    public static function routeNeedsParameters(string $routeName): bool
    {
        $route = Route::getRoutes()->getByName($routeName);
        if (! $route) {
            return true;
        }
        preg_match_all('/\{(\w+)(\?)?\}/', $route->uri(), $m, PREG_SET_ORDER);
        foreach ($m as $p) {
            if (empty($p[2])) {
                return true;
            }
        }

        return false;
    }
}
