<?php

namespace Sazeh\Core\Access;

/**
 * تنها نقطهٔ تصمیم دسترسی. Gate، Middleware، منو و صفحهٔ شروع همه از همین کلاس استفاده می‌کنند.
 * اولین قاعده‌ای که نتیجه بدهد، تصمیم نهایی است.
 */
final class AccessResolver
{
    /**
     * @param  array<string,array{panel:string,is_write?:bool,feature?:?string}>  $catalog  فهرست مجوزهای ثبت‌شده
     * @param  string[]  $allowedWhenSuspended  مجوزهایی که مالک در اشتراک معلق هنوز دارد
     */
    public function __construct(
        private readonly array $catalog,
        private readonly array $allowedWhenSuspended = ['billing.view'],
    ) {
    }

    public function decide(AccessContext $ctx, ?string $permission): Decision
    {
        // ۱) هویت و عضویت
        if (! $ctx->userActive) {
            return Decision::deny('user_inactive');
        }
        if (! $ctx->membershipActive) {
            return Decision::deny('membership_inactive');
        }

        // ۲) اشتراک معلق: فقط مالک و فقط مجوزهای پرداخت
        if ($ctx->panel === AccessContext::PANEL_WORKSPACE && $ctx->workspaceStatus === 'suspended') {
            if (! $ctx->isWorkspaceOwner) {
                return Decision::deny('workspace_suspended');
            }
            if ($permission === null || ! in_array($permission, $this->allowedWhenSuspended, true)) {
                return Decision::deny('suspended_owner_only');
            }
        }

        // ۳) صفحه‌ای که فقط ورود لازم دارد
        if ($permission === null || $permission === '') {
            return Decision::allow('auth_only');
        }

        $meta = $this->catalog[$permission] ?? null;
        if ($meta === null) {
            return Decision::deny('unknown_permission');
        }

        // ۴) مجوز پنل دیگر
        if (($meta['panel'] ?? null) !== $ctx->panel) {
            return Decision::deny('wrong_panel');
        }

        // ۵) فقط‌خواندنی
        if ($ctx->workspaceStatus === 'read_only' && ($meta['is_write'] ?? false)) {
            return Decision::deny('read_only');
        }

        // ۶) پلن (اگر اشتراک خاموش باشد همیشه مجاز)
        if (! $ctx->entitled($meta['feature'] ?? null)) {
            return Decision::deny('not_entitled');
        }

        // ۷) نقش
        if ($ctx->roleGrantsAll) {
            return Decision::allow('grants_all');
        }
        if (in_array($permission, $ctx->permissions, true)) {
            return Decision::allow('role');
        }

        return Decision::deny('default_deny');
    }

    public function allows(AccessContext $ctx, ?string $permission): bool
    {
        return $this->decide($ctx, $permission)->allowed;
    }
}
