<?php

namespace Sazeh\Core\Events;

use Illuminate\Contracts\Auth\Authenticatable;
use Sazeh\Core\Models\Workspace;

/** پس از ساخت هر فضای کاری (ثبت‌نام، «خریدار جدید»، نصب). ماژول‌ها می‌توانند به آن گوش دهند. */
class WorkspaceCreated
{
    public function __construct(
        public readonly Workspace $workspace,
        public readonly Authenticatable $owner,
        public readonly ?Authenticatable $actor = null,
    ) {
    }
}
