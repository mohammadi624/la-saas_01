<?php

namespace Sazeh\Core\Concerns;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Sazeh\Core\Models\Membership;
use Sazeh\Core\Models\Role;

/**
 * این Trait را به مدل User پروژه اضافه کنید:
 *   class User extends Authenticatable { use \Sazeh\Core\Concerns\HasSazehAccess; }
 *
 * نکته امنیتی: platform_role_id و status را در $fillable مدل User قرار ندهید.
 */
trait HasSazehAccess
{
    public function memberships(): HasMany
    {
        return $this->hasMany(Membership::class, 'user_id');
    }

    public function platformRole(): BelongsTo
    {
        return $this->belongsTo(Role::class, 'platform_role_id');
    }

    public function isActiveIdentity(): bool
    {
        return ($this->status ?? 'active') === 'active';
    }

    public function isPlatformMember(): bool
    {
        return $this->platform_role_id !== null;
    }
}
