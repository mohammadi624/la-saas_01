<?php

namespace Sazeh\Core\Billing;

use Sazeh\Core\Models\PlanFeature;
use Sazeh\Core\Models\Workspace;
use Sazeh\Core\Support\SeatPolicy;

/**
 * قابلیت‌ها و ظرفیت هر فضا. اگر اشتراک خاموش باشد همه‌چیز آزاد است
 * و ظرفیت کاربران از config('sazeh.seats') خوانده می‌شود.
 * هرگز بر اساس نام پلن تصمیم نگیرید؛ فقط از این سرویس بپرسید.
 */
class EntitlementService
{
    public function enabled(): bool
    {
        return (bool) config('sazeh.billing.enabled');
    }

    /** @return (callable(string):bool)|null  null یعنی محدودیتی نیست */
    public function checker(Workspace $ws): ?callable
    {
        if (! $this->enabled()) {
            return null;
        }
        $features = $this->features($ws);

        return fn (string $feature) => (bool) ($features[$feature]['enabled'] ?? false);
    }

    public function allows(Workspace $ws, string $feature): bool
    {
        $c = $this->checker($ws);

        return $c === null || $c($feature);
    }

    public function seats(Workspace $ws): SeatPolicy
    {
        if (! $this->enabled()) {
            return config('sazeh.seats.unlimited', true)
                ? SeatPolicy::unlimited()
                : SeatPolicy::of((int) config('sazeh.seats.limit', 0));
        }
        $f = $this->features($ws)['members'] ?? null;
        if (! $f || ! $f['enabled']) {
            return SeatPolicy::of(0);
        }

        return $f['is_unlimited'] ? SeatPolicy::unlimited() : SeatPolicy::of((int) $f['limit_value']);
    }

    /** تعداد صندلی مصرف‌شده: همهٔ عضویت‌ها (فعال و معلق) به‌جز مالک */
    public function seatsUsed(Workspace $ws): int
    {
        return $ws->memberships()->where('user_id', '!=', $ws->owner_id ?? 0)->count();
    }

    private function features(Workspace $ws): array
    {
        if (! $ws->plan_id) {
            return [];
        }

        return once(fn () => PlanFeature::where('plan_id', $ws->plan_id)->get()
            ->keyBy('feature')->map(fn ($f) => $f->only(['enabled', 'limit_value', 'is_unlimited']))->all());
    }
}
