<?php

namespace Sazeh\Core\Exceptions;

use RuntimeException;

/** خطای دامنه با پیام فارسی قابل نمایش و کد HTTP مناسب */
class SazehException extends RuntimeException
{
    public function __construct(string $message, public readonly int $status = 422)
    {
        parent::__construct($message);
    }

    public static function forbidden(string $m): self
    {
        return new self($m, 403);
    }

    public static function notFound(string $m = 'یافت نشد.'): self
    {
        return new self($m, 404);
    }

    public static function conflict(string $m): self
    {
        return new self($m, 409);
    }
}
