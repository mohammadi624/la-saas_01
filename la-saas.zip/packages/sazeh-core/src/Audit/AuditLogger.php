<?php

namespace Sazeh\Core\Audit;

use Illuminate\Database\Eloquent\Model;
use Sazeh\Core\Models\AuditLog;
use Sazeh\Core\Tenancy\CurrentContext;

class AuditLogger
{
    private const SENSITIVE = ['password', 'password_confirmation', 'code', 'otp', 'token', 'secret', 'card', 'iban'];

    public function __construct(private readonly CurrentContext $ctx)
    {
    }

    public function log(string $action, ?Model $subject = null, array $meta = [], ?int $actorId = null, ?int $workspaceId = null): void
    {
        foreach (array_keys($meta) as $k) {
            foreach (self::SENSITIVE as $s) {
                if (str_contains(strtolower((string) $k), $s)) {
                    $meta[$k] = '[redacted]';
                }
            }
        }
        $req = request();
        AuditLog::create([
            'workspace_id' => $workspaceId ?? $this->ctx->workspaceId(),
            'actor_id' => $actorId ?? auth()->id(),
            'action' => $action,
            'subject_type' => $subject ? $subject->getMorphClass() : null,
            'subject_id' => $subject?->getKey(),
            'meta' => $meta ?: null,
            'ip' => $req?->ip(),
            'user_agent' => mb_substr((string) $req?->userAgent(), 0, 255),
        ]);
    }
}
