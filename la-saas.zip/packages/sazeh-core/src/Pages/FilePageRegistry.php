<?php

namespace Sazeh\Core\Pages;

/**
 * کشف «صفحه‌های فایلی»: هر فایل Blade در  {pages_path}/{panel}/...  یک صفحه است.
 *   resources/views/pages/workspace/reports/sales.blade.php
 *     ← آدرس  /panel/p/reports/sales
 *     ← نام Route  sazeh.page.workspace.reports.sales
 *     ← مجوز  page.workspace.reports.sales  (در ماتریس نقش‌ها تیک می‌خورد)
 *
 * تنظیمات اختیاری در ابتدای فایل (هر کدام یک خط):
 *   {{-- title: گزارش فروش --}}
 *   {{-- icon: chart --}}
 *   {{-- access: all --}}      ← بدون مجوز؛ همهٔ نقش‌های این پنل می‌بینند
 *   {{-- sort: 30 --}}
 *
 * کلاس خالص PHP است و به Laravel وابسته نیست.
 */
final class FilePageRegistry
{
    public const PANELS = ['platform', 'workspace'];

    /** @var array<string,array>|null */
    private ?array $pages = null;

    public function __construct(private readonly string $basePath)
    {
    }

    /** @return array<string,array{panel:string,slug:string,path:string,view:string,title:string,icon:string,access:string,sort:int,file:string,route:string,permission:?string}> */
    public function all(): array
    {
        if ($this->pages !== null) {
            return $this->pages;
        }
        $this->pages = [];
        foreach (self::PANELS as $panel) {
            $dir = rtrim($this->basePath, '/\\').DIRECTORY_SEPARATOR.$panel;
            if (! is_dir($dir)) {
                continue;
            }
            $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
            $files = [];
            foreach ($it as $f) {
                if ($f->isFile() && str_ends_with($f->getFilename(), '.blade.php')) {
                    $files[] = $f->getPathname();
                }
            }
            sort($files);
            foreach ($files as $file) {
                $rel = str_replace('\\', '/', substr($file, strlen($dir) + 1));
                $path = substr($rel, 0, -strlen('.blade.php'));          // reports/sales
                if (! preg_match('#^[a-z0-9][a-z0-9-]*(/[a-z0-9][a-z0-9-]*)*$#', $path)) {
                    continue; // نام فایل نامعتبر (فقط حروف کوچک لاتین، عدد و خط تیره)
                }
                if (str_starts_with(basename($path), '_')) {
                    continue;
                }
                $slug = str_replace('/', '.', $path);                        // reports.sales
                $meta = self::readMeta($file);
                $access = ($meta['access'] ?? '') === 'all' ? 'all' : 'permission';
                $page = [
                    'panel' => $panel,
                    'slug' => $slug,
                    'path' => $path,
                    'view' => "pages::{$panel}.{$slug}",
                    'title' => $meta['title'] ?? $slug,
                    'icon' => $meta['icon'] ?? 'file',
                    'access' => $access,
                    'sort' => isset($meta['sort']) ? (int) $meta['sort'] : 60,
                    'file' => $file,
                    'route' => "sazeh.page.{$panel}.{$slug}",
                    'permission' => $access === 'all' ? null : "page.{$panel}.{$slug}",
                ];
                $this->pages[$page['route']] = $page;
            }
        }

        return $this->pages;
    }

    /** @return array<string,string> */
    public static function readMeta(string $file): array
    {
        $head = (string) file_get_contents($file, false, null, 0, 2000);
        preg_match_all('/\{\{--\s*([a-z]+)\s*:\s*(.*?)\s*--\}\}/u', $head, $m, PREG_SET_ORDER);
        $out = [];
        foreach ($m as $row) {
            $out[$row[1]] ??= $row[2];
        }

        return $out;
    }
}
