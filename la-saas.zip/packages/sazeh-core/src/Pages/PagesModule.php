<?php

namespace Sazeh\Core\Pages;

use Sazeh\Core\Modules\Module;

/** ماژول خودکار «صفحه‌های فایلی»: مجوز، صفحه، Route و آیتم منو (غیرفعال) برای هر فایل */
final class PagesModule extends Module
{
    private FilePageRegistry $registry;

    public function __construct(?string $path = null)
    {
        $path ??= function_exists('config') && function_exists('app') && app()->bound('config')
            ? (string) config('sazeh.file_pages.path', resource_path('views/pages'))
            : getcwd().'/resources/views/pages';
        $this->registry = new FilePageRegistry($path);
    }

    public function registry(): FilePageRegistry
    {
        return $this->registry;
    }

    public function key(): string
    {
        return 'pages';
    }

    public function title(): string
    {
        return 'صفحه‌ها';
    }

    public function permissions(): array
    {
        $out = [];
        foreach ($this->registry->all() as $p) {
            if ($p['permission']) {
                $out[] = ['key' => $p['permission'], 'panel' => $p['panel'], 'label' => 'صفحهٔ «'.$p['title'].'»'];
            }
        }

        return $out;
    }

    public function pages(): array
    {
        return array_values(array_map(fn ($p) => [
            'route' => $p['route'], 'panel' => $p['panel'], 'title' => $p['title'], 'permission' => $p['permission'],
        ], $this->registry->all()));
    }

    /** هر صفحهٔ جدید یک آیتم منوی غیرفعال می‌گیرد؛ مدیر از منوساز فعال/جابه‌جا/تغییر نام می‌دهد */
    public function menu(): array
    {
        return array_values(array_map(fn ($p) => [
            'key' => 'file.'.$p['panel'].'.'.$p['slug'], 'panel' => $p['panel'], 'title' => $p['title'],
            'icon' => $p['icon'], 'route' => $p['route'], 'sort' => $p['sort'], 'active' => false,
        ], $this->registry->all()));
    }

    public function routes(): ?string
    {
        return __DIR__.'/../../routes/pages.php';
    }
}
