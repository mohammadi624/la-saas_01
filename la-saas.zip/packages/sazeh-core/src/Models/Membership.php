<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Membership extends Model
{
    use SoftDeletes;

    protected $table = 'core_memberships';

    // هیچ فیلد حساسی fillable نیست؛ ایجاد فقط از Actionها با forceFill
    protected $fillable = [];

    public function workspace(): BelongsTo
    {
        return $this->belongsTo(Workspace::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(config('sazeh.user_model'));
    }

    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class);
    }

    public function inviter(): BelongsTo
    {
        return $this->belongsTo(config('sazeh.user_model'), 'invited_by');
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }
}
