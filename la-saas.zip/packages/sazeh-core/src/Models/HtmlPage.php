<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Model;

class HtmlPage extends Model
{
    protected $table = 'core_html_pages';

    protected $fillable = [];

    /** اسکریپت کوچکی که ارتفاع صفحه را به داشبورد گزارش می‌دهد (قاب خودکار هم‌اندازه شود) */
    public function srcdoc(): string
    {
        $resize = '<script>(function(){function h(){try{parent.postMessage({sazehHeight:document.documentElement.scrollHeight},"*")}catch(e){}}'
            .'addEventListener("load",h);if(window.ResizeObserver){new ResizeObserver(h).observe(document.documentElement)}setTimeout(h,300)})();</script>';
        $html = (string) $this->content;

        return stripos($html, '</body>') !== false
            ? substr_replace($html, $resize.'</body>', strripos($html, '</body>'), 7)
            : $html.$resize;
    }
}
