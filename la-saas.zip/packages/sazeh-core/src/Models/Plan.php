<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Plan extends Model
{
    protected $table = 'core_plans';

    protected $fillable = ['key', 'title', 'is_active'];

    protected $casts = ['is_active' => 'bool'];

    public function features(): HasMany
    {
        return $this->hasMany(PlanFeature::class);
    }
}
