<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    protected $table = 'core_permissions';

    protected $fillable = ['key', 'panel', 'label', 'module', 'feature', 'is_write', 'orphaned_at'];

    protected $casts = ['is_write' => 'bool', 'orphaned_at' => 'datetime'];
}
