<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Role extends Model
{
    protected $table = 'core_roles';

    protected $fillable = ['panel', 'workspace_id', 'key', 'title', 'description', 'grants_all', 'is_system', 'start_route', 'module'];

    protected $casts = ['grants_all' => 'bool', 'is_system' => 'bool'];

    protected static function booted(): void
    {
        static::saving(fn (Role $r) => $r->scope_key = $r->workspace_id ?? 0);
    }

    public function permissions(): BelongsToMany
    {
        return $this->belongsToMany(Permission::class, 'core_role_permission');
    }

    /** نقش‌های قابل استفاده در یک فضا: قالب‌های سراسری + نقش‌های اختصاصی همان فضا */
    public function scopeForWorkspace(Builder $q, ?int $workspaceId): Builder
    {
        return $q->where('panel', 'workspace')->where(fn ($w) => $w->whereNull('workspace_id')->when($workspaceId, fn ($x) => $x->orWhere('workspace_id', $workspaceId)));
    }

    public function permissionKeys(): array
    {
        return $this->relationLoaded('permissions')
            ? $this->permissions->pluck('key')->all()
            : $this->permissions()->pluck('key')->all();
    }
}
