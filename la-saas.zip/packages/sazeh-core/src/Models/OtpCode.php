<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Model;

class OtpCode extends Model
{
    public const UPDATED_AT = null;

    protected $table = 'core_otp_codes';

    protected $guarded = ['id'];

    protected $hidden = ['code_hash'];

    protected $casts = ['expires_at' => 'datetime', 'consumed_at' => 'datetime', 'created_at' => 'datetime'];
}
