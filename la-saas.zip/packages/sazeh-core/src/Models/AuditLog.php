<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AuditLog extends Model
{
    public const UPDATED_AT = null;

    protected $table = 'core_audit_logs';

    protected $guarded = ['id'];

    protected $casts = ['meta' => 'array', 'created_at' => 'datetime'];

    public function actor(): BelongsTo
    {
        return $this->belongsTo(config('sazeh.user_model'), 'actor_id');
    }
}
