<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Model;

class PlanFeature extends Model
{
    public $timestamps = false;

    protected $table = 'core_plan_features';

    protected $fillable = ['plan_id', 'feature', 'enabled', 'limit_value', 'is_unlimited'];

    protected $casts = ['enabled' => 'bool', 'is_unlimited' => 'bool', 'limit_value' => 'int'];
}
