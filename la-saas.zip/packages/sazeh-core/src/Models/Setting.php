<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $table = 'core_settings';

    protected $fillable = ['scope', 'key', 'value'];

    protected $casts = ['value' => 'array'];
}
