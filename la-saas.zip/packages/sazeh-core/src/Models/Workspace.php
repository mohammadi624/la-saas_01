<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Workspace extends Model
{
    use SoftDeletes;

    public const STATUSES = ['active' => 'فعال', 'grace' => 'مهلت پرداخت', 'read_only' => 'فقط‌خواندنی', 'suspended' => 'معلق'];

    protected $table = 'core_workspaces';

    // owner_id و status عمداً fillable نیستند (فقط از Actionها تغییر می‌کنند)
    protected $fillable = ['name', 'slug', 'settings'];

    protected $casts = ['settings' => 'array'];

    protected static function booted(): void
    {
        static::creating(fn (Workspace $w) => $w->uuid ??= (string) Str::uuid());
    }

    public function owner(): BelongsTo
    {
        return $this->belongsTo(config('sazeh.user_model'), 'owner_id');
    }

    public function plan(): BelongsTo
    {
        return $this->belongsTo(Plan::class);
    }

    public function memberships(): HasMany
    {
        return $this->hasMany(Membership::class);
    }

    public function isOwnedBy($user): bool
    {
        return $user && (int) $this->owner_id === (int) $user->getKey();
    }
}
