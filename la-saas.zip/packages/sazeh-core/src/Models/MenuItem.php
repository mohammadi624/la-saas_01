<?php

namespace Sazeh\Core\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class MenuItem extends Model
{
    use SoftDeletes;

    protected $table = 'core_menu_items';

    protected $fillable = ['panel', 'key', 'parent_id', 'title', 'icon', 'type', 'route', 'url', 'html_page_id', 'permission', 'new_tab', 'is_active', 'sort', 'module'];

    protected $casts = ['new_tab' => 'bool', 'is_active' => 'bool', 'is_system' => 'bool'];

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id')->orderBy('sort');
    }

    public function htmlPage(): BelongsTo
    {
        return $this->belongsTo(HtmlPage::class);
    }

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'core_menu_item_role');
    }
}
