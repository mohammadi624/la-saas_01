<?php

namespace Sazeh\Core\Auth;

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Sazeh\Core\Models\OtpCode;
use Sazeh\Core\Sms\SmsGateway;

/** کد یکبارمصرف: ۶ رقم تصادفی، ذخیرهٔ هش‌شده، ۱۲۰ ثانیه، ۵ تلاش، ۳ ارسال در ۱۰ دقیقه */
class OtpService
{
    public function __construct(private readonly SmsGateway $sms)
    {
    }

    /** پاسخ برای شمارهٔ موجود و ناموجود یکسان است (ضد شناسایی حساب) */
    public function request(string $mobile, bool $userExists, string $purpose = 'login'): ?string
    {
        $cfg = config('sazeh.otp');
        $key = 'sazeh-otp-send:'.$mobile.'|'.request()->ip();
        if (RateLimiter::tooManyAttempts($key, $cfg['max_sends'])) {
            return 'درخواست کد بیش از حد مجاز است؛ چند دقیقهٔ دیگر تلاش کنید.';
        }
        RateLimiter::hit($key, $cfg['send_window_seconds']);

        if (! $userExists) {
            return null;
        }

        // کدهای قبلی باطل شوند
        OtpCode::where('target', $mobile)->where('purpose', $purpose)->whereNull('consumed_at')->update(['consumed_at' => now()]);

        $len = (int) $cfg['length'];
        $code = (string) random_int(10 ** ($len - 1), (10 ** $len) - 1);
        OtpCode::create([
            'target' => $mobile, 'purpose' => $purpose, 'code_hash' => Hash::make($code),
            'expires_at' => now()->addSeconds($cfg['ttl_seconds']), 'ip' => request()->ip(),
        ]);
        $this->sms->send($mobile, "کد ورود شما: {$code}\nاین کد را در اختیار دیگران قرار ندهید.");

        return null;
    }

    public function verify(string $mobile, string $code, string $purpose = 'login'): bool
    {
        $otp = OtpCode::where('target', $mobile)->where('purpose', $purpose)->whereNull('consumed_at')->latest('id')->first();
        if (! $otp || $otp->expires_at->isPast() || $otp->attempts >= config('sazeh.otp.max_attempts')) {
            return false;
        }
        if (! Hash::check($code, $otp->code_hash)) {
            $otp->increment('attempts');

            return false;
        }
        $otp->forceFill(['consumed_at' => now()])->save();

        return true;
    }
}
