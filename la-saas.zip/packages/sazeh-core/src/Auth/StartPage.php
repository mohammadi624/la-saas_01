<?php

namespace Sazeh\Core\Auth;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Sazeh\Core\Access\Gatekeeper;
use Sazeh\Core\Menu\MenuService;
use Sazeh\Core\Menu\MenuTree;
use Sazeh\Core\Support\SafeRedirect;
use Sazeh\Core\Tenancy\CurrentContext;
use Throwable;

/** انتخاب صفحهٔ پس از ورود بر اساس نقش: intended ← صفحهٔ شروع نقش ← اولین منو ← صفحهٔ امن */
class StartPage
{
    public function __construct(
        private readonly Gatekeeper $gate,
        private readonly CurrentContext $ctx,
        private readonly MenuService $menu,
    ) {
    }

    /** @return array{url:string,route:?string,trace:array} */
    public function resolve(?string $intended = null): array
    {
        $candidates = [];

        $intendedRoute = null;
        $reason = null;
        if ($intended) {
            $path = SafeRedirect::path(parse_url($intended, PHP_URL_HOST) === request()->getHost() ? (string) parse_url($intended, PHP_URL_PATH) : $intended);
            if ($path === null) {
                $reason = 'آدرس بازگشت نامعتبر است.';
            } else {
                try {
                    $intendedRoute = Route::getRoutes()->match(Request::create($path))->getName();
                } catch (Throwable) {
                    $reason = 'به هیچ صفحهٔ ثبت‌شده‌ای نمی‌رسد.';
                }
            }
        }
        $candidates[] = ['label' => 'صفحهٔ درخواستی پیش از ورود', 'target' => $intendedRoute, 'reason' => $intended ? $reason : null];
        $candidates[] = ['label' => 'صفحهٔ شروع نقش «'.($this->ctx->role()?->title ?? '—').'»', 'target' => $this->ctx->role()?->start_route];
        $candidates[] = ['label' => 'اولین آیتم قابل‌نمایش منو', 'target' => MenuTree::firstPage($this->menu->tree())['route'] ?? null];
        $candidates[] = ['label' => 'صفحهٔ امن نهایی', 'target' => 'sazeh.account.security'];

        $res = StartPageResolver::resolve($candidates, function (string $route) {
            if (! Route::has($route)) {
                return 'Route وجود ندارد.';
            }
            if (Gatekeeper::routeNeedsParameters($route)) {
                return 'Route پارامتر لازم دارد.';
            }
            $d = $this->gate->page($route);

            return $d->allowed ? $this->menu->menuGateReason($route) : $d->message();
        });

        $route = $res['target'];

        return ['url' => $route ? route($route) : url('/'), 'route' => $route, 'trace' => $res['trace']];
    }

    /** فهرست صفحه‌های قابل انتخاب به‌عنوان صفحهٔ شروع برای یک پنل */
    public static function choices(string $panel): array
    {
        return collect(app(\Sazeh\Core\Modules\ModuleRegistry::class)->pages())
            ->filter(fn ($p) => ($p['panel'] === $panel || $p['panel'] === 'any') && Route::has($p['route']) && ! Gatekeeper::routeNeedsParameters($p['route']))
            ->mapWithKeys(fn ($p) => [$p['route'] => $p['title']])->all();
    }
}
