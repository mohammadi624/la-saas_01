<?php

namespace Sazeh\Core\Auth;

/**
 * انتخاب صفحهٔ شروع پس از ورود از میان نامزدها به ترتیب اولویت.
 * خالص است؛ بررسی دسترسی از بیرون به شکل callable داده می‌شود.
 */
final class StartPageResolver
{
    /**
     * @param  array<int,array{label:string,target:?string,reason?:?string}>  $candidates
     * @param  callable(string):?string  $denyReason  اگر هدف مجاز است null، وگرنه دلیل رد
     * @return array{target:?string,trace:array<int,array{label:string,target:?string,status:string,message:string}>}
     */
    public static function resolve(array $candidates, callable $denyReason): array
    {
        $trace = [];
        $chosen = null;
        foreach ($candidates as $c) {
            $target = $c['target'] ?? null;
            if ($chosen !== null) {
                $trace[] = ['label' => $c['label'], 'target' => $target, 'status' => 'skipped', 'message' => 'بررسی نشد'];

                continue;
            }
            if (! empty($c['reason'])) {
                $trace[] = ['label' => $c['label'], 'target' => $target, 'status' => 'rejected', 'message' => $c['reason']];

                continue;
            }
            if ($target === null || $target === '') {
                $trace[] = ['label' => $c['label'], 'target' => null, 'status' => 'empty', 'message' => 'تنظیم نشده'];

                continue;
            }
            $why = $denyReason($target);
            if ($why === null) {
                $chosen = $target;
                $trace[] = ['label' => $c['label'], 'target' => $target, 'status' => 'chosen', 'message' => 'انتخاب شد'];
            } else {
                $trace[] = ['label' => $c['label'], 'target' => $target, 'status' => 'rejected', 'message' => $why];
            }
        }

        return ['target' => $chosen, 'trace' => $trace];
    }
}
