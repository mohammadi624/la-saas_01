<?php

namespace Sazeh\Core\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Sazeh\Core\Tenancy\CurrentContext;
use Symfony\Component\HttpFoundation\Response;

/**
 * در هر درخواست: کاربر وارد شده؟ هویت فعال است؟ بخش جاری (پنل/فضا) هنوز معتبر است؟
 * اگر هویت غیرفعال شده باشد، خروج اجباری. اگر بخش معتبر نیست، به انتخاب بخش.
 */
class EnsureContext
{
    public function __construct(private readonly CurrentContext $ctx)
    {
    }

    public function handle(Request $request, Closure $next): Response
    {
        $user = Auth::user();
        if (! $user) {
            return redirect()->guest(route('sazeh.login'));
        }
        if (! $user->isActiveIdentity()) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('sazeh.login')->withErrors(['identifier' => 'حساب شما غیرفعال شده است.']);
        }
        if (! $this->ctx->restore($user)) {
            $ok = $this->ctx->available($user)->where('ok', true);
            if ($ok->count() === 1 && $this->ctx->enter($user, $ok->first()['key'])) {
                return $next($request);
            }

            return redirect()->route('sazeh.context.pick');
        }

        return $next($request);
    }
}
