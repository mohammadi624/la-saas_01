<?php

namespace Sazeh\Core\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Sazeh\Core\Access\Gatekeeper;
use Symfony\Component\HttpFoundation\Response;

/** برای Routeهای عملیات (POST/PUT/DELETE):  ->middleware('sazeh.can:members.manage') */
class AuthorizePermission
{
    public function __construct(private readonly Gatekeeper $gate)
    {
    }

    public function handle(Request $request, Closure $next, string $permission): Response
    {
        $d = $this->gate->decide($permission);
        if (! $d->allowed) {
            abort(403, $d->message());
        }

        return $next($request);
    }
}
