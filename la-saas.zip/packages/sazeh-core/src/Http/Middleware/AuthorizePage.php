<?php

namespace Sazeh\Core\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Sazeh\Core\Access\Gatekeeper;
use Sazeh\Core\Menu\MenuService;
use Symfony\Component\HttpFoundation\Response;

/**
 * برای Routeهای صفحه (GET): نام Route باید در رجیستری ماژول ثبت شده باشد و کاربر به آن دسترسی داشته باشد.
 * مخفی بودن منو هرگز جایگزین این بررسی نیست.
 * صفحه‌های فایلی علاوه بر مجوز، آیتم منوی فعال هم لازم دارند (sazeh.file_pages.require_menu).
 */
class AuthorizePage
{
    public function __construct(private readonly Gatekeeper $gate, private readonly MenuService $menu)
    {
    }

    public function handle(Request $request, Closure $next): Response
    {
        $name = $request->route()?->getName();
        $d = $name ? $this->gate->page($name) : null;
        if (! $d || ! $d->allowed) {
            abort(403, $d?->message() ?? 'این صفحه ثبت نشده است.');
        }
        if ($why = $this->menu->menuGateReason($name)) {
            abort(403, $why);
        }

        return $next($request);
    }
}
