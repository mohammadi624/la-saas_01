<?php

namespace Sazeh\Core\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Auth\StartPage;
use Sazeh\Core\Tenancy\CurrentContext;

/** انتخاب و تعویض بخش (پنل پلتفرم یا یک فضای کاری) */
class ContextController extends Controller
{
    public function __construct(private readonly CurrentContext $ctx)
    {
    }

    public function pick(Request $request): View
    {
        return view('sazeh::auth.pick', ['contexts' => $this->ctx->available($request->user())]);
    }

    public function select(Request $request, AuditLogger $audit): RedirectResponse
    {
        $request->validate(['context' => 'required|string|max:40']);
        if (! $this->ctx->enter($request->user(), $request->input('context'))) {
            return back()->withErrors(['context' => 'ورود به این بخش ممکن نیست.']);
        }
        $request->session()->regenerate();
        $audit->log('context.entered', null, ['context' => $request->input('context')]);

        return redirect()->to(app(StartPage::class)->resolve(session()->pull('url.intended'))['url']);
    }

    public function home(): RedirectResponse
    {
        return redirect()->to(app(StartPage::class)->resolve()['url']);
    }
}
