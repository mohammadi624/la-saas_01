<?php

namespace Sazeh\Core\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;
use Sazeh\Core\Modules\ModuleRegistry;

/** نمایش صفحهٔ فایلی داخل قالب داشبورد (دسترسی قبلاً توسط middleware 'sazeh' بررسی شده) */
class FilePageController extends Controller
{
    public function show(Request $request, ModuleRegistry $modules): View
    {
        $page = $modules->all()['pages']->registry()->all()[$request->route()->getName()] ?? abort(404);

        return view('sazeh::file-page', ['page' => $page]);
    }
}
