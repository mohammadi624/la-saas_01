<?php

namespace Sazeh\Core\Http\Controllers;

use Closure;
use Illuminate\Http\RedirectResponse;
use Illuminate\Routing\Controller as Base;
use Sazeh\Core\Exceptions\SazehException;

abstract class Controller extends Base
{
    /** اجرای Action و تبدیل خطای دامنه به پیام فارسی در فرم */
    protected function attempt(Closure $action, string $success, string $errorKey = 'form'): RedirectResponse
    {
        try {
            $result = $action();
        } catch (SazehException $e) {
            if ($e->status === 404) {
                abort(404);
            }

            return back()->withInput(request()->except(['password', 'password_confirmation', 'code']))->withErrors([$errorKey => $e->getMessage()]);
        }

        if (is_string($result)) {
            $success = $result; // Action می‌تواند پیام موفقیت دقیق‌تری برگرداند
        }

        return $result instanceof RedirectResponse ? $result->with('success', $success) : back()->with('success', $success);
    }
}
