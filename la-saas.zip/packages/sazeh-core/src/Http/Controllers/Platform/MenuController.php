<?php

namespace Sazeh\Core\Http\Controllers\Platform;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Validation\Rule;
use Illuminate\View\View;
use Sazeh\Core\Access\Gatekeeper;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Exceptions\SazehException;
use Sazeh\Core\Http\Controllers\Controller;
use Sazeh\Core\Menu\MenuAccess;
use Sazeh\Core\Menu\MenuService;
use Sazeh\Core\Menu\MenuTree;
use Sazeh\Core\Models\HtmlPage;
use Sazeh\Core\Models\MenuItem;
use Sazeh\Core\Models\Permission;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Modules\ModuleRegistry;
use Sazeh\Core\Modules\ModuleSynchronizer;

/**
 * منوساز: دو مجموعه‌منو (platform و workspace) در یک داشبورد.
 * انتخاب صفحه + تیک نقش‌ها = دسترسی (مجوز صفحه به نقش‌ها داده/گرفته می‌شود).
 */
class MenuController extends Controller
{
    public function __construct(
        private readonly AuditLogger $audit,
        private readonly ModuleRegistry $registry,
        private readonly ModuleSynchronizer $sync,
        private readonly Gatekeeper $gate,
    ) {
    }

    private function panel(Request $r): string
    {
        return in_array($r->query('panel', $r->input('panel')), ['platform', 'workspace'], true) ? $r->query('panel', $r->input('panel')) : 'platform';
    }

    public function index(Request $request): View
    {
        $panel = $this->panel($request);

        // کشف خودکار صفحه‌های فایلی جدید (بدون sazeh:sync)
        if ($found = $this->sync->discoverPages()) {
            session()->now('info', "{$found} صفحهٔ جدید پیدا شد و غیرفعال به منو اضافه شد؛ نقش‌ها را تیک بزنید و فعالش کنید.");
        }

        $items = MenuItem::with(['roles:id', 'htmlPage:id,original_name,size'])->where('panel', $panel)->orderBy('sort')->get();
        $pages = $this->linkablePages($panel);
        $roles = Role::with('permissions:id,key')->where('panel', $panel)->whereNull('workspace_id')->orderBy('id')->get();
        $rolePerms = $roles->mapWithKeys(fn (Role $r) => [$r->id => $r->grants_all ? true : $r->permissions->pluck('key')->all()])->all();

        $meta = [];
        foreach ($items as $m) {
            $page = $m->type === 'page' && $m->route ? $this->registry->page($m->route) : null;
            $needed = array_filter([$page['permission'] ?? null, $m->permission]);
            $meta[$m->id] = [
                'page' => $page,
                'badges' => MenuAccess::badges([
                    'type' => $m->type, 'is_active' => $m->is_active, 'route' => $m->route, 'module' => $m->module,
                    'html_page_id' => $m->html_page_id,
                    'created_at' => (string) $m->created_at, 'updated_at' => (string) $m->updated_at,
                ], $m->route ? Route::has($m->route) : false),
                'audience' => $m->type === 'group' ? null
                    : (($m->type === 'page' && (! $page || ! Route::has((string) $m->route))) ? [] : MenuAccess::audience($rolePerms, $needed, $m->roles->pluck('id')->all())),
            ];
        }

        $flat = $items->map(fn ($m) => $m->only(['id', 'parent_id', 'type', 'is_active', 'sort']) + ['model' => $m])->all();
        $linked = $items->where('type', 'page')->pluck('route')->filter()->all();
        $modules = collect($this->registry->all())->map(fn ($m) => $m->title())->all();

        return view('sazeh::platform.menus', [
            'panel' => $panel,
            'tree' => MenuTree::nest($flat),
            'meta' => $meta,
            'selected' => $request->integer('item') ? $items->firstWhere('id', $request->integer('item')) : null,
            'trashed' => MenuItem::onlyTrashed()->where('panel', $panel)->latest('deleted_at')->get(),
            'pages' => $pages,
            'pagesByModule' => $pages->groupBy('module'),
            'unlinked' => $pages->reject(fn ($p) => in_array($p['route'], $linked, true))->sortBy(fn ($p) => $p['module'] === 'pages' ? 0 : 1),
            'modules' => $modules,
            'roles' => $roles,
            'rolePerms' => $rolePerms,
            'permissions' => collect($this->registry->permissionCatalog())->where('panel', $panel),
            'canGrant' => $this->gate->allows('roles.manage'),
            'stats' => [
                'total' => $items->count(),
                'active' => $items->where('is_active', true)->count(),
                'new' => collect($meta)->filter(fn ($x) => in_array('new', $x['badges'], true))->count(),
                'broken' => collect($meta)->filter(fn ($x) => array_intersect(['missing', 'no_target'], $x['badges']))->count(),
            ],
        ]);
    }

    /** صفحه‌هایی که می‌توانند مقصد منوی این پنل باشند */
    private function linkablePages(string $panel)
    {
        return collect($this->registry->pages())
            ->filter(fn ($p) => ($p['panel'] === $panel || $p['panel'] === 'any') && Route::has($p['route']) && ! Gatekeeper::routeNeedsParameters($p['route']))
            ->map(fn ($p) => $p + ['url' => route($p['route'], [], false)]);
    }

    public function store(Request $request): RedirectResponse
    {
        $panel = $this->panel($request);
        $type = $request->input('type') === 'group' ? 'group' : 'page';
        $route = $type === 'page' ? (string) $request->input('route', '') : '';
        $page = $route !== '' ? $this->linkablePages($panel)->get($route) : null;
        if ($route !== '' && ! $page) {
            return back()->withErrors(['form' => 'این صفحه در این پنل قابل افزودن نیست.']);
        }

        $item = new MenuItem;
        $item->forceFill([
            'panel' => $panel,
            'title' => $page['title'] ?? ($type === 'group' ? 'گروه جدید' : 'آیتم جدید'),
            'icon' => $type === 'group' ? 'folder' : 'file',
            'type' => $type, 'route' => $page['route'] ?? null, 'is_active' => false,
            'sort' => (int) MenuItem::where('panel', $panel)->whereNull('parent_id')->max('sort') + 1,
        ])->save();
        $this->audit->log('menu.created', $item);
        MenuService::bump();

        return redirect()->route('sazeh.platform.menus', ['panel' => $panel, 'item' => $item->id])
            ->with('success', $page ? 'صفحه به منو اضافه شد (غیرفعال). نقش‌ها را تیک بزنید و فعالش کنید.' : 'آیتم ساخته شد (غیرفعال). مقصد را انتخاب و فعالش کنید.');
    }

    public function update(Request $request, MenuItem $item): RedirectResponse
    {
        $data = $request->validate([
            'title' => 'required|string|max:80',
            'icon' => ['required', Rule::in(config('sazeh.menu_icons'))],
            'type' => ['required', Rule::in(['page', 'group', 'external', 'html'])],
            'html_file' => ['nullable', 'file', 'max:2048', 'mimetypes:text/html,text/plain,application/xhtml+xml'],
            'route' => 'nullable|string|max:150',
            'url' => 'nullable|string|max:500',
            'permission' => 'nullable|string|max:100',
            'is_active' => 'nullable|boolean',
            'access' => 'nullable|array',
            'access.*' => 'integer',
            'access_present' => 'nullable|boolean',
        ]);

        $upload = $request->file('html_file');
        if ($upload && ! in_array(strtolower($upload->getClientOriginalExtension()), ['html', 'htm'], true)) {
            return back()->withErrors(['form' => 'فقط فایل با پسوند .html یا .htm پذیرفته می‌شود.']);
        }

        return $this->attempt(function () use ($item, $data, $upload, $request) {
            $note = '';
            if ($item->is_system) {
                // آیتم سیستمی: فقط عنوان و آیکون قابل تغییر است تا کسی خودش را قفل نکند
                $item->forceFill(['title' => $data['title'], 'icon' => $data['icon']])->save();
            } else {
                $type = $data['type'];
                if ($type !== 'group' && $item->children()->exists()) {
                    throw new SazehException('این گروه زیرمنو دارد؛ ابتدا زیرمنوها را جابه‌جا کنید.');
                }
                if ($type === 'page') {
                    $page = $this->registry->page((string) $data['route']);
                    if (! $page || ! in_array($page['panel'], [$item->panel, 'any'], true) || ! Route::has($data['route'])) {
                        throw new SazehException('صفحهٔ مقصد باید از صفحه‌های ثبت‌شدهٔ همین پنل انتخاب شود.');
                    }
                    if (Gatekeeper::routeNeedsParameters($data['route'])) {
                        throw new SazehException('صفحه‌ای که پارامتر لازم دارد نمی‌تواند مقصد منو باشد.');
                    }
                }
                $htmlPageId = $item->html_page_id;
                if ($type === 'html') {
                    if ($upload) {
                        $content = (string) file_get_contents($upload->getRealPath());
                        if (! mb_check_encoding($content, 'UTF-8')) {
                            $content = mb_convert_encoding($content, 'UTF-8', 'Windows-1256'); // فایل‌های قدیمی فارسی ویندوز
                        }
                        $page = $htmlPageId ? HtmlPage::find($htmlPageId) : null;
                        $page ??= new HtmlPage;
                        $page->forceFill(['panel' => $item->panel, 'original_name' => mb_substr($upload->getClientOriginalName(), 0, 200),
                            'content' => $content, 'size' => strlen($content), 'updated_by' => $request->user()->getKey()])->save();
                        $htmlPageId = $page->id;
                    } elseif (! $htmlPageId) {
                        throw new SazehException('فایل HTML صفحه را انتخاب کنید.');
                    }
                }
                if ($type === 'external' && ($err = MenuService::externalUrlError((string) $data['url']))) {
                    throw new SazehException($err);
                }
                if (! empty($data['permission'])) {
                    $meta = $this->registry->permissionCatalog()[$data['permission']] ?? null;
                    if (! $meta || $meta['panel'] !== $item->panel) {
                        throw new SazehException('مجوز انتخاب‌شده متعلق به این پنل نیست.');
                    }
                }
                $pagePerm = $type === 'page' ? ($page['permission'] ?? null) : null;
                $item->forceFill([
                    'title' => $data['title'], 'icon' => $data['icon'], 'type' => $type,
                    'route' => $type === 'page' ? $data['route'] : null,
                    'url' => $type === 'external' ? $data['url'] : null,
                    'new_tab' => $type === 'external',
                    'html_page_id' => $type === 'html' ? $htmlPageId : $item->html_page_id,
                    'permission' => $type === 'group' ? null : ($data['permission'] ?: null),
                    'is_active' => (bool) ($data['is_active'] ?? false),
                ])->save();
                if (! empty($data['access_present'])) {
                    $note = $this->applyAccess($item, $pagePerm, (array) ($data['access'] ?? []));
                }
            }
            $this->audit->log('menu.updated', $item, ['title' => $item->title]);
            MenuService::bump();

            return trim('ذخیره شد. '.$note);
        }, 'ذخیره شد.');
    }

    /**
     * تیک نقش‌ها ← دسترسی.
     *  - صفحهٔ دارای مجوز + کاربر با roles.manage: مجوز صفحه به نقش‌های تیک‌خورده داده و از بقیه گرفته می‌شود.
     *  - بقیهٔ حالت‌ها (صفحهٔ بدون مجوز، HTML، لینک، گروه، یا کاربر بدون roles.manage): فقط محدودیت نمایش.
     */
    private function applyAccess(MenuItem $item, ?string $pagePerm, array $ticked): string
    {
        $roles = Role::with('permissions:id,key')->where('panel', $item->panel)->whereNull('workspace_id')->get();
        $ticked = $roles->whereIn('id', array_map('intval', $ticked))->pluck('id')->all();

        if (! $pagePerm) {
            $item->roles()->sync($ticked);

            return $ticked ? 'فقط نقش‌های انتخاب‌شده این آیتم را می‌بینند.' : '';
        }
        if (! $this->gate->allows('roles.manage')) {
            $item->roles()->sync($ticked);

            return 'برای دادن دسترسی، مجوز «مدیریت نقش‌ها» لازم است؛ تیک‌ها فقط نمایش را محدود کرد.';
        }

        $perm = Permission::where('key', $pagePerm)->first();
        if (! $perm) {
            throw new SazehException('مجوز این صفحه هنوز ثبت نشده است؛ php artisan sazeh:sync را اجرا کنید.');
        }
        $plan = MenuAccess::plan(
            $roles->mapWithKeys(fn (Role $r) => [$r->id => (bool) $r->grants_all])->all(),
            $roles->filter(fn (Role $r) => $r->permissions->contains('key', $pagePerm))->pluck('id')->all(),
            $ticked,
            $this->permissionShared($pagePerm, $item),
        );
        DB::transaction(function () use ($roles, $plan, $perm, $item) {
            foreach ($roles->whereIn('id', $plan['grant']) as $r) {
                $r->permissions()->syncWithoutDetaching([$perm->id]);
            }
            foreach ($roles->whereIn('id', $plan['revoke']) as $r) {
                $r->permissions()->detach($perm->id);
            }
            $item->roles()->sync([]); // مجوز خودش تعیین می‌کند چه کسی ببیند
        });
        if ($plan['grant'] || $plan['revoke']) {
            $this->audit->log('menu.access', $item, ['permission' => $pagePerm, 'grant' => $plan['grant'], 'revoke' => $plan['revoke']]);
        }

        $name = fn (array $ids) => $roles->whereIn('id', $ids)->pluck('title')->implode('، ');
        $parts = [];
        if ($plan['grant']) {
            $parts[] = 'دسترسی داده شد به: '.$name($plan['grant']).'.';
        }
        if ($plan['revoke']) {
            $parts[] = 'دسترسی گرفته شد از: '.$name($plan['revoke']).'.';
        }
        if ($plan['kept']) {
            $parts[] = 'مجوز این صفحه جای دیگری هم استفاده می‌شود، پس از «'.$name($plan['kept']).'» گرفته نشد؛ از «نقش‌ها و دسترسی‌ها» اقدام کنید.';
        }

        return implode(' ', $parts);
    }

    /** آیا مجوز صفحه، صفحهٔ دیگر یا آیتم منوی دیگری را هم کنترل می‌کند؟ */
    private function permissionShared(string $perm, MenuItem $item): bool
    {
        $otherPage = collect($this->registry->pages())->contains(fn ($p) => ($p['permission'] ?? null) === $perm && $p['route'] !== $item->route);

        return $otherPage || MenuItem::where('id', '!=', $item->id)->where('permission', $perm)->exists();
    }

    public function toggle(MenuItem $item): RedirectResponse
    {
        return $this->attempt(function () use ($item) {
            if ($item->is_system) {
                throw new SazehException('آیتم سیستمی قابل غیرفعال‌سازی نیست.');
            }
            if (! $item->is_active && $item->type === 'html' && ! $item->html_page_id) {
                throw new SazehException('پیش از فعال‌سازی، فایل HTML را انتخاب کنید.');
            }
            if (! $item->is_active && $item->type === 'page' && ! $item->route) {
                throw new SazehException('پیش از فعال‌سازی، صفحهٔ مقصد را انتخاب کنید.');
            }
            $item->forceFill(['is_active' => ! $item->is_active])->save();
            $this->audit->log('menu.toggled', $item, ['active' => $item->is_active]);
            MenuService::bump();
        }, $item->is_active ? 'غیرفعال شد.' : 'فعال شد.');
    }

    /** جابه‌جایی: up | down | in (زیر گروه قبلی) | out (یک سطح بیرون) */
    public function move(Request $request, MenuItem $item): RedirectResponse
    {
        $dir = $request->input('dir');

        return $this->attempt(function () use ($item, $dir) {
            DB::transaction(function () use ($item, $dir) {
                $siblings = MenuItem::where('panel', $item->panel)->where('parent_id', $item->parent_id)->orderBy('sort')->orderBy('id')->get()->values();
                $i = $siblings->search(fn ($s) => $s->id === $item->id);
                $all = MenuItem::where('panel', $item->panel)->get(['id', 'parent_id', 'type', 'panel'])->map->toArray()->all();

                if ($dir === 'up' || $dir === 'down') {
                    $j = $dir === 'up' ? $i - 1 : $i + 1;
                    if (! isset($siblings[$j])) {
                        return;
                    }
                    $siblings->splice(min($i, $j), 2, $dir === 'up' ? [$siblings[$i], $siblings[$j]] : [$siblings[$j], $siblings[$i]]);
                    $siblings->values()->each(fn ($s, $k) => $s->forceFill(['sort' => $k + 1])->save());
                } elseif ($dir === 'in') {
                    $prev = $siblings[$i - 1] ?? null;
                    if (! $prev) {
                        throw new SazehException('آیتمی قبل از این نیست.');
                    }
                    if ($err = MenuTree::moveError($all, $item->id, $prev->id)) {
                        throw new SazehException($err);
                    }
                    $item->forceFill(['parent_id' => $prev->id, 'sort' => (int) MenuItem::where('parent_id', $prev->id)->max('sort') + 1])->save();
                } elseif ($dir === 'out') {
                    $parent = $item->parent;
                    if (! $parent) {
                        throw new SazehException('در بالاترین سطح است.');
                    }
                    $item->forceFill(['parent_id' => $parent->parent_id])->save();
                    $sib = MenuItem::where('panel', $item->panel)->where('parent_id', $parent->parent_id)->where('id', '!=', $item->id)
                        ->orderBy('sort')->orderBy('id')->get()->values();
                    $pos = $sib->search(fn ($s) => $s->id === $parent->id) + 1;
                    $sib->splice($pos, 0, [$item]);
                    $sib->values()->each(fn ($s, $k) => $s->forceFill(['sort' => $k + 1])->save());
                }
            });
            MenuService::bump();
        }, 'جابه‌جا شد.');
    }

    public function destroy(MenuItem $item): RedirectResponse
    {
        return $this->attempt(function () use ($item) {
            if ($item->is_system) {
                throw new SazehException('آیتم سیستمی قابل حذف نیست.');
            }
            $ids = $this->subtree($item->id);
            MenuItem::whereIn('id', $ids)->get()->each->delete();
            $this->audit->log('menu.deleted', $item, ['count' => count($ids)]);
            MenuService::bump();

            return redirect()->route('sazeh.platform.menus', ['panel' => $item->panel]);
        }, 'حذف شد؛ از بخش «حذف‌شده‌ها» قابل بازیابی است.');
    }

    public function restore(int $id): RedirectResponse
    {
        $item = MenuItem::onlyTrashed()->findOrFail($id);
        $item->restore();
        if ($item->parent_id && ! MenuItem::find($item->parent_id)) {
            $item->forceFill(['parent_id' => null])->save();
        }
        MenuItem::onlyTrashed()->whereIn('id', $this->subtree($item->id, true))->get()->each->restore();
        $this->audit->log('menu.restored', $item);
        MenuService::bump();

        return back()->with('success', 'بازیابی شد.');
    }

    private function subtree(int $id, bool $withTrashed = false): array
    {
        $q = $withTrashed ? MenuItem::withTrashed() : MenuItem::query();
        $out = [$id];
        foreach ($q->where('parent_id', $id)->pluck('id') as $child) {
            $out = array_merge($out, $this->subtree($child, $withTrashed));
        }

        return $out;
    }
}
