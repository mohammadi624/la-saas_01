<?php

namespace Sazeh\Core\Http\Controllers\Platform;

use Illuminate\Http\Request;
use Illuminate\View\View;
use Sazeh\Core\Http\Controllers\Controller;
use Sazeh\Core\Models\AuditLog;

class AuditController extends Controller
{
    public function index(Request $request): View
    {
        $q = trim((string) $request->query('q'));

        return view('sazeh::platform.audit', [
            'logs' => AuditLog::with('actor')->when($q !== '', fn ($w) => $w->where('action', 'like', "%{$q}%"))
                ->latest('id')->paginate(50)->withQueryString(),
            'q' => $q,
        ]);
    }
}
