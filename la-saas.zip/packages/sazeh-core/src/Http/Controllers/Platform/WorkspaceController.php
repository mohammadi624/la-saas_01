<?php

namespace Sazeh\Core\Http\Controllers\Platform;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Sazeh\Core\Actions\CreateWorkspace;
use Sazeh\Core\Actions\ResolveIdentity;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Billing\EntitlementService;
use Sazeh\Core\Http\Controllers\Controller;
use Sazeh\Core\Models\Plan;
use Sazeh\Core\Models\Workspace;

/** فضاهای کاری (خریداران / مشتریان). مدیر پلتفرم بدون عضویت به دادهٔ داخل فضا دسترسی ندارد. */
class WorkspaceController extends Controller
{
    public function index(Request $request, EntitlementService $ent): View
    {
        $q = trim((string) $request->query('q'));
        $workspaces = Workspace::with('owner', 'plan')->withCount('memberships')
            ->when($q !== '', fn ($w) => $w->where(fn ($x) => $x->where('name', 'like', "%{$q}%")->orWhere('slug', 'like', "%{$q}%")))
            ->latest('id')->paginate(30)->withQueryString();

        return view('sazeh::platform.workspaces', ['workspaces' => $workspaces, 'plans' => Plan::where('is_active', true)->get(),
            'ent' => $ent, 'q' => $q]);
    }

    /** «خریدار جدید»: هویت (یا هویت موجود) + فضای کاری + عضویت مالک */
    public function store(Request $request, ResolveIdentity $identity, CreateWorkspace $create, AuditLogger $audit): RedirectResponse
    {
        $request->validate(['ws_name' => 'required|string|max:100', 'slug' => 'required|string|max:60', 'plan_id' => 'nullable|integer',
            'name' => 'nullable|string|max:100', 'mobile' => 'required|string|max:30', 'email' => 'nullable|email', 'password' => 'nullable|string|max:200']);

        return $this->attempt(function () use ($request, $identity, $create) {
            DB::transaction(function () use ($request, $identity, $create) {
                [$owner] = $identity->handle($request->only(['name', 'mobile', 'email', 'password']), $request->user());
                $plan = $request->filled('plan_id') ? Plan::find($request->integer('plan_id'))?->id : null;
                $create->handle($owner, $request->input('ws_name'), $request->input('slug'), $plan, $request->user());
            });
        }, 'فضای کاری و مالک آن ساخته شد. مالک با موبایل خودش وارد پنل کاربری می‌شود.');
    }

    public function status(Request $request, Workspace $workspace, AuditLogger $audit): RedirectResponse
    {
        $request->validate(['status' => 'required|in:'.implode(',', array_keys(Workspace::STATUSES))]);
        $workspace->forceFill(['status' => $request->input('status')])->save();
        $audit->log('workspace.status', $workspace, ['status' => $workspace->status], null, $workspace->id);

        return back()->with('success', 'وضعیت فضای کاری تغییر کرد.');
    }
}
