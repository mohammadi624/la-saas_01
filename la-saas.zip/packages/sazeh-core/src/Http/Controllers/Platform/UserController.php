<?php

namespace Sazeh\Core\Http\Controllers\Platform;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Sazeh\Core\Actions\CreatePlatformUser;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Exceptions\SazehException;
use Sazeh\Core\Http\Controllers\Controller;
use Sazeh\Core\Models\Role;

/** کاربران تیم پلتفرم (زیرمجموعهٔ مالک سایت) */
class UserController extends Controller
{
    public function __construct(private readonly AuditLogger $audit)
    {
    }

    public function index(Request $request): View
    {
        $q = trim((string) $request->query('q'));
        $users = config('sazeh.user_model')::query()->whereNotNull('platform_role_id')
            ->when($q !== '', fn ($w) => $w->where(fn ($x) => $x->where('name', 'like', "%{$q}%")->orWhere('mobile', 'like', "%{$q}%")->orWhere('email', 'like', "%{$q}%")))
            ->with(['platformRole.permissions'])->orderBy('id')->paginate(30)->withQueryString();

        return view('sazeh::platform.users', [
            'users' => $users,
            'roles' => Role::with('permissions')->where('panel', 'platform')->whereNull('workspace_id')->orderBy('id')->get(),
            'starts' => \Sazeh\Core\Auth\StartPage::choices('platform'),
            'q' => $q,
        ]);
    }

    public function store(Request $request, CreatePlatformUser $create): RedirectResponse
    {
        $request->validate(['name' => 'nullable|string|max:100', 'mobile' => 'required|string|max:30', 'email' => 'nullable|email|max:150',
            'password' => 'nullable|string|max:200', 'role_id' => 'required|integer']);

        return $this->attempt(function () use ($request, $create) {
            [$user, $existed] = $create->handle($request->only(['name', 'mobile', 'email', 'password', 'role_id']));
            return ($existed ? "نقش پلتفرم به «{$user->name}» (حساب موجود) داده شد." : "«{$user->name}» به تیم پلتفرم اضافه شد.");
        }, 'کاربر اضافه شد.');
    }

    public function update(Request $request, int $id): RedirectResponse
    {
        $user = config('sazeh.user_model')::whereNotNull('platform_role_id')->findOrFail($id);
        $request->validate(['role_id' => 'nullable|integer', 'status' => 'nullable|in:active,inactive', 'remove' => 'nullable|boolean']);

        return $this->attempt(function () use ($request, $user) {
            $me = $request->user();
            if ((int) $me->getKey() === (int) $user->getKey()) {
                throw new SazehException('نقش یا وضعیت خودتان را نمی‌توانید تغییر دهید.');
            }
            $admins = Role::where('panel', 'platform')->where('grants_all', true)->pluck('id');
            $isLastAdmin = $admins->contains($user->platform_role_id)
                && config('sazeh.user_model')::whereIn('platform_role_id', $admins)->where('status', 'active')->count() <= 1;

            if ($request->filled('role_id')) {
                $role = Role::where('panel', 'platform')->findOrFail($request->integer('role_id'));
                if ($isLastAdmin && ! $role->grants_all) {
                    throw new SazehException('آخرین مدیر کل را نمی‌توان تغییر نقش داد.');
                }
                $user->forceFill(['platform_role_id' => $role->id])->save();
            }
            if ($request->filled('status')) {
                if ($isLastAdmin && $request->input('status') !== 'active') {
                    throw new SazehException('آخرین مدیر کل قابل غیرفعال‌سازی نیست.');
                }
                $user->forceFill(['status' => $request->input('status')])->save();
            }
            if ($request->boolean('remove')) {
                if ($isLastAdmin) {
                    throw new SazehException('آخرین مدیر کل قابل حذف از تیم نیست.');
                }
                $user->forceFill(['platform_role_id' => null])->save(); // فقط از تیم خارج می‌شود؛ هویت باقی است
            }
            $this->audit->log('platform.user_changed', $user, $request->only(['role_id', 'status', 'remove']));
        }, 'ذخیره شد.');
    }
}
