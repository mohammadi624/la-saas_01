<?php

namespace Sazeh\Core\Http\Controllers\Platform;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Auth\StartPage;
use Sazeh\Core\Exceptions\SazehException;
use Sazeh\Core\Http\Controllers\Controller;
use Sazeh\Core\Menu\MenuService;
use Sazeh\Core\Models\Membership;
use Sazeh\Core\Models\Permission;
use Sazeh\Core\Models\Role;

/** نقش‌های قالب پلتفرم و فضای کاری + ماتریس مجوز + صفحهٔ شروع هر نقش */
class RoleController extends Controller
{
    public function __construct(private readonly AuditLogger $audit)
    {
    }

    public function index(Request $request): View
    {
        $panel = $request->query('panel') === 'workspace' ? 'workspace' : 'platform';

        return view('sazeh::platform.roles', [
            'panel' => $panel,
            'roles' => Role::with('permissions:id,key')->where('panel', $panel)->whereNull('workspace_id')->orderBy('id')->get(),
            'permissions' => Permission::where('panel', $panel)->whereNull('orphaned_at')->orderBy('module')->orderBy('id')->get()->groupBy('module'),
            'starts' => StartPage::choices($panel),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate(['panel' => 'required|in:platform,workspace', 'title' => 'required|string|max:60']);
        $role = new Role;
        $key = Str::slug($data['title']) ?: 'role';
        $key = (preg_match('/^[a-z]/', $key) ? $key : 'r-'.$key).'-'.Str::lower(Str::random(4));
        $role->forceFill(['panel' => $data['panel'], 'key' => $key, 'title' => $data['title'], 'grants_all' => false, 'is_system' => false])->save();
        $this->audit->log('role.created', $role);

        return redirect()->route('sazeh.platform.roles', ['panel' => $data['panel']])->with('success', 'نقش ساخته شد؛ مجوزهایش را تیک بزنید.');
    }

    /** ذخیرهٔ کل ماتریس یک پنل در یک درخواست */
    public function matrix(Request $request): RedirectResponse
    {
        $panel = $request->input('panel') === 'workspace' ? 'workspace' : 'platform';
        $matrix = (array) $request->input('perm', []);
        $starts = (array) $request->input('start', []);
        $valid = Permission::where('panel', $panel)->pluck('id', 'key');
        $choices = StartPage::choices($panel);

        return $this->attempt(function () use ($panel, $matrix, $starts, $valid, $choices) {
            foreach (Role::where('panel', $panel)->whereNull('workspace_id')->get() as $role) {
                if (! $role->grants_all) {
                    $keys = array_keys((array) ($matrix[$role->id] ?? []));
                    $role->permissions()->sync($valid->only($keys)->values());
                }
                $start = $starts[$role->id] ?? null;
                if ($start !== null && $start !== '' && ! isset($choices[$start])) {
                    throw new SazehException("صفحهٔ شروع نقش «{$role->title}» معتبر نیست.");
                }
                $role->forceFill(['start_route' => $start ?: null])->save();
            }
            $this->audit->log('role.matrix_saved', null, ['panel' => $panel]);
            MenuService::bump();
        }, 'نقش‌ها و مجوزها ذخیره شد.');
    }

    public function destroy(Role $role): RedirectResponse
    {
        return $this->attempt(function () use ($role) {
            if ($role->is_system) {
                throw new SazehException('نقش سیستمی قابل حذف نیست.');
            }
            $used = Membership::where('role_id', $role->id)->count() + config('sazeh.user_model')::where('platform_role_id', $role->id)->count();
            if ($used) {
                throw new SazehException("{$used} کاربر این نقش را دارند؛ ابتدا نقش آن‌ها را تغییر دهید.");
            }
            $role->delete();
            $this->audit->log('role.deleted', null, ['key' => $role->key]);
            MenuService::bump();
        }, 'نقش حذف شد.');
    }
}
