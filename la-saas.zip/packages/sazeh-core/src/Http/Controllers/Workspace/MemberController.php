<?php

namespace Sazeh\Core\Http\Controllers\Workspace;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Sazeh\Core\Access\Gatekeeper;
use Sazeh\Core\Actions\AddWorkspaceMember;
use Sazeh\Core\Actions\ChangeMembership;
use Sazeh\Core\Billing\EntitlementService;
use Sazeh\Core\Http\Controllers\Controller;
use Sazeh\Core\Models\Membership;
use Sazeh\Core\Tenancy\CurrentContext;

/** کاربران فضای کاری (زیرمجموعهٔ خریدار) — همیشه فقط فضای جاری */
class MemberController extends Controller
{
    public function __construct(private readonly CurrentContext $ctx)
    {
    }

    public function index(EntitlementService $ent, AddWorkspaceMember $add, Gatekeeper $gate): View
    {
        $ws = $this->ctx->workspace();
        $seats = $ent->seats($ws);

        return view('sazeh::workspace.members', [
            'ws' => $ws,
            'members' => Membership::with(['user', 'role.permissions', 'inviter'])->where('workspace_id', $ws->id)->orderBy('id')->get(),
            'starts' => \Sazeh\Core\Auth\StartPage::choices('workspace'),
            'roles' => $add->assignableRoles(),
            'canManage' => $gate->allows('members.manage'),
            'seatText' => $seats->unlimited ? 'نامحدود' : $ent->seatsUsed($ws).' از '.$seats->limit,
            'me' => $this->ctx->user(),
        ]);
    }

    public function store(Request $request, AddWorkspaceMember $add): RedirectResponse
    {
        $request->validate(['name' => 'nullable|string|max:100', 'mobile' => 'required|string|max:30', 'email' => 'nullable|email|max:150',
            'password' => 'nullable|string|max:200', 'role_id' => 'required|integer']);

        return $this->attempt(function () use ($request, $add) {
            [$user, $existed] = $add->handle($request->only(['name', 'mobile', 'email', 'password', 'role_id']));
            return ($existed ? "«{$user->name}» (حساب موجود) به این فضا اضافه شد." : "«{$user->name}» اضافه شد و با موبایل خودش وارد می‌شود.");
        }, 'کاربر اضافه شد.');
    }

    public function update(Request $request, int $membership, ChangeMembership $change): RedirectResponse
    {
        $request->validate(['role_id' => 'nullable|integer', 'status' => 'nullable|in:active,suspended']);

        return $this->attempt(fn () => $change->handle($membership, array_filter($request->only(['role_id', 'status']))), 'ذخیره شد.');
    }

    public function destroy(int $membership, ChangeMembership $change): RedirectResponse
    {
        return $this->attempt(fn () => $change->handle($membership, ['remove' => true]), 'کاربر از این فضا حذف شد؛ حساب او باقی است.');
    }
}
