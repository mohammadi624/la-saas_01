<?php

namespace Sazeh\Core\Http\Controllers;

use Illuminate\View\View;
use Sazeh\Core\Auth\StartPage;
use Sazeh\Core\Billing\EntitlementService;
use Sazeh\Core\Models\AuditLog;
use Sazeh\Core\Models\Membership;
use Sazeh\Core\Models\Workspace;
use Sazeh\Core\Tenancy\CurrentContext;

class DashboardController extends Controller
{
    public function platform(CurrentContext $ctx): View
    {
        $userModel = config('sazeh.user_model');

        return view('sazeh::dashboard.platform', [
            'stats' => [
                'کاربران' => $userModel::count(),
                'تیم پلتفرم' => $userModel::whereNotNull('platform_role_id')->count(),
                'فضاهای کاری' => Workspace::count(),
                'ورودهای ۲۴ ساعت' => AuditLog::where('action', 'login.success')->where('created_at', '>=', now()->subDay())->count(),
            ],
            'trace' => app(StartPage::class)->resolve()['trace'],
        ]);
    }

    public function workspace(CurrentContext $ctx, EntitlementService $ent): View
    {
        $ws = $ctx->workspace();
        $seats = $ent->seats($ws);

        return view('sazeh::dashboard.workspace', [
            'stats' => [
                'نقش شما' => $ctx->role()->title,
                (config('sazeh.panels.workspace.owner_label') ?: 'مالک') => $ctx->isWorkspaceOwner() ? 'خود شما' : ($ws->owner?->name ?? '—'),
                'کاربران فضا' => Membership::where('workspace_id', $ws->id)->count(),
                'ظرفیت' => $seats->unlimited ? 'نامحدود' : $ent->seatsUsed($ws).' از '.$seats->limit,
                'وضعیت' => Workspace::STATUSES[$ws->status] ?? $ws->status,
            ],
            'trace' => app(StartPage::class)->resolve()['trace'],
        ]);
    }
}
