<?php

namespace Sazeh\Core\Http\Controllers;

use Illuminate\View\View;
use Sazeh\Core\Menu\MenuService;
use Sazeh\Core\Models\HtmlPage;
use Sazeh\Core\Models\MenuItem;
use Sazeh\Core\Tenancy\CurrentContext;

/**
 * نمایش صفحهٔ HTML آپلودی.
 * دسترسی = دقیقاً همان قاعدهٔ نمایش آیتم منو (پنل، فعال بودن خودش و والدها، نقش‌ها، مجوز).
 * محتوا در iframe ایزوله (sandbox بدون allow-same-origin) نمایش داده می‌شود؛ هرگز PHP/Blade اجرا نمی‌شود.
 */
class HtmlPageController extends Controller
{
    public function show(int $item, CurrentContext $ctx, MenuService $menu): View
    {
        $m = MenuItem::where('type', 'html')->where('panel', $ctx->panel())->findOrFail($item);
        if (! $this->visible($menu->tree(), $m->id)) {
            abort(403, 'این صفحه برای نقش شما فعال نیست.');
        }
        $page = HtmlPage::findOrFail($m->html_page_id);

        return view('sazeh::html-page', ['item' => $m, 'page' => $page]);
    }

    private function visible(array $tree, int $id): bool
    {
        foreach ($tree as $n) {
            if ($n['id'] === $id || $this->visible($n['children'] ?? [], $id)) {
                return true;
            }
        }

        return false;
    }
}
