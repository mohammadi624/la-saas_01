<?php

namespace Sazeh\Core\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;
use Sazeh\Core\Audit\AuditLogger;

class AccountController extends Controller
{
    public function security(Request $request): View
    {
        return view('sazeh::account.security', ['user' => $request->user()]);
    }

    public function password(Request $request, AuditLogger $audit): RedirectResponse
    {
        $request->validate([
            'current_password' => 'required|string',
            'password' => 'required|string|confirmed|min:'.config('sazeh.password_min', 8),
        ]);
        $user = $request->user();
        if (! Hash::check($request->input('current_password'), $user->password)) {
            return back()->withErrors(['current_password' => 'رمز فعلی نادرست است.']);
        }
        $user->forceFill(['password' => Hash::make($request->input('password'))])->save();
        // باطل کردن نشست‌های دیگر (نیازمند AuthenticateSession در گروه web)
        Auth::logoutOtherDevices($request->input('password'));
        $request->session()->regenerate();
        $audit->log('password.changed', $user);

        return back()->with('success', 'رمز عبور تغییر کرد و نشست‌های دیگر باطل شدند.');
    }
}
