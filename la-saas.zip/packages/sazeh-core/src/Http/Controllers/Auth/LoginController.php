<?php

namespace Sazeh\Core\Http\Controllers\Auth;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\View\View;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Auth\OtpService;
use Sazeh\Core\Auth\StartPage;
use Sazeh\Core\Http\Controllers\Controller;
use Sazeh\Core\Support\Identifier;
use Sazeh\Core\Tenancy\CurrentContext;

class LoginController extends Controller
{
    private const GENERIC = 'شناسه یا رمز عبور نادرست است.';

    public function __construct(
        private readonly CurrentContext $ctx,
        private readonly AuditLogger $audit,
    ) {
    }

    public function show(): View|RedirectResponse
    {
        if (Auth::check()) {
            return redirect()->route('sazeh.home');
        }

        return view('sazeh::auth.login');
    }

    public function password(Request $request): RedirectResponse
    {
        $request->validate(['identifier' => 'required|string|max:120', 'password' => 'required|string|max:200']);
        $id = Identifier::parse($request->input('identifier'));
        $key = 'sazeh-login:'.$id->value.'|'.$request->ip();
        $max = (int) config('sazeh.login.max_attempts', 5);

        if (RateLimiter::tooManyAttempts($key, $max)) {
            $min = (int) ceil(RateLimiter::availableIn($key) / 60);
            $this->audit->log('login.locked', null, ['identifier' => $id->value], null, null);

            return back()->withInput($request->only('identifier'))
                ->withErrors(['identifier' => "به‌دلیل تلاش‌های ناموفق، ورود با این شناسه تا {$min} دقیقهٔ دیگر مسدود است."]);
        }

        $user = $id->isValid() ? config('sazeh.user_model')::where($id->type, $id->value)->first() : null;
        if (! $user || ! Hash::check($request->input('password'), $user->password)) {
            RateLimiter::hit($key, (int) config('sazeh.login.lock_minutes', 15) * 60);
            $this->audit->log('login.failed', null, ['identifier' => $id->value]);
            $left = max(0, $max - RateLimiter::attempts($key));

            return back()->withInput($request->only('identifier'))
                ->withErrors(['identifier' => self::GENERIC.($left > 0 ? " ({$left} تلاش باقی‌مانده)" : '')]);
        }
        RateLimiter::clear($key);

        return $this->complete($request, $user, 'password');
    }

    public function otpRequest(Request $request, OtpService $otp): RedirectResponse
    {
        abort_unless(config('sazeh.login.otp'), 404);
        $request->validate(['mobile' => 'required|string|max:30']);
        $mobile = Identifier::normalizeMobile($request->input('mobile'));
        if (! $mobile) {
            return back()->withInput()->withErrors(['mobile' => 'یک شمارهٔ موبایل معتبر وارد کنید.']);
        }
        $exists = config('sazeh.user_model')::where('mobile', $mobile)->exists();
        if ($err = $otp->request($mobile, $exists)) {
            return back()->withInput()->withErrors(['mobile' => $err]);
        }
        session(['sazeh.otp_mobile' => $mobile]);
        $this->audit->log('otp.requested', null, ['mobile' => $mobile]);

        return redirect()->route('sazeh.login.otp.form')
            ->with('info', 'اگر حسابی با این شماره وجود داشته باشد، کد '.config('sazeh.otp.length').' رقمی برایش ارسال شد.');
    }

    public function otpForm(): View|RedirectResponse
    {
        return session('sazeh.otp_mobile') ? view('sazeh::auth.otp', ['mobile' => session('sazeh.otp_mobile')]) : redirect()->route('sazeh.login');
    }

    public function otpVerify(Request $request, OtpService $otp): RedirectResponse
    {
        $request->validate(['code' => 'required|string|max:12']);
        $mobile = session('sazeh.otp_mobile');
        if (! $mobile) {
            return redirect()->route('sazeh.login');
        }
        $code = preg_replace('/\D/', '', Identifier::toLatinDigits($request->input('code')));
        $user = config('sazeh.user_model')::where('mobile', $mobile)->first();
        if (! $user || ! $otp->verify($mobile, $code)) {
            $this->audit->log('otp.failed', null, ['mobile' => $mobile]);

            return back()->withErrors(['code' => 'کد نامعتبر یا منقضی است.']);
        }
        session()->forget('sazeh.otp_mobile');

        return $this->complete($request, $user, 'otp');
    }

    /** پایان ورود: وضعیت هویت ← نشست تازه ← انتخاب بخش ← صفحهٔ شروع نقش */
    public function complete(Request $request, Authenticatable $user, string $method): RedirectResponse
    {
        if (! $user->isActiveIdentity()) {
            $this->audit->log('login.blocked_inactive', $user, [], $user->getKey());

            return redirect()->route('sazeh.login')->withErrors(['identifier' => 'امکان ورود با این حساب وجود ندارد. با پشتیبانی تماس بگیرید.']);
        }
        $intended = session('url.intended');
        Auth::login($user, $request->boolean('remember'));
        $request->session()->regenerate();
        if ($intended) {
            session(['url.intended' => $intended]);
        }
        $user->forceFill(['last_login_at' => now(), 'last_login_ip' => $request->ip()])->save();
        $this->audit->log('login.success', $user, ['method' => $method], $user->getKey());

        $ok = $this->ctx->available($user)->where('ok', true)->values();
        if ($ok->isEmpty()) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('sazeh.login')->withErrors(['identifier' => 'ورود موفق بود اما هیچ بخش فعالی برای شما وجود ندارد (عضویت یا اشتراک فعال نیست).']);
        }
        if ($ok->count() > 1) {
            return redirect()->route('sazeh.context.pick');
        }
        $this->ctx->enter($user, $ok->first()['key']);

        return redirect()->to(app(StartPage::class)->resolve(session()->pull('url.intended'))['url']);
    }

    public function logout(Request $request): RedirectResponse
    {
        $this->audit->log('logout', Auth::user());
        $this->ctx->forget();
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('sazeh.login')->with('success', 'با موفقیت خارج شدید.');
    }
}
