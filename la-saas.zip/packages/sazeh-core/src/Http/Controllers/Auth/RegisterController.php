<?php

namespace Sazeh\Core\Http\Controllers\Auth;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Sazeh\Core\Actions\RegisterUser;
use Sazeh\Core\Exceptions\SazehException;
use Sazeh\Core\Http\Controllers\Controller;

class RegisterController extends Controller
{
    public function show(): View
    {
        abort_unless(config('sazeh.registration.mode') === 'public', 404);

        return view('sazeh::auth.register');
    }

    public function store(Request $request, RegisterUser $register, LoginController $login): RedirectResponse
    {
        abort_unless(config('sazeh.registration.mode') === 'public', 404);
        $request->validate([
            'name' => 'required|string|max:100',
            'mobile' => 'required|string|max:30',
            'email' => (config('sazeh.registration.require_email') ? 'required' : 'nullable').'|email|max:150',
            'password' => 'required|string|confirmed|min:'.config('sazeh.password_min', 8),
            'workspace_name' => 'nullable|string|max:100',
        ]);
        try {
            // فقط فیلدهای مجاز به Action می‌رود (Mass Assignment ممکن نیست)
            $user = $register->handle($request->only(['name', 'mobile', 'email', 'password', 'workspace_name']));
        } catch (SazehException $e) {
            return back()->withInput($request->except(['password', 'password_confirmation']))->withErrors(['form' => $e->getMessage()]);
        }

        return $login->complete($request, $user, 'register');
    }
}
