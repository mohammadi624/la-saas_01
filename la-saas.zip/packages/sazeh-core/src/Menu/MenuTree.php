<?php

namespace Sazeh\Core\Menu;

/**
 * ساخت و اعتبارسنجی درخت منو — خالص و بدون وابستگی.
 * هر آیتم آرایه‌ای است با کلیدهای: id, parent_id, type(page|group|external), is_active, sort
 */
final class MenuTree
{
    public const MAX_DEPTH = 3;

    /**
     * درخت قابل‌نمایش برای یک کاربر.
     *
     * @param  array<int,array>  $items
     * @param  callable(array):bool  $leafVisible  برای آیتم صفحه/لینک: آیا این کاربر می‌بیند؟
     * @return array<int,array> آیتم‌ها با کلید children
     */
    public static function visible(array $items, callable $leafVisible): array
    {
        $byParent = self::groupByParent($items);

        $walk = function ($parentId) use (&$walk, $byParent, $leafVisible): array {
            $out = [];
            foreach ($byParent[$parentId ?? 0] ?? [] as $item) {
                if (! ($item['is_active'] ?? true)) {
                    continue; // غیرفعال بودن والد، کل زیرشاخه را پنهان می‌کند
                }
                if (($item['type'] ?? 'page') === 'group') {
                    $children = $walk($item['id']);
                    if ($children === []) {
                        continue; // گروه خالی نمایش داده نمی‌شود
                    }
                    $item['children'] = $children;
                    $out[] = $item;
                } elseif ($leafVisible($item)) {
                    $item['children'] = [];
                    $out[] = $item;
                }
            }

            return $out;
        };

        return $walk(null);
    }

    /** اولین آیتم صفحه در درخت قابل‌نمایش (برای صفحهٔ شروع جایگزین) */
    public static function firstPage(array $tree): ?array
    {
        foreach ($tree as $item) {
            if (($item['type'] ?? 'page') === 'page') {
                return $item;
            }
            if ($found = self::firstPage($item['children'] ?? [])) {
                return $found;
            }
        }

        return null;
    }

    /** درخت کامل (برای منوساز) */
    public static function nest(array $items): array
    {
        $byParent = self::groupByParent($items);
        $walk = function ($parentId) use (&$walk, $byParent): array {
            $out = [];
            foreach ($byParent[$parentId ?? 0] ?? [] as $item) {
                $item['children'] = $walk($item['id']);
                $out[] = $item;
            }

            return $out;
        };

        return $walk(null);
    }

    /**
     * آیا می‌توان آیتم را زیر والد جدید برد؟ پیام خطا یا null.
     */
    public static function moveError(array $items, int $id, ?int $newParentId, int $maxDepth = self::MAX_DEPTH): ?string
    {
        $index = [];
        foreach ($items as $it) {
            $index[$it['id']] = $it;
        }
        if (! isset($index[$id])) {
            return 'آیتم یافت نشد.';
        }
        if ($newParentId === null) {
            return self::height($items, $id) > $maxDepth ? "حداکثر عمق منو {$maxDepth} سطح است." : null;
        }
        if (! isset($index[$newParentId])) {
            return 'والد یافت نشد.';
        }
        if ($index[$newParentId]['panel'] ?? null) {
            if (($index[$newParentId]['panel'] ?? null) !== ($index[$id]['panel'] ?? null)) {
                return 'والد باید در همان پنل باشد.';
            }
        }
        for ($c = $newParentId; $c !== null; $c = $index[$c]['parent_id'] ?? null) {
            if ($c === $id) {
                return 'یک آیتم نمی‌تواند زیرمجموعهٔ خودش یا فرزندانش شود.';
            }
        }
        if (($index[$newParentId]['type'] ?? null) !== 'group') {
            return 'فقط آیتم نوع «گروه» می‌تواند زیرمنو داشته باشد.';
        }
        if (self::depth($index, $newParentId) + self::height($items, $id) > $maxDepth) {
            return "حداکثر عمق منو {$maxDepth} سطح است.";
        }

        return null;
    }

    private static function depth(array $index, int $id): int
    {
        $d = 0;
        for ($c = $id; $c !== null; $c = $index[$c]['parent_id'] ?? null) {
            $d++;
        }

        return $d;
    }

    private static function height(array $items, int $id): int
    {
        $max = 0;
        foreach ($items as $it) {
            if (($it['parent_id'] ?? null) === $id) {
                $max = max($max, self::height($items, $it['id']));
            }
        }

        return 1 + $max;
    }

    private static function groupByParent(array $items): array
    {
        usort($items, fn ($a, $b) => [($a['sort'] ?? 0), $a['id']] <=> [($b['sort'] ?? 0), $b['id']]);
        $by = [];
        foreach ($items as $it) {
            $by[$it['parent_id'] ?? 0][] = $it;
        }

        return $by;
    }
}
