<?php

namespace Sazeh\Core\Menu;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Route;
use Sazeh\Core\Access\Gatekeeper;
use Sazeh\Core\Models\MenuItem;
use Sazeh\Core\Tenancy\CurrentContext;

class MenuService
{
    public function __construct(private readonly Gatekeeper $gate, private readonly CurrentContext $ctx)
    {
    }

    /** همهٔ آیتم‌های یک پنل (کش‌شده تا تغییر بعدی) — بدون N+1 */
    public function items(string $panel): array
    {
        return Cache::rememberForever('sazeh:menu:'.$panel.':v'.self::version(), fn () => MenuItem::with('roles:id')
            ->where('panel', $panel)->orderBy('sort')->get()
            ->map(fn (MenuItem $m) => [
                'id' => $m->id, 'parent_id' => $m->parent_id, 'panel' => $m->panel, 'key' => $m->key,
                'title' => $m->title, 'icon' => $m->icon, 'type' => $m->type, 'route' => $m->route, 'url' => $m->url, 'html_page_id' => $m->html_page_id,
                'permission' => $m->permission, 'new_tab' => $m->new_tab, 'is_active' => $m->is_active,
                'is_system' => $m->is_system, 'sort' => $m->sort, 'roles' => $m->roles->pluck('id')->all(),
            ])->all());
    }

    /** درخت منوی قابل‌نمایش برای کاربر جاری */
    public function tree(): array
    {
        $panel = $this->ctx->panel();
        if (! $panel) {
            return [];
        }
        $roleId = $this->ctx->role()?->id;

        return MenuTree::visible($this->items($panel), fn (array $item) => $this->why($item, $roleId) === null);
    }

    /** دلیل پنهان بودن یک آیتم برگ برای نقش جاری؛ null یعنی نمایش داده می‌شود */
    public function why(array $item, ?int $roleId): ?string
    {
        if ($item['roles'] && ! in_array($roleId, $item['roles'], true)) {
            return 'برای این نقش تعریف نشده است.';
        }
        if ($item['type'] === 'external') {
            return self::externalUrlError((string) $item['url']);
        }
        if ($item['type'] === 'html') {
            if (empty($item['html_page_id'])) {
                return 'فایل HTML انتخاب نشده است.';
            }
            if ($item['permission']) {
                $d = $this->gate->decide($item['permission']);

                return $d->allowed ? null : $d->message();
            }

            return $this->ctx->user()?->isActiveIdentity() ? null : 'کاربر غیرفعال است.';
        }
        if (! $item['route'] || ! Route::has($item['route'])) {
            return 'صفحهٔ مقصد وجود ندارد.';
        }
        $d = $this->gate->page($item['route'], $item['permission']);

        return $d->allowed ? null : $d->message();
    }

    /**
     * صفحه‌های فایلی فقط وقتی باز هستند که آیتم منوی فعالِ قابل‌نمایش برای نقش جاری داشته باشند.
     * (صفحهٔ بدون منو = بسته؛ مدیر با فعال کردن آیتم در منوساز آن را باز می‌کند.)
     *
     * @return string|null دلیل بسته بودن؛ null یعنی مشکلی نیست
     */
    public function menuGateReason(string $route): ?string
    {
        if (! config('sazeh.file_pages.require_menu', true) || ! str_starts_with($route, 'sazeh.page.')) {
            return null;
        }

        return MenuAccess::routeInTree($this->tree(), $route) ? null : 'این صفحه در منوی نقش شما فعال نشده است.';
    }

    public static function externalUrlError(string $url): ?string
    {
        $parts = parse_url($url);
        if (! $parts || ($parts['scheme'] ?? '') !== 'https' || empty($parts['host'])) {
            return 'فقط آدرس https مجاز است.';
        }
        if (! in_array(strtolower($parts['host']), array_map('strtolower', (array) config('sazeh.external_link_domains', [])), true)) {
            return 'دامنهٔ لینک در فهرست دامنه‌های مجاز نیست.';
        }

        return null;
    }

    public static function version(): int
    {
        return (int) Cache::get('sazeh:version', 1);
    }

    /** پس از هر تغییر در منو، نقش یا مجوز صدا زده شود */
    public static function bump(): void
    {
        Cache::forever('sazeh:version', self::version() + 1);
    }
}
