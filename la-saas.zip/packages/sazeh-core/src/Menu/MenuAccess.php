<?php

namespace Sazeh\Core\Menu;

/**
 * منطق خالص «دسترسی از منوساز».
 *
 * وقتی مدیر در منوساز برای یک صفحه نقش‌ها را تیک می‌زند، مجوز همان صفحه به آن نقش‌ها
 * داده و از نقش‌های تیک‌نخورده گرفته می‌شود. این کلاس فقط تصمیم می‌گیرد چه چیزی عوض شود؛
 * ذخیره در دیتابیس با کنترلر است. هیچ وابستگی به Laravel ندارد.
 */
final class MenuAccess
{
    /**
     * برنامهٔ تغییر مجوز.
     *
     * @param  array<int,bool>  $grantsAll  role_id => آیا نقش «همهٔ دسترسی‌ها» دارد
     * @param  int[]  $holders  نقش‌هایی که الان مجوز را دارند
     * @param  int[]  $ticked  نقش‌هایی که مدیر تیک زده است
     * @param  bool  $shared  آیا این مجوز جای دیگری هم استفاده می‌شود (آن‌وقت گرفتنش ممنوع است)
     * @return array{grant:int[],revoke:int[],kept:int[]} kept = نقش‌هایی که باید گرفته می‌شد ولی چون مشترک است ماند
     */
    public static function plan(array $grantsAll, array $holders, array $ticked, bool $shared): array
    {
        $roles = array_map('intval', array_keys($grantsAll));
        $ticked = array_values(array_intersect(array_map('intval', $ticked), $roles));
        $holders = array_values(array_intersect(array_map('intval', $holders), $roles));
        $normal = array_values(array_filter($roles, fn ($id) => ! $grantsAll[$id]));

        $grant = array_values(array_diff(array_intersect($ticked, $normal), $holders));
        $toRevoke = array_values(array_diff(array_intersect($holders, $normal), $ticked));

        sort($grant);
        sort($toRevoke);

        return $shared
            ? ['grant' => $grant, 'revoke' => [], 'kept' => $toRevoke]
            : ['grant' => $grant, 'revoke' => $toRevoke, 'kept' => []];
    }

    /**
     * چه نقش‌هایی این آیتم را می‌بینند؟
     *
     * @param  array<int,true|string[]>  $rolePerms  role_id => true (همهٔ دسترسی‌ها) یا فهرست کلید مجوزها
     * @param  string[]  $needed  مجوزهای لازم (مجوز صفحه + مجوز اضافهٔ آیتم)
     * @param  int[]  $pivot  محدودیت نقش آیتم (خالی = بدون محدودیت)
     * @return int[]
     */
    public static function audience(array $rolePerms, array $needed, array $pivot): array
    {
        $needed = array_values(array_filter($needed));
        $out = [];
        foreach ($rolePerms as $id => $perms) {
            if ($pivot && ! in_array((int) $id, array_map('intval', $pivot), true)) {
                continue;
            }
            if ($perms === true || array_diff($needed, (array) $perms) === []) {
                $out[] = (int) $id;
            }
        }

        return $out;
    }

    /**
     * وضعیت نمایشی یک آیتم در منوساز.
     *
     * @param  array{type:string,is_active:bool,route:?string,module:?string,created_at:?string,updated_at:?string,html_page_id?:?int}  $item
     * @return string[] برچسب‌ها: new | missing | no_target | inactive
     */
    public static function badges(array $item, bool $routeExists): array
    {
        $out = [];
        if (($item['type'] ?? 'page') === 'page') {
            if (empty($item['route'])) {
                $out[] = 'no_target';
            } elseif (! $routeExists) {
                $out[] = 'missing';
            }
        }
        if (($item['type'] ?? '') === 'html' && empty($item['html_page_id'])) {
            $out[] = 'no_target';
        }
        if (($item['module'] ?? null) === 'pages' && empty($item['is_active'])
            && ($item['created_at'] ?? null) !== null && ($item['created_at'] ?? null) === ($item['updated_at'] ?? null)) {
            $out[] = 'new';
        }
        if (empty($item['is_active'])) {
            $out[] = 'inactive';
        }

        return $out;
    }

    /** آیا یک Route در درخت قابل‌نمایش هست؟ */
    public static function routeInTree(array $tree, string $route): bool
    {
        foreach ($tree as $node) {
            if (($node['type'] ?? 'page') === 'page' && ($node['route'] ?? null) === $route) {
                return true;
            }
            if (self::routeInTree($node['children'] ?? [], $route)) {
                return true;
            }
        }

        return false;
    }

    /** اثر انگشت فهرست صفحه‌ها؛ با تغییر آن، کشف خودکار دوباره اجرا می‌شود */
    public static function fingerprint(array $pages): string
    {
        $rows = array_map(fn ($p) => ($p['route'] ?? '').'|'.($p['title'] ?? '').'|'.($p['permission'] ?? ''), $pages);
        sort($rows);

        return md5(implode("\n", $rows));
    }
}
