<?php

namespace Sazeh\Core\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

class MakePageCommand extends Command
{
    protected $signature = 'sazeh:page
        {panel : platform (پنل مالک سایت) یا workspace (پنل خریدار)}
        {path : مسیر لاتین، مثلاً reports/sales}
        {title? : عنوان صفحه}
        {--icon=file : آیکون منو}
        {--all : همهٔ نقش‌های این پنل بدون مجوز جدا ببینند}';

    protected $description = 'ساخت یک صفحهٔ جدید داشبورد و اتصال خودکار به منو و ماتریس نقش‌ها';

    public function handle(): int
    {
        $panel = $this->argument('panel');
        if (! in_array($panel, ['platform', 'workspace'], true)) {
            $this->error('پنل باید platform یا workspace باشد.');

            return self::FAILURE;
        }
        $path = trim(strtolower(str_replace('\\', '/', $this->argument('path'))), '/');
        if (! preg_match('#^[a-z0-9][a-z0-9-]*(/[a-z0-9][a-z0-9-]*)*$#', $path)) {
            $this->error('مسیر فقط حروف کوچک لاتین، عدد، خط تیره و / باشد. مثال: reports/sales');

            return self::FAILURE;
        }
        $file = rtrim(config('sazeh.file_pages.path', resource_path('views/pages')), '/\\')."/{$panel}/{$path}.blade.php";
        if (File::exists($file)) {
            $this->error("این صفحه از قبل وجود دارد: {$file}");

            return self::FAILURE;
        }
        // عنوان فارسی در cmd ویندوز ممکن است خالی برسد؛ بعداً در فایل یا منوساز قابل تغییر است
        $title = trim((string) $this->argument('title')) ?: str_replace(['/', '-'], [' / ', ' '], $path);
        $icon = preg_replace('/[^a-z]/', '', (string) $this->option('icon')) ?: 'file';

        File::ensureDirectoryExists(dirname($file));
        File::put($file, implode("\n", array_filter([
            "{{-- title: {$title} --}}",
            "{{-- icon: {$icon} --}}",
            $this->option('all') ? '{{-- access: all --}}' : null,
            '',
            '<div class="card">',
            '    <h2>{{ $page[\'title\'] }}</h2>',
            '    <p class="desc">محتوای این صفحه را اینجا بنویسید. HTML و Blade کامل در دسترس است.</p>',
            '    <p>کاربر جاری: <b>{{ auth()->user()->name }}</b> — نقش: <b>{{ $sazehCtx->role()?->title }}</b>',
            '    @if ($sazehCtx->workspace()) — فضای کاری: <b>{{ $sazehCtx->workspace()->name }}</b> @endif</p>',
            '</div>',
            '',
        ], fn ($l) => $l !== null)));

        $this->call('sazeh:sync');
        $prefix = config("sazeh.panels.{$panel}.prefix");
        $this->newLine();
        $this->info("صفحه ساخته شد: {$file}");
        $this->line("آدرس: /{$prefix}/p/{$path}");
        $this->line('۱) محتوای فایل را ویرایش کنید.');
        $this->line($this->option('all')
            ? '۲) این صفحه برای همهٔ نقش‌های این پنل باز است.'
            : '۲) در «نقش‌ها و دسترسی‌ها» تیک «صفحهٔ «'.$title.'»» را برای نقش‌های مجاز بزنید.');
        $this->line('۳) در «مدیریت منوها» آیتم غیرفعال این صفحه را فعال، جابه‌جا یا تغییر نام دهید.');

        return self::SUCCESS;
    }
}
