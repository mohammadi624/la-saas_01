<?php

namespace Sazeh\Core\Console;

use Illuminate\Console\Command;
use Sazeh\Core\Modules\ModuleSynchronizer;

class SyncCommand extends Command
{
    protected $signature = 'sazeh:sync {--dry-run : فقط نمایش تغییرات، بدون ذخیره}';

    protected $description = 'همگام‌سازی مجوزها، نقش‌های قالب و منوهای ماژول‌ها با دیتابیس';

    public function handle(ModuleSynchronizer $sync): int
    {
        $stats = $sync->sync((bool) $this->option('dry-run'));
        $this->table(['مورد', 'تعداد'], collect($stats)->map(fn ($v, $k) => [$k, $v])->values()->all());
        $this->info($this->option('dry-run') ? 'اجرای آزمایشی؛ چیزی ذخیره نشد.' : 'همگام‌سازی انجام شد.');

        return self::SUCCESS;
    }
}
