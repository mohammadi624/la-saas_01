<?php

namespace Sazeh\Core\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;
use Sazeh\Core\Actions\CreateWorkspace;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Models\Workspace;
use Sazeh\Core\Modules\ModuleSynchronizer;
use Sazeh\Core\Support\Identifier;

class InstallCommand extends Command
{
    protected $signature = 'sazeh:install
        {--name= : نام مدیر کل}
        {--mobile= : موبایل مدیر کل}
        {--email= : ایمیل مدیر کل (اختیاری)}
        {--password= : رمز مدیر کل}';

    protected $description = 'نصب هسته: همگام‌سازی، ساخت مدیر کل و فضای کاری پیش‌فرض';

    public function handle(ModuleSynchronizer $sync, CreateWorkspace $createWorkspace): int
    {
        $sync->sync();
        $this->info('ماژول‌ها همگام شدند.');

        $model = config('sazeh.user_model');
        $adminRole = Role::where('panel', 'platform')->whereNull('workspace_id')->where('key', 'admin')->firstOrFail();

        $admin = $model::where('platform_role_id', $adminRole->id)->first();
        if (! $admin) {
            $name = trim((string) ($this->option('name') ?: $this->ask('نام مدیر کل (در cmd ویندوز نام لاتین بنویسید یا از --name استفاده کنید)')));
            if ($name === '') {
                $this->error('نام خالی است. اگر فارسی تایپ کرده‌اید، cmd آن را منتقل نکرده؛ از --name="Admin" استفاده کنید و بعداً در پنل تغییر دهید.');

                return self::FAILURE;
            }
            $mobile = Identifier::normalizeMobile((string) ($this->option('mobile') ?: $this->ask('موبایل مدیر کل (09…)')));
            if (! $mobile) {
                $this->error('موبایل نامعتبر است.');

                return self::FAILURE;
            }
            $email = $this->option('email') ?: null;
            $password = $this->option('password') ?: $this->secret('رمز عبور (حداقل '.config('sazeh.password_min', 8).' نویسه)');
            if (mb_strlen((string) $password) < (int) config('sazeh.password_min', 8)) {
                $this->error('رمز کوتاه است.');

                return self::FAILURE;
            }
            $admin = $model::where('mobile', $mobile)->first() ?? new $model;
            $admin->forceFill(['name' => $name, 'mobile' => $mobile, 'email' => $email ?? $admin->email,
                'password' => Hash::make($password), 'status' => 'active', 'platform_role_id' => $adminRole->id])->save();
            $this->info("مدیر کل ساخته شد: {$mobile}");
        } else {
            $this->line('مدیر کل از قبل وجود دارد.');
        }

        $slug = config('sazeh.default_workspace.slug');
        if (! Workspace::where('slug', $slug)->exists()) {
            $createWorkspace->handle($admin, (string) config('sazeh.default_workspace.name'), $slug);
            $this->info("فضای کاری پیش‌فرض «{$slug}» ساخته شد (مالک: مدیر کل).");
        }

        $this->newLine();
        $this->info('نصب کامل شد. ورود: '.url('/login'));

        return self::SUCCESS;
    }
}
