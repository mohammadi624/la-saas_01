<?php

namespace Sazeh\Core\Support;

/**
 * تشخیص و نرمال‌سازی شناسهٔ ورود (ایمیل، موبایل ایران، نام کاربری).
 * کلاس خالص PHP است و به Laravel وابسته نیست.
 */
final class Identifier
{
    public const EMAIL = 'email';
    public const MOBILE = 'mobile';
    public const USERNAME = 'username';

    private const FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    private const AR_DIGITS = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

    public function __construct(public readonly ?string $type, public readonly string $value)
    {
    }

    public static function toLatinDigits(string $input): string
    {
        $latin = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

        return str_replace(self::AR_DIGITS, $latin, str_replace(self::FA_DIGITS, $latin, $input));
    }

    /** موبایل ایران را به قالب 09xxxxxxxxx برمی‌گرداند؛ در غیر این صورت null */
    public static function normalizeMobile(string $input): ?string
    {
        $digits = preg_replace('/[\s\-().]/u', '', self::toLatinDigits(trim($input)));
        if ($digits === null || ! preg_match('/^(?:\+98|0098|98|0)?(9\d{9})$/', $digits, $m)) {
            return null;
        }

        return '0'.$m[1];
    }

    public static function parse(?string $raw): self
    {
        $id = trim(self::toLatinDigits((string) $raw));
        if ($id === '') {
            return new self(null, '');
        }
        if (str_contains($id, '@')) {
            $email = mb_strtolower($id);

            return new self(filter_var($email, FILTER_VALIDATE_EMAIL) ? self::EMAIL : null, $email);
        }
        if ($mobile = self::normalizeMobile($id)) {
            return new self(self::MOBILE, $mobile);
        }
        if (preg_match('/^[a-zA-Z][a-zA-Z0-9_.\-]{2,40}$/', $id)) {
            return new self(self::USERNAME, mb_strtolower($id));
        }

        return new self(null, $id);
    }

    public function isValid(): bool
    {
        return $this->type !== null;
    }
}
