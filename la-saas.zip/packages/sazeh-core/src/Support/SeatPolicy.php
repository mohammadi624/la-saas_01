<?php

namespace Sazeh\Core\Support;

/** محدودیت عددی با معنای صریح «نامحدود» (هرگز null به‌معنای نامحدود نیست) */
final class SeatPolicy
{
    public function __construct(public readonly bool $unlimited, public readonly int $limit)
    {
    }

    public static function unlimited(): self
    {
        return new self(true, 0);
    }

    public static function of(int $limit): self
    {
        return new self(false, max(0, $limit));
    }

    /** پیام خطا در صورت عدم امکان افزودن یک عضو دیگر؛ وگرنه null */
    public function blocks(int $used): ?string
    {
        if ($this->unlimited) {
            return null;
        }
        if ($this->limit === 0) {
            return 'پلن این فضای کاری امکان افزودن کاربر ندارد.';
        }
        if ($used >= $this->limit) {
            return "ظرفیت کاربران پر است ({$this->limit} نفر).";
        }

        return null;
    }
}
