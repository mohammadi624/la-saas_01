<?php

namespace Sazeh\Core\Support;

use DateTimeInterface;

/** نمایش تاریخ شمسی (بدون وابستگی). ذخیره در دیتابیس میلادی می‌ماند. */
final class Jalali
{
    public const MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

    /** @return array{0:int,1:int,2:int} */
    public static function fromGregorian(int $gy, int $gm, int $gd): array
    {
        $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        $gy2 = $gm > 2 ? $gy + 1 : $gy;
        $days = 355666 + (365 * $gy) + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100) + intdiv($gy2 + 399, 400) + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * intdiv($days, 12053));
        $days %= 12053;
        $jy += 4 * intdiv($days, 1461);
        $days %= 1461;
        if ($days > 365) {
            $jy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }
        if ($days < 186) {
            $jm = 1 + intdiv($days, 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + intdiv($days - 186, 30);
            $jd = 1 + (($days - 186) % 30);
        }

        return [$jy, $jm, $jd];
    }

    /** @return array{0:int,1:int,2:int} */
    public static function toGregorian(int $jy, int $jm, int $jd): array
    {
        $jy += 1595;
        $days = -355668 + (365 * $jy) + (intdiv($jy, 33) * 8) + intdiv(($jy % 33) + 3, 4) + $jd
            + ($jm < 7 ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186);
        $gy = 400 * intdiv($days, 146097);
        $days %= 146097;
        if ($days > 36524) {
            $days--;
            $gy += 100 * intdiv($days, 36524);
            $days %= 36524;
            if ($days >= 365) {
                $days++;
            }
        }
        $gy += 4 * intdiv($days, 1461);
        $days %= 1461;
        if ($days > 365) {
            $gy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }
        $gd = $days + 1;
        $leap = ($gy % 4 === 0 && $gy % 100 !== 0) || $gy % 400 === 0;
        $months = [31, $leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        $gm = 0;
        while ($gm < 12 && $gd > $months[$gm]) {
            $gd -= $months[$gm];
            $gm++;
        }

        return [$gy, $gm + 1, $gd];
    }

    /** «۱۳۷۰/۰۵/۱۲» یا «1370-5-12» ← «1991-08-03»؛ تاریخ نامعتبر ← null */
    public static function parse(?string $input): ?string
    {
        $s = trim(Identifier::toLatinDigits((string) $input));
        if (! preg_match('#^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})$#', $s, $m)) {
            return null;
        }
        [$jy, $jm, $jd] = [(int) $m[1], (int) $m[2], (int) $m[3]];
        if ($jy < 1200 || $jy > 1600 || $jm < 1 || $jm > 12 || $jd < 1 || $jd > ($jm <= 6 ? 31 : 30)) {
            return null;
        }
        [$gy, $gm, $gd] = self::toGregorian($jy, $jm, $jd);
        if (self::fromGregorian($gy, $gm, $gd) !== [$jy, $jm, $jd]) {
            return null; // مثلاً ۳۰ اسفند در سال غیرکبیسه
        }

        return sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
    }

    /** برای مقدار پیش‌فرض فیلد فرم: «1991-08-03» ← «1370/05/12» */
    public static function toInput(DateTimeInterface|string|null $date): string
    {
        if ($date === null || $date === '') {
            return '';
        }
        $d = $date instanceof DateTimeInterface ? $date : new \DateTimeImmutable((string) $date);
        [$y, $m, $dd] = self::fromGregorian((int) $d->format('Y'), (int) $d->format('n'), (int) $d->format('j'));

        return sprintf('%04d/%02d/%02d', $y, $m, $dd);
    }

    /** ۱۴۰۵/۰۸/۲۹ یا ۲۹ آبان ۱۴۰۵ */
    public static function format(DateTimeInterface|string|null $date, bool $long = false, bool $persianDigits = true): string
    {
        if ($date === null || $date === '') {
            return '—';
        }
        $dt = $date instanceof DateTimeInterface ? $date : new \DateTimeImmutable((string) $date);
        [$y, $m, $d] = self::fromGregorian((int) $dt->format('Y'), (int) $dt->format('n'), (int) $dt->format('j'));
        $out = $long ? $d.' '.self::MONTHS[$m - 1].' '.$y : sprintf('%04d/%02d/%02d', $y, $m, $d);

        return $persianDigits ? self::digits($out) : $out;
    }

    public static function digits(string|int|float $s): string
    {
        return str_replace(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'], (string) $s);
    }

    /** ۱۲٬۵۰۰٬۰۰۰ */
    public static function money(int|float|null $amount): string
    {
        return self::digits(number_format((float) $amount, 0, '.', '٬'));
    }
}
