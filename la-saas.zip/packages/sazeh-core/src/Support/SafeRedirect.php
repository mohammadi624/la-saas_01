<?php

namespace Sazeh\Core\Support;

/** اعتبارسنجی مقصد بازگشت (intended) در برابر Open Redirect */
final class SafeRedirect
{
    /** فقط مسیر نسبی همان میزبان را برمی‌گرداند؛ در غیر این صورت null */
    public static function path(?string $target): ?string
    {
        $t = trim(Identifier::toLatinDigits((string) $target));
        if ($t === '' || $t[0] !== '/') {
            return null;
        }
        if (preg_match('#^/[/\\\\]#', $t) || preg_match('/[\x00-\x1F]/', $t)) {
            return null;
        }
        $path = preg_split('/[?#]/', $t)[0];
        $path = rtrim($path, '/');

        return $path === '' ? '/' : $path;
    }
}
