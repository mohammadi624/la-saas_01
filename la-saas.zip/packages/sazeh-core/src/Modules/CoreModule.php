<?php

namespace Sazeh\Core\Modules;

/** ماژول خود هسته: داشبورد، منوساز، نقش‌ها، کاربران، فضاهای کاری، اعضا، امنیت حساب */
final class CoreModule extends Module
{
    public function key(): string
    {
        return 'core';
    }

    public function title(): string
    {
        return 'هسته';
    }

    public function permissions(): array
    {
        return [
            ['key' => 'menus.manage', 'panel' => 'platform', 'label' => 'مدیریت منوها', 'is_write' => true],
            ['key' => 'roles.manage', 'panel' => 'platform', 'label' => 'مدیریت نقش‌ها و مجوزها', 'is_write' => true],
            ['key' => 'users.manage', 'panel' => 'platform', 'label' => 'مدیریت کاربران تیم پلتفرم', 'is_write' => true],
            ['key' => 'workspaces.manage', 'panel' => 'platform', 'label' => 'مدیریت فضاهای کاری / خریداران', 'is_write' => true],
            ['key' => 'audit.view', 'panel' => 'platform', 'label' => 'مشاهدهٔ لاگ امنیتی'],

            ['key' => 'members.view', 'panel' => 'workspace', 'label' => 'مشاهدهٔ کاربران فضا', 'feature' => 'members'],
            ['key' => 'members.manage', 'panel' => 'workspace', 'label' => 'افزودن و مدیریت کاربران فضا', 'is_write' => true, 'feature' => 'members'],
            ['key' => 'billing.view', 'panel' => 'workspace', 'label' => 'اشتراک و پرداخت'],
        ];
    }

    public function pages(): array
    {
        return [
            ['route' => 'sazeh.platform.dashboard', 'panel' => 'platform', 'title' => 'داشبورد'],
            ['route' => 'sazeh.platform.menus', 'panel' => 'platform', 'title' => 'مدیریت منوها', 'permission' => 'menus.manage'],
            ['route' => 'sazeh.platform.roles', 'panel' => 'platform', 'title' => 'نقش‌ها و دسترسی‌ها', 'permission' => 'roles.manage'],
            ['route' => 'sazeh.platform.users', 'panel' => 'platform', 'title' => 'کاربران تیم', 'permission' => 'users.manage'],
            ['route' => 'sazeh.platform.workspaces', 'panel' => 'platform', 'title' => 'فضاهای کاری', 'permission' => 'workspaces.manage'],
            ['route' => 'sazeh.platform.audit', 'panel' => 'platform', 'title' => 'لاگ امنیتی', 'permission' => 'audit.view'],

            ['route' => 'sazeh.workspace.dashboard', 'panel' => 'workspace', 'title' => 'داشبورد'],
            ['route' => 'sazeh.workspace.members', 'panel' => 'workspace', 'title' => 'کاربران', 'permission' => 'members.view'],

            ['route' => 'sazeh.account.security', 'panel' => 'any', 'title' => 'امنیت حساب'],
            // صفحه‌های HTML آپلودی؛ دسترسی دقیق در HtmlPageController با قاعدهٔ منو
            ['route' => 'sazeh.platform.html', 'panel' => 'platform', 'title' => 'صفحهٔ HTML'],
            ['route' => 'sazeh.workspace.html', 'panel' => 'workspace', 'title' => 'صفحهٔ HTML'],
        ];
    }

    public function menu(): array
    {
        return [
            ['key' => 'p.dashboard', 'panel' => 'platform', 'title' => 'داشبورد', 'icon' => 'home', 'route' => 'sazeh.platform.dashboard', 'sort' => 1, 'system' => true],
            ['key' => 'p.workspaces', 'panel' => 'platform', 'title' => 'فضاهای کاری', 'icon' => 'folder', 'route' => 'sazeh.platform.workspaces', 'sort' => 50],
            ['key' => 'p.system', 'panel' => 'platform', 'title' => 'تنظیمات سیستم', 'icon' => 'gear', 'type' => 'group', 'sort' => 90],
            ['key' => 'p.menus', 'panel' => 'platform', 'parent' => 'p.system', 'title' => 'مدیریت منوها', 'icon' => 'menu', 'route' => 'sazeh.platform.menus', 'sort' => 1, 'system' => true],
            ['key' => 'p.roles', 'panel' => 'platform', 'parent' => 'p.system', 'title' => 'نقش‌ها و دسترسی‌ها', 'icon' => 'key', 'route' => 'sazeh.platform.roles', 'sort' => 2, 'system' => true],
            ['key' => 'p.users', 'panel' => 'platform', 'parent' => 'p.system', 'title' => 'کاربران تیم', 'icon' => 'users', 'route' => 'sazeh.platform.users', 'sort' => 3, 'system' => true],
            ['key' => 'p.audit', 'panel' => 'platform', 'parent' => 'p.system', 'title' => 'لاگ امنیتی', 'icon' => 'shield', 'route' => 'sazeh.platform.audit', 'sort' => 4],
            ['key' => 'p.account', 'panel' => 'platform', 'title' => 'امنیت حساب', 'icon' => 'lock', 'route' => 'sazeh.account.security', 'sort' => 99, 'system' => true],

            ['key' => 'w.dashboard', 'panel' => 'workspace', 'title' => 'داشبورد', 'icon' => 'home', 'route' => 'sazeh.workspace.dashboard', 'sort' => 1, 'system' => true],
            ['key' => 'w.members', 'panel' => 'workspace', 'title' => 'کاربران', 'icon' => 'users', 'route' => 'sazeh.workspace.members', 'sort' => 50],
            ['key' => 'w.account', 'panel' => 'workspace', 'title' => 'امنیت حساب', 'icon' => 'lock', 'route' => 'sazeh.account.security', 'sort' => 99, 'system' => true],
        ];
    }

    public function roles(): array
    {
        return [
            ['key' => 'admin', 'panel' => 'platform', 'title' => 'مدیر کل', 'grants_all' => true, 'system' => true, 'start' => 'sazeh.platform.dashboard'],
            ['key' => 'staff', 'panel' => 'platform', 'title' => 'کارمند پلتفرم', 'start' => 'sazeh.platform.dashboard', 'permissions' => []],

            ['key' => self::ownerRoleKey(), 'panel' => 'workspace', 'title' => self::ownerRoleTitle(), 'grants_all' => true, 'system' => true, 'start' => 'sazeh.workspace.dashboard'],
            ['key' => 'manager', 'panel' => 'workspace', 'title' => 'مدیر', 'start' => 'sazeh.workspace.dashboard', 'permissions' => ['members.view', 'members.manage', 'billing.view']],
            ['key' => 'member', 'panel' => 'workspace', 'title' => 'عضو', 'start' => 'sazeh.workspace.dashboard', 'permissions' => []],
        ];
    }

    /** کلید نقش مالک فضای کاری (قابل تنظیم؛ پیش‌فرض owner) */
    public static function ownerRoleKey(): string
    {
        return function_exists('config') && function_exists('app') && app()->bound('config')
            ? (string) config('sazeh.workspace_owner_role.key', 'owner') : 'owner';
    }

    public static function ownerRoleTitle(): string
    {
        return function_exists('config') && function_exists('app') && app()->bound('config')
            ? (string) config('sazeh.workspace_owner_role.title', 'مالک') : 'مالک';
    }

    public function features(): array
    {
        return ['members' => 'کاربران فضای کاری'];
    }

    public function routes(): ?string
    {
        return __DIR__.'/../../routes/web.php';
    }
}
