<?php

namespace Sazeh\Core\Modules;

/**
 * قرارداد ماژول. هر قابلیت (فروشگاه، نوبت‌دهی، وبلاگ، …) یک کلاس از این نوع است
 * و هر چیزی را که به هسته معرفی می‌کند فقط از همین متدها برمی‌گرداند.
 * هسته هیچ‌وقت کد ماژول را تغییر نمی‌دهد و ماژول هم هسته را تغییر نمی‌دهد.
 */
abstract class Module
{
    /** شناسهٔ یکتا، مثلاً 'shop' */
    abstract public function key(): string;

    public function title(): string
    {
        return $this->key();
    }

    /**
     * مجوزها.
     *
     * @return array<int,array{key:string,panel:string,label:string,is_write?:bool,feature?:?string}>
     */
    public function permissions(): array
    {
        return [];
    }

    /**
     * صفحه‌ها (Routeهای نام‌دار) و مجوز لازم هر کدام.
     * panel می‌تواند 'platform'، 'workspace' یا 'any' (مثل صفحهٔ امنیت حساب) باشد.
     *
     * @return array<int,array{route:string,panel:string,title:string,permission?:?string}>
     */
    public function pages(): array
    {
        return [];
    }

    /**
     * آیتم‌های پیش‌فرض منو. فقط اگر وجود نداشته باشند ساخته می‌شوند؛ تغییرات مدیر حفظ می‌شود.
     *
     * @return array<int,array{key:string,panel:string,title:string,type?:string,icon?:string,route?:string,url?:string,parent?:string,sort?:int,system?:bool,permission?:string}>
     */
    public function menu(): array
    {
        return [];
    }

    /**
     * نقش‌های قالب (برای همهٔ فضاها یا پلتفرم).
     *
     * @return array<int,array{key:string,panel:string,title:string,grants_all?:bool,system?:bool,start?:?string,permissions?:string[]}>
     */
    public function roles(): array
    {
        return [];
    }

    /**
     * قابلیت‌های قابل فروش در پلن (فقط وقتی اشتراک روشن است معنا دارد).
     *
     * @return array<string,string> کلید => عنوان
     */
    public function features(): array
    {
        return [];
    }

    /** پوشهٔ Migrationهای ماژول (فقط وقتی ماژول فعال است اجرا می‌شوند) */
    public function migrations(): ?string
    {
        return null;
    }

    /** دستورهای Artisan ماژول @return class-string[] */
    public function commands(): array
    {
        return [];
    }

    /** اجرا هنگام بوت برنامه (ثبت Listener، Scheduler و …) */
    public function boot(): void
    {
    }

    /** پوشهٔ نماهای ماژول؛ با namespace کلید ماژول در دسترس است: view('blog::index') */
    public function views(): ?string
    {
        return null;
    }

    /** فایل Route ماژول (اختیاری) */
    public function routes(): ?string
    {
        return null;
    }
}
