<?php

namespace Sazeh\Core\Modules;

use InvalidArgumentException;

/** فهرست ماژول‌های فعال و اطلاعات تجمیعی آن‌ها (بدون وابستگی به دیتابیس) */
final class ModuleRegistry
{
    /** @var array<string,Module> */
    private array $modules = [];

    public function register(Module $module): void
    {
        $key = $module->key();
        if (isset($this->modules[$key])) {
            throw new InvalidArgumentException("ماژول «{$key}» دو بار ثبت شده است.");
        }
        $this->modules[$key] = $module;
    }

    /** @return array<string,Module> */
    public function all(): array
    {
        return $this->modules;
    }

    /** @return array<string,array{panel:string,label:string,is_write:bool,feature:?string,module:string}> */
    public function permissionCatalog(): array
    {
        $out = [];
        foreach ($this->modules as $mk => $m) {
            foreach ($m->permissions() as $p) {
                if (isset($out[$p['key']])) {
                    throw new InvalidArgumentException("مجوز «{$p['key']}» تکراری است.");
                }
                $out[$p['key']] = [
                    'panel' => $p['panel'],
                    'label' => $p['label'],
                    'is_write' => (bool) ($p['is_write'] ?? false),
                    'feature' => $p['feature'] ?? null,
                    'module' => $mk,
                ];
            }
        }

        return $out;
    }

    /** @return array<string,array{route:string,panel:string,title:string,permission:?string,module:string}> */
    public function pages(): array
    {
        $out = [];
        foreach ($this->modules as $mk => $m) {
            foreach ($m->pages() as $p) {
                $out[$p['route']] = $p + ['permission' => null, 'module' => $mk];
            }
        }

        return $out;
    }

    public function page(string $route): ?array
    {
        return $this->pages()[$route] ?? null;
    }

    /** @return array<string,string> */
    public function features(): array
    {
        $out = [];
        foreach ($this->modules as $m) {
            $out += $m->features();
        }

        return $out;
    }
}
