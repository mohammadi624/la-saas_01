<?php

namespace Sazeh\Core\Modules;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Sazeh\Core\Menu\MenuAccess;
use Sazeh\Core\Menu\MenuService;
use Sazeh\Core\Models\MenuItem;
use Sazeh\Core\Models\Permission;
use Sazeh\Core\Models\Role;

/**
 * همگام‌سازی تعاریف ماژول‌ها با دیتابیس — idempotent (اجرای مکرر بی‌خطر است).
 * - مجوزها: ایجاد/به‌روزرسانی؛ مجوز حذف‌شده از کد فقط orphaned علامت می‌خورد.
 * - نقش‌های قالب: فقط اگر وجود ندارند ساخته می‌شوند (تغییرات مدیر حفظ می‌شود).
 * - منوها: فقط آیتم‌های جدید اضافه می‌شوند؛ عنوان/ترتیب/وضعیتی که مدیر تغییر داده دست نمی‌خورد.
 */
class ModuleSynchronizer
{
    public function __construct(private readonly ModuleRegistry $registry)
    {
    }

    /** @return array<string,int> آمار تغییرات */
    public function sync(bool $dryRun = false): array
    {
        $stats = ['permissions_created' => 0, 'permissions_updated' => 0, 'permissions_orphaned' => 0, 'roles_created' => 0, 'menu_created' => 0];

        $run = function () use (&$stats) {
            $catalog = $this->registry->permissionCatalog();
            foreach ($catalog as $key => $meta) {
                $p = Permission::firstOrNew(['key' => $key]);
                $stats[$p->exists ? 'permissions_updated' : 'permissions_created']++;
                $p->fill(['panel' => $meta['panel'], 'label' => $meta['label'], 'module' => $meta['module'],
                    'feature' => $meta['feature'], 'is_write' => $meta['is_write'], 'orphaned_at' => null])->save();
            }
            $stats['permissions_orphaned'] = Permission::whereNotIn('key', array_keys($catalog))->whereNull('orphaned_at')->update(['orphaned_at' => now()]);

            foreach ($this->registry->all() as $mk => $module) {
                foreach ($module->roles() as $r) {
                    $role = Role::where('panel', $r['panel'])->whereNull('workspace_id')->where('key', $r['key'])->first();
                    if ($role) {
                        continue;
                    }
                    $role = new Role;
                    $role->forceFill(['panel' => $r['panel'], 'workspace_id' => null, 'key' => $r['key'], 'title' => $r['title'],
                        'grants_all' => (bool) ($r['grants_all'] ?? false), 'is_system' => (bool) ($r['system'] ?? false),
                        'start_route' => $r['start'] ?? null, 'module' => $mk])->save();
                    $ids = Permission::whereIn('key', $r['permissions'] ?? [])->pluck('id');
                    $role->permissions()->sync($ids);
                    $stats['roles_created']++;
                }

                $stats['menu_created'] += $this->syncMenu($mk, $module);
            }
        };

        if ($dryRun) {
            DB::beginTransaction();
            try {
                $run();
            } finally {
                DB::rollBack();
            }
        } else {
            DB::transaction($run);
            MenuService::bump();
            Cache::forever('sazeh:pages:fingerprint', $this->pagesFingerprint());
        }

        return $stats;
    }

    /**
     * کشف خودکار صفحه‌های فایلی، بدون اجرای دستی sazeh:sync.
     * فقط وقتی فهرست فایل‌ها عوض شده باشد به دیتابیس می‌نویسد (هر بار باز کردن منوساز صدا زده می‌شود).
     *
     * @return int تعداد آیتم منوی جدید
     */
    public function discoverPages(): int
    {
        $module = $this->registry->all()['pages'] ?? null;
        if (! $module) {
            return 0;
        }
        $fp = $this->pagesFingerprint();
        if (Cache::get('sazeh:pages:fingerprint') === $fp) {
            return 0;
        }

        $created = DB::transaction(function () use ($module) {
            $keys = [];
            foreach ($module->permissions() as $p) {
                $keys[] = $p['key'];
                Permission::firstOrNew(['key' => $p['key']])->fill([
                    'panel' => $p['panel'], 'label' => $p['label'], 'module' => 'pages',
                    'feature' => null, 'is_write' => false, 'orphaned_at' => null,
                ])->save();
            }
            // صفحه‌ای که فایلش حذف شده: مجوزش فقط علامت می‌خورد (تیک نقش‌ها برای بازگشت فایل حفظ می‌شود)
            Permission::where('module', 'pages')->whereNotIn('key', $keys)->whereNull('orphaned_at')->update(['orphaned_at' => now()]);

            return $this->syncMenu('pages', $module);
        });

        Cache::forever('sazeh:pages:fingerprint', $fp);
        MenuService::bump();

        return $created;
    }

    private function pagesFingerprint(): string
    {
        $module = $this->registry->all()['pages'] ?? null;

        return $module ? MenuAccess::fingerprint($module->pages()) : '';
    }

    /** آیتم‌های منوی یک ماژول را فقط در صورت نبودن می‌سازد. @return int تعداد ساخته‌شده */
    private function syncMenu(string $mk, Module $module): int
    {
        $count = 0;
        $byKey = MenuItem::withTrashed()->whereNotNull('key')->get()->keyBy(fn ($m) => $m->panel.'|'.$m->key);
        foreach ($module->menu() as $i => $m) {
            if (isset($byKey[$m['panel'].'|'.$m['key']])) {
                continue;
            }
            $parentId = isset($m['parent']) ? ($byKey[$m['panel'].'|'.$m['parent']]->id ?? null) : null;
            $item = new MenuItem;
            $item->forceFill([
                'panel' => $m['panel'], 'key' => $m['key'], 'parent_id' => $parentId, 'title' => $m['title'],
                'icon' => $m['icon'] ?? 'file', 'type' => $m['type'] ?? (isset($m['url']) ? 'external' : 'page'),
                'route' => $m['route'] ?? null, 'url' => $m['url'] ?? null, 'permission' => $m['permission'] ?? null,
                'new_tab' => isset($m['url']), 'is_active' => (bool) ($m['active'] ?? true), 'is_system' => (bool) ($m['system'] ?? false),
                'sort' => $m['sort'] ?? ($i + 1), 'module' => $mk,
            ])->save();
            $byKey[$m['panel'].'|'.$m['key']] = $item;
            $count++;
        }

        return $count;
    }
}
