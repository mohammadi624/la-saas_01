<?php

namespace Sazeh\Core\Sms;

use Illuminate\Support\Facades\Log;

/** فقط برای توسعه: پیامک را در لاگ می‌نویسد. در production استفاده نکنید. */
class LogSmsGateway implements SmsGateway
{
    public function send(string $mobile, string $message): void
    {
        Log::info("[sazeh-sms] {$mobile}: {$message}");
    }
}
