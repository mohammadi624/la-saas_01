<?php

namespace Sazeh\Core\Sms;

/** درایور پیامک. برای سرویس‌دهندهٔ واقعی (کاوه‌نگار، ملی‌پیامک، …) این Interface را پیاده کنید. */
interface SmsGateway
{
    public function send(string $mobile, string $message): void;
}
