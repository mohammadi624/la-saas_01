<?php

namespace Sazeh\Core\Actions;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Sazeh\Core\Access\Gatekeeper;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Billing\EntitlementService;
use Sazeh\Core\Exceptions\SazehException;
use Sazeh\Core\Models\Membership;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Models\Workspace;
use Sazeh\Core\Tenancy\CurrentContext;

/**
 * کاربری که مالک/مدیر فضا اضافه می‌کند زیرمجموعهٔ همان فضاست (core_memberships).
 * فضای مقصد همیشه فضای جاری است و از فرم پذیرفته نمی‌شود.
 */
class AddWorkspaceMember
{
    public function __construct(
        private readonly ResolveIdentity $identity,
        private readonly CurrentContext $ctx,
        private readonly Gatekeeper $gate,
        private readonly EntitlementService $entitlements,
        private readonly AuditLogger $audit,
    ) {
    }

    /** @return array{0:Authenticatable,1:bool} [کاربر، هویت از قبل وجود داشت] */
    public function handle(array $data): array
    {
        $ws = $this->ctx->workspace();
        if (! $ws) {
            throw SazehException::forbidden('افزودن کاربر فقط داخل یک فضای کاری ممکن است.');
        }
        $d = $this->gate->decide('members.manage');
        if (! $d->allowed) {
            throw SazehException::forbidden($d->message());
        }
        $role = $this->assignableRole((int) ($data['role_id'] ?? 0));

        return DB::transaction(function () use ($data, $ws, $role) {
            // قفل ردیف فضا تا ظرفیت با درخواست‌های هم‌زمان دور زده نشود
            $locked = Workspace::whereKey($ws->id)->lockForUpdate()->first();
            if ($why = $this->entitlements->seats($locked)->blocks($this->entitlements->seatsUsed($locked))) {
                throw SazehException::conflict($why);
            }
            [$user, $existed] = $this->identity->handle($data, $this->ctx->user());
            if (Membership::withTrashed()->where('workspace_id', $ws->id)->where('user_id', $user->getKey())->exists()) {
                $m = Membership::withTrashed()->where('workspace_id', $ws->id)->where('user_id', $user->getKey())->first();
                if (! $m->trashed()) {
                    throw SazehException::conflict('این شخص قبلاً عضو همین فضا است.');
                }
                $m->restore(); // بازگردانی به‌جای ردیف دوم
                $m->forceFill(['role_id' => $role->id, 'status' => 'active', 'invited_by' => $this->ctx->user()->getKey()])->save();
            } else {
                (new Membership)->forceFill([
                    'workspace_id' => $ws->id, 'user_id' => $user->getKey(), 'role_id' => $role->id,
                    'status' => 'active', 'invited_by' => $this->ctx->user()->getKey(),
                ])->save();
            }
            $this->audit->log('member.added', $user, ['role' => $role->key, 'existing_identity' => $existed]);

            return [$user, $existed];
        });
    }

    /** نقشی که کاربر جاری اجازهٔ دادنش را دارد (ضد ارتقای مجوز) */
    public function assignableRole(int $roleId): Role
    {
        $role = Role::forWorkspace($this->ctx->workspaceId())->with('permissions')->find($roleId);
        if (! $role) {
            throw new SazehException('فقط نقش‌های همین فضای کاری قابل انتخاب است.');
        }
        if ($role->grants_all || $role->is_system) {
            throw SazehException::forbidden('نقش مالک قابل واگذاری نیست؛ از «انتقال مالکیت» استفاده کنید.');
        }
        $mine = $this->ctx->role();
        if (! $mine->grants_all && array_diff($role->permissionKeys(), $mine->permissionKeys()) !== []) {
            throw SazehException::forbidden('نمی‌توانید نقشی با مجوز بیشتر از خودتان بدهید.');
        }

        return $role;
    }

    /** @return \Illuminate\Support\Collection<int,Role> */
    public function assignableRoles()
    {
        return Role::forWorkspace($this->ctx->workspaceId())->with('permissions')->orderBy('id')->get()
            ->filter(function (Role $r) {
                try {
                    $this->assignableRole($r->id);

                    return true;
                } catch (SazehException) {
                    return false;
                }
            })->values();
    }
}
