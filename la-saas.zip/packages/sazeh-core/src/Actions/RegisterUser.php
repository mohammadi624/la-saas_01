<?php

namespace Sazeh\Core\Actions;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Exceptions\SazehException;
use Sazeh\Core\Models\Membership;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Models\Workspace;

/** ثبت‌نام عمومی (برای سایت‌هایی که برای همه باز است) */
class RegisterUser
{
    public function __construct(
        private readonly ResolveIdentity $identity,
        private readonly CreateWorkspace $createWorkspace,
        private readonly AuditLogger $audit,
    ) {
    }

    public function handle(array $data): Authenticatable
    {
        if (config('sazeh.registration.mode') !== 'public') {
            throw SazehException::forbidden('ثبت‌نام در این سایت فعال نیست.');
        }

        return DB::transaction(function () use ($data) {
            [$user, $existed] = $this->identity->handle($data);
            if ($existed) {
                // پیام عمومی؛ وجود حساب افشا نمی‌شود
                throw new SazehException('ثبت‌نام انجام نشد. اگر قبلاً حساب داشته‌اید وارد شوید.');
            }

            if (config('sazeh.registration.on_register') === 'own_workspace' && config('sazeh.tenancy') === 'multi') {
                $base = Str::slug((string) ($data['workspace_name'] ?? '')) ?: 'ws';
                $slug = preg_match('/^[a-z]/', $base) ? $base : 'ws-'.$base;
                $slug = mb_substr($slug, 0, 40).'-'.Str::lower(Str::random(5));
                $this->createWorkspace->handle($user, (string) ($data['workspace_name'] ?? $user->name), $slug, null, $user);
            } else {
                $ws = Workspace::where('slug', config('sazeh.default_workspace.slug'))->first();
                $role = Role::where('panel', 'workspace')->whereNull('workspace_id')
                    ->where('key', config('sazeh.registration.default_role', 'member'))->first();
                if (! $ws || ! $role || $role->grants_all) {
                    throw new SazehException('فضای پیش‌فرض یا نقش پیش‌فرض تنظیم نشده است (php artisan sazeh:install).', 500);
                }
                (new Membership)->forceFill(['workspace_id' => $ws->id, 'user_id' => $user->getKey(), 'role_id' => $role->id, 'status' => 'active'])->save();
            }
            $this->audit->log('identity.registered', $user, [], $user->getKey());

            return $user;
        });
    }
}
