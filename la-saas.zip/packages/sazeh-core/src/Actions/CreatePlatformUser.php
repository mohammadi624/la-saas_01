<?php

namespace Sazeh\Core\Actions;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Sazeh\Core\Access\Gatekeeper;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Exceptions\SazehException;
use Sazeh\Core\Menu\MenuService;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Tenancy\CurrentContext;

/** کاربری که مدیر پلتفرم اضافه می‌کند زیرمجموعهٔ تیم پلتفرم است (نقش پلتفرم، بدون عضویت در فضا). */
class CreatePlatformUser
{
    public function __construct(
        private readonly ResolveIdentity $identity,
        private readonly CurrentContext $ctx,
        private readonly Gatekeeper $gate,
        private readonly AuditLogger $audit,
    ) {
    }

    /** @return array{0:Authenticatable,1:bool} */
    public function handle(array $data): array
    {
        if ($this->ctx->panel() !== 'platform' || ! $this->gate->allows('users.manage')) {
            throw SazehException::forbidden('فقط مدیران پلتفرم می‌توانند کاربر تیم اضافه کنند.');
        }
        $role = Role::where('panel', 'platform')->find($data['role_id'] ?? 0);
        if (! $role) {
            throw new SazehException('فقط نقش‌های پلتفرم قابل انتخاب است.');
        }
        if ($role->grants_all && ! $this->ctx->role()?->grants_all) {
            throw SazehException::forbidden('نقش مدیر کل را فقط مدیر کل می‌تواند بدهد.');
        }

        return DB::transaction(function () use ($data, $role) {
            [$user, $existed] = $this->identity->handle($data, $this->ctx->user());
            if ($existed && $user->platform_role_id) {
                throw SazehException::conflict('این شخص از قبل عضو تیم پلتفرم است.');
            }
            $user->forceFill(['platform_role_id' => $role->id])->save();
            $this->audit->log('platform.user_added', $user, ['role' => $role->key, 'existing_identity' => $existed]);
            MenuService::bump();

            return [$user, $existed];
        });
    }
}
