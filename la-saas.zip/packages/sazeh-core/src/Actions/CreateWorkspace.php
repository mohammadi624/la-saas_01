<?php

namespace Sazeh\Core\Actions;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Exceptions\SazehException;
use Sazeh\Core\Models\Membership;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Models\Workspace;
use Sazeh\Core\Modules\CoreModule;

/** ساخت فضای کاری و عضویت مالک (خریدار جدید، ثبت‌نام خودخدمت، یا فضای پیش‌فرض نصب) */
class CreateWorkspace
{
    public function __construct(private readonly AuditLogger $audit)
    {
    }

    public function handle(Authenticatable $owner, string $name, string $slug, ?int $planId = null, ?Authenticatable $actor = null): Workspace
    {
        $name = trim($name);
        $slug = mb_strtolower(trim($slug));
        if ($name === '') {
            throw new SazehException('نام فضای کاری الزامی است.');
        }
        if (! preg_match('/^[a-z][a-z0-9-]{2,59}$/', $slug)) {
            throw new SazehException('نامک فقط حروف کوچک لاتین، عدد و خط تیره (حداقل ۳ نویسه).');
        }
        if (Workspace::withTrashed()->where('slug', $slug)->exists()) {
            throw SazehException::conflict('این نامک قبلاً استفاده شده است.');
        }
        $ownerKey = CoreModule::ownerRoleKey();
        $ownerRole = Role::where('panel', 'workspace')->whereNull('workspace_id')->where('key', $ownerKey)->first();
        if (! $ownerRole) {
            throw new SazehException("نقش «{$ownerKey}» یافت نشد؛ ابتدا php artisan sazeh:sync را اجرا کنید.", 500);
        }

        return DB::transaction(function () use ($owner, $name, $slug, $planId, $ownerRole, $actor) {
            $ws = new Workspace(['name' => $name, 'slug' => $slug]);
            $ws->forceFill(['owner_id' => $owner->getKey(), 'plan_id' => $planId, 'status' => 'active'])->save();
            (new Membership)->forceFill([
                'workspace_id' => $ws->id, 'user_id' => $owner->getKey(), 'role_id' => $ownerRole->id,
                'status' => 'active', 'invited_by' => $actor?->getKey(),
            ])->save();
            $this->audit->log('workspace.created', $ws, ['owner_id' => $owner->getKey()], $actor?->getKey(), $ws->id);
            event(new \Sazeh\Core\Events\WorkspaceCreated($ws, $owner, $actor));

            return $ws;
        });
    }
}
