<?php

namespace Sazeh\Core\Actions;

use Sazeh\Core\Access\Gatekeeper;
use Sazeh\Core\Audit\AuditLogger;
use Sazeh\Core\Exceptions\SazehException;
use Sazeh\Core\Models\Membership;
use Sazeh\Core\Tenancy\CurrentContext;

/** تغییر نقش، تعلیق/فعال‌سازی و حذف عضو — فقط داخل فضای جاری */
class ChangeMembership
{
    public function __construct(
        private readonly CurrentContext $ctx,
        private readonly Gatekeeper $gate,
        private readonly AddWorkspaceMember $add,
        private readonly AuditLogger $audit,
    ) {
    }

    public function handle(int $membershipId, array $change): void
    {
        $ws = $this->ctx->workspace();
        // عضو فضای دیگر = 404 (وجودش افشا نمی‌شود)
        $m = $ws ? Membership::where('workspace_id', $ws->id)->find($membershipId) : null;
        if (! $m) {
            throw SazehException::notFound('عضو یافت نشد.');
        }
        $d = $this->gate->decide('members.manage');
        if (! $d->allowed) {
            throw SazehException::forbidden($d->message());
        }
        if ((int) $m->user_id === (int) $this->ctx->user()->getKey()) {
            throw SazehException::forbidden('نقش یا وضعیت خودتان را نمی‌توانید تغییر دهید.');
        }
        if ($ws->isOwnedBy($m->user)) {
            throw SazehException::forbidden('مالک فضای کاری قابل تغییر نیست.');
        }

        if (isset($change['role_id'])) {
            $role = $this->add->assignableRole((int) $change['role_id']);
            $m->forceFill(['role_id' => $role->id])->save();
            $this->audit->log('member.role_changed', $m, ['role' => $role->key]);
        }
        if (isset($change['status'])) {
            if (! in_array($change['status'], ['active', 'suspended'], true)) {
                throw new SazehException('وضعیت نامعتبر است.');
            }
            $m->forceFill(['status' => $change['status']])->save();
            $this->audit->log('member.status_changed', $m, ['status' => $change['status']]);
        }
        if (! empty($change['remove'])) {
            $m->delete(); // فقط عضویت؛ هویت و عضویت‌های دیگر باقی می‌ماند
            $this->audit->log('member.removed', $m);
        }
    }
}
