<?php

namespace Sazeh\Core\Actions;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\Hash;
use Sazeh\Core\Exceptions\SazehException;
use Sazeh\Core\Support\Identifier;

/**
 * هویت سراسری است: اگر موبایل یا ایمیل قبلاً ثبت شده، همان شخص برگردانده می‌شود
 * و حساب تکراری ساخته نمی‌شود.
 */
class ResolveIdentity
{
    /** @return array{0:Authenticatable,1:bool} [کاربر، آیا از قبل وجود داشت] */
    public function handle(array $data, ?Authenticatable $creator = null): array
    {
        $model = config('sazeh.user_model');
        $mobile = Identifier::normalizeMobile((string) ($data['mobile'] ?? ''));
        if (! $mobile) {
            throw new SazehException('شمارهٔ موبایل معتبر نیست.');
        }
        $email = trim((string) ($data['email'] ?? '')) !== '' ? mb_strtolower(trim($data['email'])) : null;
        if ($email !== null && ! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new SazehException('ایمیل معتبر نیست.');
        }

        $byMobile = $model::where('mobile', $mobile)->first();
        $byEmail = $email ? $model::where('email', $email)->first() : null;
        if ($byMobile && $byEmail && $byMobile->getKey() !== $byEmail->getKey()) {
            throw SazehException::conflict('این موبایل و ایمیل متعلق به دو شخص متفاوت‌اند.');
        }
        if ($existing = $byMobile ?? $byEmail) {
            return [$existing, true];
        }

        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new SazehException('نام الزامی است.');
        }
        $password = (string) ($data['password'] ?? '');
        if (mb_strlen($password) < (int) config('sazeh.password_min', 8)) {
            throw new SazehException('رمز عبور باید حداقل '.config('sazeh.password_min', 8).' نویسه باشد.');
        }

        $user = new $model;
        $user->forceFill([
            'name' => $name,
            'email' => $email,
            'mobile' => $mobile,
            'password' => Hash::make($password),
            'status' => 'active',
        ])->save();

        return [$user, false];
    }
}
