<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** صفحه‌های HTML آپلودی از منوساز (بدون کدنویسی). فقط افزایشی. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('core_html_pages', function (Blueprint $t) {
            $t->id();
            $t->string('panel', 20);
            $t->string('original_name')->nullable();
            $t->longText('content');
            $t->unsignedInteger('size')->default(0);
            $t->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });

        Schema::table('core_menu_items', function (Blueprint $t) {
            $t->foreignId('html_page_id')->nullable()->after('url')->constrained('core_html_pages')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('core_menu_items', fn (Blueprint $t) => $t->dropConstrainedForeignId('html_page_id'));
        Schema::dropIfExists('core_html_pages');
    }
};
