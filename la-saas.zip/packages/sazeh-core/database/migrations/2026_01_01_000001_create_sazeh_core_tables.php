<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * جداول هسته. همه با پیشوند core_ تا با جداول موجود پروژه (مثل roles) تداخل نکنند.
 * فقط افزایشی است: هیچ جدول یا ستون موجودی حذف یا تغییر نام داده نمی‌شود.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('users')) {
            throw new RuntimeException('جدول users وجود ندارد. ابتدا Migration جدول users (مثلاً 0001_01_01_000000_create_users_table) را بسازید و اجرا کنید.');
        }

        Schema::create('core_roles', function (Blueprint $t) {
            $t->id();
            $t->string('panel', 20);                       // platform | workspace
            $t->unsignedBigInteger('workspace_id')->nullable(); // null = نقش قالب، مشترک بین همهٔ فضاها
            $t->unsignedBigInteger('scope_key')->default(0);    // = workspace_id ?? 0 (برای یکتایی؛ NULL در UNIQUE یکتا نیست)
            $t->string('key', 60);
            $t->string('title');
            $t->string('description')->nullable();
            $t->boolean('grants_all')->default(false);
            $t->boolean('is_system')->default(false);
            $t->string('start_route')->nullable();
            $t->string('module', 60)->nullable();
            $t->timestamps();
            $t->unique(['panel', 'scope_key', 'key']);
            $t->index('workspace_id');
        });

        Schema::create('core_permissions', function (Blueprint $t) {
            $t->id();
            $t->string('key', 100)->unique();
            $t->string('panel', 20);
            $t->string('label');
            $t->string('module', 60)->nullable();
            $t->string('feature', 60)->nullable();
            $t->boolean('is_write')->default(false);
            $t->timestamp('orphaned_at')->nullable();      // در کد دیگر تعریف نشده
            $t->timestamps();
        });

        Schema::create('core_role_permission', function (Blueprint $t) {
            $t->foreignId('role_id')->constrained('core_roles')->cascadeOnDelete();
            $t->foreignId('permission_id')->constrained('core_permissions')->cascadeOnDelete();
            $t->primary(['role_id', 'permission_id']);
        });

        Schema::create('core_plans', function (Blueprint $t) {
            $t->id();
            $t->string('key', 60)->unique();
            $t->string('title');
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::create('core_plan_features', function (Blueprint $t) {
            $t->id();
            $t->foreignId('plan_id')->constrained('core_plans')->cascadeOnDelete();
            $t->string('feature', 60);
            $t->boolean('enabled')->default(true);
            $t->unsignedInteger('limit_value')->default(0);
            $t->boolean('is_unlimited')->default(false);
            $t->unique(['plan_id', 'feature']);
        });

        Schema::create('core_workspaces', function (Blueprint $t) {
            $t->id();
            $t->uuid('uuid')->unique();
            $t->string('name');
            $t->string('slug', 60)->unique();
            $t->foreignId('owner_id')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('plan_id')->nullable()->constrained('core_plans')->nullOnDelete();
            $t->string('status', 20)->default('active'); // active | grace | read_only | suspended
            $t->json('settings')->nullable();
            $t->timestamps();
            $t->softDeletes();
        });

        Schema::create('core_memberships', function (Blueprint $t) {
            $t->id();
            $t->foreignId('workspace_id')->constrained('core_workspaces')->cascadeOnDelete();
            $t->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('role_id')->constrained('core_roles')->restrictOnDelete();
            $t->string('status', 20)->default('active');  // active | suspended
            $t->foreignId('invited_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
            $t->softDeletes();
            $t->unique(['workspace_id', 'user_id']);
            $t->index(['user_id', 'status']);
        });

        Schema::create('core_menu_items', function (Blueprint $t) {
            $t->id();
            $t->string('panel', 20);
            $t->string('key', 100)->nullable();            // آیتم‌های تعریف‌شده در ماژول‌ها
            $t->foreignId('parent_id')->nullable()->constrained('core_menu_items')->nullOnDelete();
            $t->string('title');
            $t->string('icon', 30)->default('file');
            $t->string('type', 20)->default('page');      // page | group | external
            $t->string('route')->nullable();               // نام Route برای type=page
            $t->string('url', 500)->nullable();            // فقط برای type=external
            $t->string('permission', 100)->nullable();     // اگر خالی باشد، مجوز صفحه از رجیستری
            $t->boolean('new_tab')->default(false);
            $t->boolean('is_active')->default(true);
            $t->boolean('is_system')->default(false);
            $t->integer('sort')->default(0);
            $t->string('module', 60)->nullable();
            $t->timestamps();
            $t->softDeletes();
            $t->unique(['panel', 'key']);
            $t->index(['panel', 'parent_id', 'sort']);
        });

        Schema::create('core_menu_item_role', function (Blueprint $t) {
            $t->foreignId('menu_item_id')->constrained('core_menu_items')->cascadeOnDelete();
            $t->foreignId('role_id')->constrained('core_roles')->cascadeOnDelete();
            $t->primary(['menu_item_id', 'role_id']);
        });

        Schema::create('core_settings', function (Blueprint $t) {
            $t->id();
            $t->string('scope', 40)->default('platform');  // platform | ws:{id}
            $t->string('key', 100);
            $t->json('value')->nullable();
            $t->timestamps();
            $t->unique(['scope', 'key']);
        });

        Schema::create('core_audit_logs', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('workspace_id')->nullable();
            $t->unsignedBigInteger('actor_id')->nullable();
            $t->string('action', 80);
            $t->string('subject_type', 120)->nullable();
            $t->unsignedBigInteger('subject_id')->nullable();
            $t->json('meta')->nullable();                  // هرگز رمز، OTP یا توکن
            $t->string('ip', 45)->nullable();
            $t->string('user_agent')->nullable();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['workspace_id', 'created_at']);
            $t->index(['actor_id', 'created_at']);
            $t->index(['action', 'created_at']);
        });

        Schema::create('core_otp_codes', function (Blueprint $t) {
            $t->id();
            $t->string('target', 40);                      // موبایل نرمال‌شده
            $t->string('purpose', 20)->default('login');
            $t->string('code_hash');
            $t->unsignedTinyInteger('attempts')->default(0);
            $t->timestamp('expires_at');
            $t->timestamp('consumed_at')->nullable();
            $t->string('ip', 45)->nullable();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['target', 'purpose']);
        });

        // ستون‌های لازم روی users — فقط اگر وجود ندارند
        Schema::table('users', function (Blueprint $t) {
            if (! Schema::hasColumn('users', 'mobile')) {
                $t->string('mobile', 20)->nullable()->unique();
            }
            if (! Schema::hasColumn('users', 'username')) {
                $t->string('username', 50)->nullable()->unique();
            }
            if (! Schema::hasColumn('users', 'status')) {
                $t->string('status', 20)->default('active');
            }
            if (! Schema::hasColumn('users', 'platform_role_id')) {
                $t->foreignId('platform_role_id')->nullable()->constrained('core_roles')->nullOnDelete();
            }
            if (! Schema::hasColumn('users', 'last_login_at')) {
                $t->timestamp('last_login_at')->nullable();
            }
            if (! Schema::hasColumn('users', 'last_login_ip')) {
                $t->string('last_login_ip', 45)->nullable();
            }
        });

        // ثبت‌نام با موبایل بدون ایمیل: ایمیل اختیاری شود (فقط سهل‌تر کردن قید؛ داده‌ای تغییر نمی‌کند)
        $email = collect(Schema::getColumns('users'))->firstWhere('name', 'email');
        if ($email && ! $email['nullable']) {
            Schema::table('users', fn (Blueprint $t) => $t->string('email')->nullable()->change());
        }
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $t) {
            if (Schema::hasColumn('users', 'platform_role_id')) {
                $t->dropConstrainedForeignId('platform_role_id');
            }
        });
        // ستون‌های mobile/username/status/last_login_* عمداً حذف نمی‌شوند (ممکن است داده داشته باشند)
        foreach (['core_otp_codes', 'core_audit_logs', 'core_settings', 'core_menu_item_role', 'core_menu_items',
            'core_memberships', 'core_workspaces', 'core_plan_features', 'core_plans', 'core_role_permission',
            'core_permissions', 'core_roles'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
