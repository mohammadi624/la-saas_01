<?php

return [

    /*
    | مدل کاربر پروژه. باید Trait «Sazeh\Core\Concerns\HasSazehAccess» را داشته باشد.
    */
    'user_model' => env('SAZEH_USER_MODEL', 'App\\Models\\User'),

    /*
    | حالت فضای کاری:
    |  single → یک سایت/سازمان؛ یک فضای پیش‌فرض، بدون انتخاب فضا (سایت شرکتی، انجمن، سایت عمومی)
    |  multi  → چندمستاجری؛ هر خریدار/مشتری فضای خودش را دارد (SaaS)
    */
    'tenancy' => env('SAZEH_TENANCY', 'single'),

    /*
    | نقش مالک هر فضای کاری (مثلاً «خریدار اشتراک»). کلید پس از نصب فقط همراه با
    | به‌روزرسانی ردیف core_roles تغییر کند (راهنما در README).
    */
    'workspace_owner_role' => [
        'key' => env('SAZEH_OWNER_ROLE_KEY', 'owner'),
        'title' => env('SAZEH_OWNER_ROLE_TITLE', 'مالک'),
    ],

    'default_workspace' => [
        'name' => env('SAZEH_DEFAULT_WORKSPACE_NAME', env('APP_NAME', 'سایت من')),
        'slug' => env('SAZEH_DEFAULT_WORKSPACE_SLUG', 'main'),
    ],

    /*
    | اشتراک و پلن. اگر خاموش باشد همهٔ قابلیت‌ها آزاد و ظرفیت کاربران طبق «seats» است.
    */
    'billing' => [
        'enabled' => (bool) env('SAZEH_BILLING', false),
        // مجوزهایی که مالک در اشتراک معلق هنوز دارد (صفحهٔ تمدید و پرداخت)
        'allowed_when_suspended' => ['billing.view'],
    ],

    // ظرفیت کاربران هر فضا وقتی اشتراک خاموش است. unlimited=true یعنی بدون سقف.
    'seats' => [
        'unlimited' => (bool) env('SAZEH_SEATS_UNLIMITED', true),
        'limit' => (int) env('SAZEH_SEATS_LIMIT', 0),
    ],

    /*
    | ثبت‌نام عمومی (برای سایت‌هایی که برای همه قابل دسترسی‌اند)
    |  mode:        public | disabled
    |  on_register: default_workspace → عضو فضای پیش‌فرض سایت با نقش default_role
    |               own_workspace     → برای هر ثبت‌نام‌کننده فضای کاری جدید و مالکیت آن (SaaS خودخدمت)
    */
    'registration' => [
        'mode' => env('SAZEH_REGISTRATION', 'disabled'),
        'on_register' => env('SAZEH_ON_REGISTER', 'default_workspace'),
        'default_role' => 'member',
        'require_email' => false,
    ],

    'login' => [
        'password' => true,
        'otp' => (bool) env('SAZEH_OTP', true),
        'max_attempts' => 5,
        'lock_minutes' => 15,
    ],

    'otp' => [
        'length' => 6,
        'ttl_seconds' => 120,
        'max_attempts' => 5,
        'max_sends' => 3,
        'send_window_seconds' => 600,
    ],

    'password_min' => 8,

    'sms' => [
        // log → کد در storage/logs/laravel.log نوشته می‌شود (فقط توسعه)
        // برای محیط واقعی کلاس خودتان را که SmsGateway را پیاده می‌کند بدهید
        'driver' => env('SAZEH_SMS_DRIVER', 'log'),
    ],

    /*
    | پنل‌ها: یک داشبورد با دو مجموعه‌منو. عنوان، رنگ و پیشوند آدرس قابل تغییر است.
    */
    'panels' => [
        'platform' => [
            'title' => env('SAZEH_PLATFORM_TITLE', 'پنل مدیریت'),
            'owner_label' => env('SAZEH_PLATFORM_OWNER_LABEL', 'مالک سایت'),           // صاحب این پنل
            'members_label' => env('SAZEH_PLATFORM_MEMBERS_LABEL', 'کاربران مالک سایت'), // کاربرانی که او تعریف می‌کند
            'prefix' => 'admin', 'color' => '#3157c8', 'sidebar' => '#141d3b',
        ],
        'workspace' => [
            'title' => env('SAZEH_WORKSPACE_TITLE', 'پنل کاربری'),
            'owner_label' => env('SAZEH_WORKSPACE_OWNER_LABEL', 'خریدار اشتراک'),
            'members_label' => env('SAZEH_WORKSPACE_MEMBERS_LABEL', 'کاربران خریدار اشتراک'),
            'prefix' => 'panel', 'color' => '#0f766e', 'sidebar' => '#0c2b2a',
        ],
    ],

    'route_middleware' => ['web'],

    // دامنه‌های مجاز برای آیتم منوی لینک خارجی
    'external_link_domains' => [],

    /*
    | ماژول‌ها. ماژول‌های پروژه را اینجا اضافه کنید و سپس php artisan sazeh:sync
    */
    'modules' => [
        Sazeh\Core\Modules\CoreModule::class,
    ],

    /*
    | صفحه‌های فایلی: هر فایل Blade در resources/views/pages/{platform|workspace}/
    | یک صفحهٔ داشبورد با آدرس، مجوز و آیتم منو می‌شود.  ساخت:  php artisan sazeh:page
    */
    'file_pages' => [
        'enabled' => true,
        'path' => resource_path('views/pages'),
        // صفحهٔ فایلی بدون آیتم منوی فعال بسته است (حتی با داشتن مجوز). false = فقط مجوز ملاک است.
        'require_menu' => env('SAZEH_PAGES_REQUIRE_MENU', true),
    ],

    /*
    | ماژول اشتراک‌ها و سایت‌ها (SAZEH_SUBSCRIPTIONS=true)
    | چرخهٔ وضعیت: فعال ← (پایان اشتراک) مهلت پرداخت ← فقط‌خواندنی ← معلق
    */
    'subscriptions' => [
        'currency' => env('SAZEH_CURRENCY', 'تومان'),
        'trial_days' => (int) env('SAZEH_TRIAL_DAYS', 0),       // ۰ = بدون دورهٔ آزمایشی
        'grace_days' => (int) env('SAZEH_GRACE_DAYS', 3),
        'read_only_days' => (int) env('SAZEH_READ_ONLY_DAYS', 7),
        // فضای کاری بدون هیچ اشتراکی معلق شود؟ (برای وقتی که ثبت‌نام عمومی است و فقط با خرید فعال می‌شود)
        'require_subscription' => (bool) env('SAZEH_REQUIRE_SUBSCRIPTION', false),
        'periods' => [
            'monthly' => ['title' => 'ماهانه', 'months' => 1],
            'quarterly' => ['title' => 'سه‌ماهه', 'months' => 3],
            'semiannual' => ['title' => 'شش‌ماهه', 'months' => 6],
            'yearly' => ['title' => 'سالانه', 'months' => 12],
        ],
        'payment_methods' => ['card' => 'کارت‌به‌کارت', 'transfer' => 'انتقال بانکی', 'cash' => 'نقدی', 'other' => 'سایر'],
    ],

    'menu_icons' => ['home', 'grid', 'globe', 'folder', 'file', 'list', 'users', 'card', 'chart', 'chat', 'shield', 'key', 'gear', 'lock', 'flag', 'box', 'menu', 'edit'],
];
