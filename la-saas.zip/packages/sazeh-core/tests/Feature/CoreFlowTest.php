<?php

namespace Sazeh\Core\Tests\Feature;

use Sazeh\Core\Menu\MenuService;
use Sazeh\Core\Models\MenuItem;
use Sazeh\Core\Models\Membership;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Models\Workspace;
use Sazeh\Core\Tests\Fixtures\User;
use Sazeh\Core\Tests\TestCase;

class CoreFlowTest extends TestCase
{
    private function role(string $panel, string $key): Role
    {
        return Role::where('panel', $panel)->whereNull('workspace_id')->where('key', $key)->firstOrFail();
    }

    /** مدیر کل یک خریدار می‌سازد و برمی‌گرداند */
    private function makeBuyer(string $slug = 'aftab', string $mobile = '09123333333'): Workspace
    {
        $this->actingAs($this->admin())->withSession(['sazeh.context' => 'platform']);
        $this->get('/admin')->assertOk();
        $this->post('/admin/workspaces', ['ws_name' => 'فروشگاه '.$slug, 'slug' => $slug, 'name' => 'خریدار '.$slug,
            'mobile' => $mobile, 'password' => 'Buyer@1234'])->assertSessionHasNoErrors();
        $this->logout();

        return Workspace::where('slug', $slug)->firstOrFail();
    }

    public function test_install_creates_admin_and_default_workspace(): void
    {
        $this->assertTrue($this->admin()->platformRole->grants_all);
        $this->assertTrue(Workspace::where('slug', 'main')->exists());
        $this->artisan('sazeh:sync')->assertSuccessful(); // اجرای دوباره بی‌خطر
        $this->assertSame(1, Role::where('panel', 'platform')->where('key', 'admin')->count());
    }

    public function test_admin_logs_in_with_persian_digits_and_lands_on_role_start_page(): void
    {
        // مدیر کل هم عضو فضای main است ← دو بخش ← صفحهٔ انتخاب
        $this->loginAs('۰۹۱۲۱۱۱۱۱۱۱', 'Admin@1234')->assertRedirect(route('sazeh.context.pick'));
        $this->post('/context', ['context' => 'platform'])->assertRedirect(route('sazeh.platform.dashboard'));
        $this->get('/admin')->assertOk()->assertSee('مدیریت منوها');
    }

    public function test_wrong_password_and_unknown_user_get_same_message_and_lock_after_five(): void
    {
        $a = $this->loginAs('09121111111', 'wrong')->assertSessionHasErrors('identifier');
        $msgA = explode(' (', session('errors')->first('identifier'))[0];
        $this->loginAs('09129999999', 'wrong');
        $msgB = explode(' (', session('errors')->first('identifier'))[0];
        $this->assertSame($msgA, $msgB);

        for ($i = 0; $i < 4; $i++) {
            $this->loginAs('09121111111', 'wrong');
        }
        $this->loginAs('09121111111', 'Admin@1234')->assertSessionHasErrors('identifier');
        $this->assertStringContainsString('مسدود', session('errors')->first('identifier'));
        $this->assertGuest();
    }

    public function test_otp_login_is_single_use(): void
    {
        $this->post('/login/otp', ['mobile' => '+989121111111'])->assertRedirect(route('sazeh.login.otp.form'));
        $code = $this->sms->lastCode();
        $this->assertNotNull($code);
        $this->post('/login/otp/verify', ['code' => '000000' === $code ? '111111' : '000000'])->assertSessionHasErrors('code');
        $this->post('/login/otp/verify', ['code' => $code])->assertRedirect();
        $this->assertAuthenticated();
        $this->logout();
        $this->withSession(['sazeh.otp_mobile' => '09121111111'])->post('/login/otp/verify', ['code' => $code])->assertSessionHasErrors('code');
    }

    public function test_otp_response_is_identical_for_unknown_number(): void
    {
        $this->post('/login/otp', ['mobile' => '09120000000'])->assertRedirect(route('sazeh.login.otp.form'));
        $this->assertSame([], $this->sms->sent);
    }

    public function test_platform_user_created_by_admin_belongs_to_platform_team_only(): void
    {
        $this->actingAs($this->admin())->withSession(['sazeh.context' => 'platform']);
        $staff = $this->role('platform', 'staff');
        $this->post('/admin/users', ['name' => 'نگار', 'mobile' => '09122222222', 'password' => 'Staff@1234', 'role_id' => $staff->id])->assertSessionHasNoErrors();
        $this->logout();

        $u = User::where('mobile', '09122222222')->firstOrFail();
        $this->assertSame($staff->id, (int) $u->platform_role_id);
        $this->assertSame(0, Membership::where('user_id', $u->id)->count());

        $this->loginAs('09122222222', 'Staff@1234')->assertRedirect(route('sazeh.platform.dashboard'));
        $this->get('/admin/menus')->assertForbidden();      // کارمند پلتفرم مجوز منو ندارد
        $this->get('/panel')->assertForbidden();             // صفحهٔ پنل دیگر
    }

    public function test_buyer_adds_member_under_own_workspace_and_member_lands_on_panel(): void
    {
        $ws = $this->makeBuyer();
        $this->loginAs('09123333333', 'Buyer@1234')->assertRedirect(route('sazeh.workspace.dashboard'));

        $manager = $this->role('workspace', 'manager');
        $this->post('/panel/members', ['name' => 'مریم', 'mobile' => '09124444444', 'password' => 'Member@1234', 'role_id' => $manager->id])
            ->assertSessionHasNoErrors();
        $this->logout();

        $u = User::where('mobile', '09124444444')->firstOrFail();
        $this->assertNull($u->platform_role_id);
        $this->assertTrue(Membership::where('user_id', $u->id)->where('workspace_id', $ws->id)->exists());

        $this->loginAs('09124444444', 'Member@1234')->assertRedirect(route('sazeh.workspace.dashboard'));
        $this->get('/panel/members')->assertOk()->assertSee('مریم');
        $this->get('/admin')->assertForbidden();
    }

    public function test_buyer_cannot_assign_owner_role(): void
    {
        $this->makeBuyer();
        $this->loginAs('09123333333', 'Buyer@1234');
        $owner = $this->role('workspace', 'owner');
        $this->post('/panel/members', ['name' => 'x', 'mobile' => '09124444444', 'password' => 'Member@1234', 'role_id' => $owner->id])
            ->assertSessionHasErrors('form');
        $this->assertFalse(User::where('mobile', '09124444444')->exists());
    }

    public function test_member_without_manage_permission_cannot_add_users(): void
    {
        $this->makeBuyer();
        $this->loginAs('09123333333', 'Buyer@1234');
        $member = $this->role('workspace', 'member');
        $this->post('/panel/members', ['name' => 'عضو', 'mobile' => '09124444444', 'password' => 'Member@1234', 'role_id' => $member->id]);
        $this->logout();
        $this->loginAs('09124444444', 'Member@1234');
        $this->post('/panel/members', ['name' => 'x', 'mobile' => '09125555555', 'password' => 'Member@1234', 'role_id' => $member->id])->assertForbidden();
    }

    public function test_workspace_isolation_returns_404_for_foreign_membership(): void
    {
        $a = $this->makeBuyer('aftab', '09123333333');
        $b = $this->makeBuyer('mehr', '09125555555');
        $foreign = Membership::where('workspace_id', $b->id)->firstOrFail();
        $this->loginAs('09123333333', 'Buyer@1234');
        $this->put('/panel/members/'.$foreign->id, ['status' => 'suspended'])->assertNotFound();
        $this->assertSame('active', $foreign->fresh()->status);
    }

    public function test_existing_identity_is_attached_not_duplicated(): void
    {
        $this->makeBuyer('aftab', '09123333333');
        $this->makeBuyer('mehr', '09125555555');
        $count = User::count();
        $this->loginAs('09125555555', 'Buyer@1234');
        $this->post('/panel/members', ['mobile' => '+989123333333', 'role_id' => $this->role('workspace', 'member')->id])->assertSessionHasNoErrors();
        $this->assertSame($count, User::count());
        $this->logout();
        // حالا عضو دو فضاست ← صفحهٔ انتخاب
        $this->loginAs('09123333333', 'Buyer@1234')->assertRedirect(route('sazeh.context.pick'));
    }

    public function test_seat_limit_is_enforced_when_billing_is_off(): void
    {
        config(['sazeh.seats.unlimited' => false, 'sazeh.seats.limit' => 1]);
        $this->makeBuyer();
        $this->loginAs('09123333333', 'Buyer@1234');
        $member = $this->role('workspace', 'member')->id;
        $this->post('/panel/members', ['name' => 'a', 'mobile' => '09124444441', 'password' => 'Member@1234', 'role_id' => $member])->assertSessionHasNoErrors();
        $this->post('/panel/members', ['name' => 'b', 'mobile' => '09124444442', 'password' => 'Member@1234', 'role_id' => $member])->assertSessionHasErrors('form');
    }

    public function test_suspended_workspace_blocks_members_but_owner_can_enter(): void
    {
        $ws = $this->makeBuyer();
        $this->loginAs('09123333333', 'Buyer@1234');
        $this->post('/panel/members', ['name' => 'a', 'mobile' => '09124444444', 'password' => 'Member@1234', 'role_id' => $this->role('workspace', 'manager')->id]);
        $this->logout();
        $ws->forceFill(['status' => 'suspended'])->save();

        $this->loginAs('09124444444', 'Member@1234')->assertRedirect(route('sazeh.login'));
        $this->assertGuest();
        $this->loginAs('09123333333', 'Buyer@1234');
        $this->assertAuthenticated();
        $this->get('/panel/members')->assertForbidden();
        $this->get('/account/security')->assertOk();         // صفحهٔ حساب همیشه باز است
    }

    public function test_deactivated_identity_is_logged_out_on_next_request(): void
    {
        $this->makeBuyer();
        $this->loginAs('09123333333', 'Buyer@1234');
        User::where('mobile', '09123333333')->update(['status' => 'inactive']);
        $this->get('/panel')->assertRedirect(route('sazeh.login'));
        $this->assertGuest();
    }

    public function test_public_registration_joins_default_workspace(): void
    {
        config(['sazeh.registration.mode' => 'public', 'sazeh.registration.on_register' => 'default_workspace']);
        $this->post('/register', ['name' => 'بازدیدکننده', 'mobile' => '09127777777', 'password' => 'Visitor@123', 'password_confirmation' => 'Visitor@123'])
            ->assertRedirect(route('sazeh.workspace.dashboard'));
        $u = User::where('mobile', '09127777777')->firstOrFail();
        $m = Membership::with('role', 'workspace')->where('user_id', $u->id)->firstOrFail();
        $this->assertSame('main', $m->workspace->slug);
        $this->assertSame('member', $m->role->key);
    }

    public function test_registration_disabled_by_default(): void
    {
        $this->get('/register')->assertNotFound();
        $this->post('/register', ['name' => 'x', 'mobile' => '09127777777', 'password' => 'Visitor@123', 'password_confirmation' => 'Visitor@123'])->assertNotFound();
    }

    public function test_open_redirect_is_ignored_and_valid_intended_is_honored(): void
    {
        $this->makeBuyer();
        $this->withSession(['url.intended' => '//evil.com/x'])->loginAs('09123333333', 'Buyer@1234')
            ->assertRedirect(route('sazeh.workspace.dashboard'));
        $this->logout();
        $this->get('/panel/members')->assertRedirect(route('sazeh.login'));
        $this->loginAs('09123333333', 'Buyer@1234')->assertRedirect(route('sazeh.workspace.members'));
    }

    public function test_disabled_menu_item_is_hidden(): void
    {
        $item = MenuItem::where('panel', 'workspace')->where('key', 'w.members')->firstOrFail();
        $item->forceFill(['is_active' => false])->save();
        MenuService::bump();
        $this->makeBuyer();
        $this->loginAs('09123333333', 'Buyer@1234');
        $this->get('/panel')->assertOk()->assertDontSee(route('sazeh.workspace.members'), false);
        $this->get('/panel/members')->assertOk(); // پنهان بودن منو ≠ سلب دسترسی؛ صفحه با مجوز کنترل می‌شود
    }

    public function test_role_start_page_controls_landing(): void
    {
        $this->makeBuyer();
        $this->role('workspace', 'owner')->forceFill(['start_route' => 'sazeh.workspace.members'])->save();
        $this->loginAs('09123333333', 'Buyer@1234')->assertRedirect(route('sazeh.workspace.members'));
    }

    public function test_system_menu_item_cannot_be_disabled_and_cycle_is_rejected(): void
    {
        $this->actingAs($this->admin());
        $this->withSession(['sazeh.context' => 'platform']);
        $sys = MenuItem::where('key', 'p.menus')->firstOrFail();
        $this->post('/admin/menus/'.$sys->id.'/toggle')->assertSessionHasErrors('form');
        $this->assertTrue($sys->fresh()->is_active);
    }
}
