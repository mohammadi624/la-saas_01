<?php

namespace Sazeh\Core\Tests\Feature;

use Sazeh\Core\Tests\TestCase;

/** حالت single: سایت معمولی بدون فروش اشتراک */
class SingleTenantTest extends TestCase
{
    protected function defineEnvironment($app): void
    {
        parent::defineEnvironment($app);
        $app['config']->set('sazeh.tenancy', 'single');
        $app['config']->set('sazeh.billing.enabled', false);
        $app['config']->set('sazeh.registration.mode', 'public');
    }

    public function test_visitor_registers_and_enters_site_panel_without_choosing(): void
    {
        $this->get('/register')->assertOk();
        $this->post('/register', ['name' => 'کاربر', 'mobile' => '09127777777', 'password' => 'Visitor@123', 'password_confirmation' => 'Visitor@123'])
            ->assertRedirect(route('sazeh.workspace.dashboard'));
        $this->get('/panel')->assertOk();
        $this->get('/panel/members')->assertForbidden(); // نقش member مجوز مشاهدهٔ کاربران ندارد
    }
}
