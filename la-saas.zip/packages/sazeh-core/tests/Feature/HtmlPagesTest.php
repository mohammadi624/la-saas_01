<?php

namespace Sazeh\Core\Tests\Feature;

use Illuminate\Http\UploadedFile;
use Sazeh\Core\Menu\MenuService;
use Sazeh\Core\Models\MenuItem;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Tests\TestCase;

/** صفحهٔ HTML آپلودی از منوساز: بدون کدنویسی، با همان قاعدهٔ دسترسی منو */
class HtmlPagesTest extends TestCase
{
    private function adminCreatesHtmlItem(string $panel, array $roles = []): MenuItem
    {
        $this->actingAs($this->admin())->withSession(['sazeh.context' => 'platform']);
        $this->post('/admin/menus', ['panel' => $panel]);
        $item = MenuItem::where('panel', $panel)->latest('id')->firstOrFail();
        $file = UploadedFile::fake()->createWithContent('welcome.html', '<html><body><h1>WELCOME-CONTENT</h1><?php echo "x"; ?></body></html>');
        $this->put('/admin/menus/'.$item->id, ['title' => 'خوش آمدید', 'icon' => 'home', 'type' => 'html', 'is_active' => 1,
            'html_file' => $file, 'access' => $roles, 'access_present' => 1])->assertSessionHasNoErrors();

        return $item->fresh();
    }

    public function test_upload_creates_page_and_shows_in_sandboxed_iframe(): void
    {
        $item = $this->adminCreatesHtmlItem('platform');
        $this->assertNotNull($item->html_page_id);
        $this->assertTrue($item->is_active);
        MenuService::bump();
        $res = $this->get('/admin/h/'.$item->id)->assertOk();
        $res->assertSee('sandbox="allow-scripts', false);
        $res->assertDontSee('allow-same-origin', false);
        $res->assertSee('WELCOME-CONTENT');           // داخل srcdoc (escape شده)
        $this->get('/admin')->assertSee(route('sazeh.platform.html', $item->id), false); // در منوی کناری
    }

    public function test_non_html_file_is_rejected(): void
    {
        $this->actingAs($this->admin())->withSession(['sazeh.context' => 'platform']);
        $this->post('/admin/menus', ['panel' => 'workspace']);
        $item = MenuItem::where('panel', 'workspace')->latest('id')->firstOrFail();
        $this->put('/admin/menus/'.$item->id, ['title' => 'x', 'icon' => 'home', 'type' => 'html', 'is_active' => 1,
            'html_file' => UploadedFile::fake()->createWithContent('shell.php', '<?php system($_GET["c"]);')])->assertSessionHasErrors();
        $this->assertNull($item->fresh()->html_page_id);
    }

    public function test_role_restriction_applies_to_direct_url(): void
    {
        $ownerRole = Role::where('panel', 'workspace')->where('key', 'owner')->firstOrFail();
        $item = $this->adminCreatesHtmlItem('workspace', [$ownerRole->id]);
        $this->logout();

        config(['sazeh.registration.mode' => 'public', 'sazeh.registration.on_register' => 'own_workspace']);
        $this->post('/register', ['name' => 'خریدار', 'mobile' => '09123333333', 'password' => 'Buyer@1234',
            'password_confirmation' => 'Buyer@1234', 'workspace_name' => 'shop']);
        $this->get('/panel/h/'.$item->id)->assertOk();          // مالک: مجاز

        $member = Role::where('panel', 'workspace')->where('key', 'member')->firstOrFail();
        $this->post('/panel/members', ['name' => 'k', 'mobile' => '09124444444', 'password' => 'Member@1234', 'role_id' => $member->id]);
        $this->logout();
        $this->loginAs('09124444444', 'Member@1234');
        $this->get('/panel/h/'.$item->id)->assertForbidden();   // نقش دیگر: حتی با آدرس مستقیم
        $this->get('/admin/h/'.$item->id)->assertForbidden();   // پنل دیگر
    }

    public function test_disabled_item_page_is_not_reachable(): void
    {
        $item = $this->adminCreatesHtmlItem('platform');
        $item->forceFill(['is_active' => false])->save();
        MenuService::bump();
        $this->get('/admin/h/'.$item->id)->assertForbidden();
    }
}
