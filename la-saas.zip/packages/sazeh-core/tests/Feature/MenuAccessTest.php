<?php

namespace Sazeh\Core\Tests\Feature;

use Sazeh\Core\Models\MenuItem;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Tests\TestCase;

/** انتخاب صفحه در منوساز + تیک نقش = دسترسی */
class MenuAccessTest extends TestCase
{
    private static string $dir;

    protected function defineEnvironment($app): void
    {
        parent::defineEnvironment($app);
        self::$dir = sys_get_temp_dir().'/sazeh-ma-'.getmypid().'-'.mt_rand();
        @mkdir(self::$dir.'/workspace', 0777, true);
        file_put_contents(self::$dir.'/workspace/orders.blade.php', "{{-- title: سفارش‌ها --}}\nORDERS-CONTENT");
        $app['config']->set('sazeh.file_pages.path', self::$dir);
        $app['config']->set('sazeh.registration.mode', 'public');
        $app['config']->set('sazeh.registration.on_register', 'own_workspace');
    }

    private function asAdmin(): void
    {
        $this->actingAs($this->admin())->withSession(['sazeh.context' => 'platform']);
    }

    private function member(): Role
    {
        return Role::where('panel', 'workspace')->whereNull('workspace_id')->where('key', 'member')->firstOrFail();
    }

    private function save(MenuItem $item, array $access, bool $active = true)
    {
        return $this->put('/admin/menus/'.$item->id, [
            'title' => $item->title, 'icon' => 'file', 'type' => 'page', 'route' => 'sazeh.page.workspace.orders',
            'is_active' => $active ? 1 : 0, 'access' => $access, 'access_present' => 1,
        ]);
    }

    public function test_menu_builder_lists_page_and_ticking_role_grants_permission(): void
    {
        $this->asAdmin();
        $this->get('/admin/menus?panel=workspace')->assertOk()->assertSee('سفارش‌ها')->assertSee('جدید');

        $item = MenuItem::where('key', 'file.workspace.orders')->firstOrFail();
        $this->save($item, [$this->member()->id])->assertSessionHasNoErrors()->assertSessionHas('success', fn ($m) => str_contains($m, 'دسترسی داده شد'));

        $this->assertTrue($this->member()->permissions()->where('key', 'page.workspace.orders')->exists());
        $this->assertTrue($item->fresh()->is_active);
        $this->assertSame(0, $item->roles()->count());
    }

    public function test_unticking_role_revokes_and_member_loses_access(): void
    {
        // خریدار و کارمندش
        $this->post('/register', ['name' => 'خریدار', 'mobile' => '09123333333', 'password' => 'Buyer@1234',
            'password_confirmation' => 'Buyer@1234', 'workspace_name' => 'shop'])->assertRedirect();
        $this->post('/panel/members', ['name' => 'کارمند', 'mobile' => '09124444444', 'password' => 'Member@1234', 'role_id' => $this->member()->id]);
        $this->logout();

        $this->asAdmin();
        $this->get('/admin/menus?panel=workspace');
        $item = MenuItem::where('key', 'file.workspace.orders')->firstOrFail();
        $this->save($item, [$this->member()->id])->assertSessionHasNoErrors();
        $this->logout();

        $this->loginAs('09124444444', 'Member@1234');
        $this->get('/panel/p/orders')->assertOk()->assertSee('ORDERS-CONTENT');
        $this->logout();

        $this->asAdmin();
        $this->save($item, [])->assertSessionHas('success', fn ($m) => str_contains($m, 'گرفته شد'));
        $this->logout();

        $this->loginAs('09124444444', 'Member@1234');
        $this->get('/panel/p/orders')->assertForbidden();
    }

    public function test_permission_without_active_menu_item_does_not_open_page(): void
    {
        $this->asAdmin();
        $this->get('/admin/menus?panel=workspace');
        $item = MenuItem::where('key', 'file.workspace.orders')->firstOrFail();
        $this->save($item, [$this->member()->id], active: false)->assertSessionHasNoErrors();
        $this->logout();

        $this->post('/register', ['name' => 'خریدار', 'mobile' => '09123333333', 'password' => 'Buyer@1234',
            'password_confirmation' => 'Buyer@1234', 'workspace_name' => 'shop'])->assertRedirect();
        $this->get('/panel/p/orders')->assertForbidden();
    }

    public function test_user_without_roles_manage_cannot_grant_through_menu(): void
    {
        $staff = Role::where('panel', 'platform')->where('key', 'staff')->firstOrFail();
        $staff->permissions()->sync(\Sazeh\Core\Models\Permission::where('key', 'menus.manage')->pluck('id'));
        $user = $this->admin()->replicate(['mobile', 'email', 'username', 'referral_code']);
        $user->forceFill(['name' => 'کارمند منو', 'mobile' => '09125555555', 'platform_role_id' => $staff->id])->save();

        $this->actingAs($user)->withSession(['sazeh.context' => 'platform']);
        $this->get('/admin/menus?panel=workspace')->assertOk();
        $item = MenuItem::where('key', 'file.workspace.orders')->firstOrFail();
        $this->save($item, [$this->member()->id])->assertSessionHas('success', fn ($m) => str_contains($m, 'مدیریت نقش‌ها'));

        $this->assertFalse($this->member()->permissions()->where('key', 'page.workspace.orders')->exists());
    }

    public function test_add_to_menu_from_unlinked_pages(): void
    {
        $this->asAdmin();
        $this->get('/admin/menus?panel=workspace');
        MenuItem::where('key', 'file.workspace.orders')->forceDelete();
        $this->get('/admin/menus?panel=workspace')->assertSee('افزودن به منو');

        $this->post('/admin/menus', ['panel' => 'workspace', 'route' => 'sazeh.page.workspace.orders'])->assertSessionHasNoErrors();
        $item = MenuItem::where('route', 'sazeh.page.workspace.orders')->firstOrFail();
        $this->assertSame('سفارش‌ها', $item->title);
        $this->assertFalse($item->is_active);

        $this->post('/admin/menus', ['panel' => 'workspace', 'route' => 'sazeh.platform.users'])->assertSessionHasErrors('form');
    }
}
