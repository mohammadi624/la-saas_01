<?php

namespace Sazeh\Core\Tests\Feature;

use Sazeh\Core\Models\MenuItem;
use Sazeh\Core\Models\Role;
use Sazeh\Core\Tests\TestCase;

/** صفحه‌های فایلی: هر فایل Blade یک صفحهٔ داشبورد با مجوز و آیتم منو */
class FilePagesTest extends TestCase
{
    private static string $dir;

    protected function defineEnvironment($app): void
    {
        parent::defineEnvironment($app);
        self::$dir = sys_get_temp_dir().'/sazeh-fp-'.getmypid();
        @mkdir(self::$dir.'/workspace/reports', 0777, true);
        file_put_contents(self::$dir.'/workspace/reports/sales.blade.php', "{{-- title: گزارش فروش --}}\n<div class=\"card\">SALES-PAGE-CONTENT</div>");
        file_put_contents(self::$dir.'/workspace/help.blade.php', "{{-- title: راهنما --}}\n{{-- access: all --}}\nHELP-CONTENT");
        $app['config']->set('sazeh.file_pages.path', self::$dir);
        $app['config']->set('sazeh.registration.mode', 'public');
        $app['config']->set('sazeh.registration.on_register', 'own_workspace');
    }

    public function test_file_page_gets_route_permission_and_inactive_menu_item(): void
    {
        $this->assertTrue(\Route::has('sazeh.page.workspace.reports.sales'));
        $item = MenuItem::where('key', 'file.workspace.reports.sales')->firstOrFail();
        $this->assertFalse($item->is_active);
        $this->assertSame('گزارش فروش', $item->title);
    }

    /** فعال کردن آیتم منوی یک صفحهٔ فایلی (کاری که مدیر در منوساز می‌کند) */
    private function activate(string $key): void
    {
        MenuItem::where('key', $key)->update(['is_active' => true]);
        \Sazeh\Core\Menu\MenuService::bump();
    }

    public function test_page_without_active_menu_item_is_closed_even_for_owner(): void
    {
        $this->post('/register', ['name' => 'خریدار', 'mobile' => '09123333333', 'password' => 'Buyer@1234',
            'password_confirmation' => 'Buyer@1234', 'workspace_name' => 'shop'])->assertRedirect();
        $this->get('/panel/p/reports/sales')->assertForbidden();
        $this->activate('file.workspace.reports.sales');
        $this->get('/panel/p/reports/sales')->assertOk()->assertSee('SALES-PAGE-CONTENT');
    }

    public function test_owner_sees_page_and_member_needs_permission(): void
    {
        $this->activate('file.workspace.reports.sales');
        $this->activate('file.workspace.help');
        $this->post('/register', ['name' => 'خریدار', 'mobile' => '09123333333', 'password' => 'Buyer@1234',
            'password_confirmation' => 'Buyer@1234', 'workspace_name' => 'shop'])->assertRedirect();
        $this->get('/panel/p/reports/sales')->assertOk()->assertSee('SALES-PAGE-CONTENT');

        $member = Role::where('panel', 'workspace')->where('key', 'member')->firstOrFail();
        $this->post('/panel/members', ['name' => 'کارمند', 'mobile' => '09124444444', 'password' => 'Member@1234', 'role_id' => $member->id])
            ->assertSessionHasNoErrors();
        $this->logout();

        $this->loginAs('09124444444', 'Member@1234');
        $this->get('/panel/p/reports/sales')->assertForbidden();
        $this->get('/panel/p/help')->assertOk()->assertSee('HELP-CONTENT'); // access: all

        // اعطای مجوز صفحه به نقش ← دسترسی
        $member->permissions()->attach(\Sazeh\Core\Models\Permission::where('key', 'page.workspace.reports.sales')->value('id'));
        \Sazeh\Core\Menu\MenuService::bump();
        $this->get('/panel/p/reports/sales')->assertOk();
    }
}
