<?php

namespace Sazeh\Core\Tests;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Orchestra\Testbench\TestCase as Base;
use Sazeh\Core\SazehServiceProvider;
use Sazeh\Core\Sms\SmsGateway;
use Sazeh\Core\Tests\Fixtures\FakeSms;
use Sazeh\Core\Tests\Fixtures\User;

abstract class TestCase extends Base
{
    use RefreshDatabase;

    protected FakeSms $sms;

    protected function getPackageProviders($app): array
    {
        return [SazehServiceProvider::class];
    }

    protected function defineEnvironment($app): void
    {
        $app['config']->set('database.default', 'sqlite');
        $app['config']->set('database.connections.sqlite.database', ':memory:');
        $app['config']->set('sazeh.user_model', User::class);
        $app['config']->set('auth.providers.users.model', User::class);
        $app['config']->set('sazeh.tenancy', 'multi');
    }

    protected function defineDatabaseMigrations(): void
    {
        $this->loadLaravelMigrations();
    }

    protected function setUp(): void
    {
        parent::setUp();
        $this->sms = new FakeSms;
        $this->app->instance(SmsGateway::class, $this->sms);
        $this->artisan('sazeh:install', ['--name' => 'مدیر', '--mobile' => '09121111111', '--password' => 'Admin@1234'])->assertSuccessful();
    }

    protected function admin(): User
    {
        return User::where('mobile', '09121111111')->firstOrFail();
    }

    protected function loginAs(string $identifier, string $password)
    {
        return $this->post('/login', ['identifier' => $identifier, 'password' => $password]);
    }

    protected function logout(): void
    {
        $this->post('/logout');
        $this->app['auth']->forgetGuards();
        $this->flushSession();
    }
}
