<?php

/**
 * تست‌های منطق خالص هسته — بدون نیاز به Laravel یا Composer.
 * اجرا:  php tests/Pure/run.php
 */
spl_autoload_register(function (string $class) {
    $prefix = 'Sazeh\\Core\\';
    if (str_starts_with($class, $prefix)) {
        $file = __DIR__.'/../../src/'.str_replace('\\', '/', substr($class, strlen($prefix))).'.php';
        if (is_file($file)) {
            require $file;
        }
    }
});

use Sazeh\Core\Access\AccessContext as Ctx;
use Sazeh\Core\Access\AccessResolver;
use Sazeh\Core\Auth\StartPageResolver;
use Sazeh\Core\Menu\MenuTree;
use Sazeh\Core\Modules\CoreModule;
use Sazeh\Core\Modules\Module;
use Sazeh\Core\Modules\ModuleRegistry;
use Sazeh\Core\Support\Identifier;
use Sazeh\Core\Support\SafeRedirect;
use Sazeh\Core\Support\SeatPolicy;

$pass = 0;
$fail = 0;
function t(string $name, callable $fn): void
{
    global $pass, $fail;
    try {
        $r = $fn();
        if ($r === true) {
            $pass++;
            echo "  ✓ {$name}\n";
        } else {
            $fail++;
            echo "  ✗ {$name}  → ".var_export($r, true)."\n";
        }
    } catch (Throwable $e) {
        $fail++;
        echo "  ✗ {$name}  → ".get_class($e).': '.$e->getMessage()."\n";
    }
}

echo "شناسه و موبایل\n";
t('ارقام فارسی و قالب‌های مختلف موبایل نرمال می‌شوند', fn () => array_unique(array_map(
    fn ($x) => Identifier::parse($x)->value,
    ['۰۹۱۲۳۳۳۳۳۳۳', '+989123333333', '00989123333333', '989123333333', '9123333333', '0912 333 3333', '٠٩١٢٣٣٣٣٣٣٣']
)) === ['09123333333']);
t('ایمیل lowercase می‌شود', fn () => Identifier::parse(' Reza@Aftab.TEST ')->value === 'reza@aftab.test' && Identifier::parse('a@b.co')->type === 'email');
t('نام کاربری تشخیص داده می‌شود', fn () => Identifier::parse('Ali_2')->type === 'username' && Identifier::parse('Ali_2')->value === 'ali_2');
t('ورودی نامعتبر', fn () => ! Identifier::parse('12')->isValid() && ! Identifier::parse('')->isValid() && ! Identifier::parse('x@')->isValid());
t('موبایل غیرایرانی رد می‌شود', fn () => Identifier::normalizeMobile('+14155550000') === null && Identifier::normalizeMobile('0812345678') === null);

echo "مقصد بازگشت\n";
t('مسیر نسبی معتبر', fn () => SafeRedirect::path('/panel/members?x=1') === '/panel/members' && SafeRedirect::path('/') === '/');
t('Open Redirect رد می‌شود', fn () => SafeRedirect::path('//evil.com') === null && SafeRedirect::path('/\\evil.com') === null
    && SafeRedirect::path('https://evil.com') === null && SafeRedirect::path('javascript:alert(1)') === null && SafeRedirect::path("/a\nb") === null);

echo "تصمیم دسترسی\n";
$catalog = [
    'members.view' => ['panel' => 'workspace', 'feature' => 'members'],
    'members.manage' => ['panel' => 'workspace', 'is_write' => true, 'feature' => 'members'],
    'billing.view' => ['panel' => 'workspace'],
    'menus.manage' => ['panel' => 'platform', 'is_write' => true],
];
$ar = new AccessResolver($catalog, ['billing.view']);
$ws = fn (array $o = []) => new Ctx(
    $o['ua'] ?? true, $o['ma'] ?? true, 'workspace', $o['role'] ?? 'manager', $o['all'] ?? false,
    $o['perms'] ?? ['members.view', 'members.manage'], $o['status'] ?? 'active', $o['owner'] ?? false, $o['ent'] ?? null
);
t('کاربر غیرفعال رد می‌شود', fn () => $ar->decide($ws(['ua' => false]), 'members.view')->code === 'user_inactive');
t('عضویت غیرفعال رد می‌شود', fn () => $ar->decide($ws(['ma' => false]), null)->code === 'membership_inactive');
t('صفحهٔ بدون مجوز فقط ورود می‌خواهد', fn () => $ar->decide($ws(), null)->code === 'auth_only');
t('مجوز نقش', fn () => $ar->decide($ws(), 'members.manage')->code === 'role');
t('پیش‌فرض منع', fn () => $ar->decide($ws(['perms' => []]), 'members.view')->code === 'default_deny');
t('مجوز پنل دیگر رد می‌شود حتی برای مالک', fn () => $ar->decide($ws(['all' => true]), 'menus.manage')->code === 'wrong_panel');
t('مجوز ناشناخته رد می‌شود', fn () => $ar->decide($ws(['all' => true]), 'x.y')->code === 'unknown_permission');
t('فقط‌خواندنی: مشاهده آری، نوشتن نه', fn () => $ar->allows($ws(['status' => 'read_only']), 'members.view')
    && $ar->decide($ws(['status' => 'read_only', 'all' => true]), 'members.manage')->code === 'read_only');
t('اشتراک خاموش (entitled=null) همه قابلیت‌ها مجاز', fn () => $ar->allows($ws(), 'members.view'));
t('قابلیت خارج از پلن رد می‌شود حتی برای مالک', fn () => $ar->decide($ws(['all' => true, 'ent' => fn ($f) => false]), 'members.view')->code === 'not_entitled');
t('اشتراک معلق: عضو غیرمالک رد', fn () => $ar->decide($ws(['status' => 'suspended']), 'members.view')->code === 'workspace_suspended');
t('اشتراک معلق: مالک فقط پرداخت', fn () => $ar->allows($ws(['status' => 'suspended', 'owner' => true, 'all' => true]), 'billing.view')
    && $ar->decide($ws(['status' => 'suspended', 'owner' => true, 'all' => true]), null)->code === 'suspended_owner_only');
t('پنل پلتفرم تحت تأثیر وضعیت فضا نیست', fn () => $ar->allows(new Ctx(true, true, 'platform', 'admin', true, [], null), 'menus.manage'));

echo "درخت منو\n";
$items = [
    ['id' => 1, 'parent_id' => null, 'type' => 'page', 'is_active' => true, 'sort' => 1, 'perm' => null, 'panel' => 'workspace'],
    ['id' => 2, 'parent_id' => null, 'type' => 'group', 'is_active' => true, 'sort' => 2, 'panel' => 'workspace'],
    ['id' => 3, 'parent_id' => 2, 'type' => 'page', 'is_active' => true, 'sort' => 1, 'perm' => 'secret', 'panel' => 'workspace'],
    ['id' => 4, 'parent_id' => null, 'type' => 'group', 'is_active' => false, 'sort' => 3, 'panel' => 'workspace'],
    ['id' => 5, 'parent_id' => 4, 'type' => 'page', 'is_active' => true, 'sort' => 1, 'perm' => null, 'panel' => 'workspace'],
    ['id' => 6, 'parent_id' => null, 'type' => 'group', 'is_active' => true, 'sort' => 4, 'panel' => 'workspace'],
    ['id' => 7, 'parent_id' => 6, 'type' => 'group', 'is_active' => true, 'sort' => 1, 'panel' => 'workspace'],
    ['id' => 8, 'parent_id' => 7, 'type' => 'page', 'is_active' => true, 'sort' => 1, 'perm' => null, 'panel' => 'workspace'],
    ['id' => 9, 'parent_id' => null, 'type' => 'page', 'is_active' => true, 'sort' => 0, 'perm' => null, 'panel' => 'workspace'],
];
$visible = fn ($it) => $it['perm'] === null;
$ids = function (array $tree) use (&$ids): array {
    $o = [];
    foreach ($tree as $n) {
        $o[] = $n['id'];
        $o = array_merge($o, $ids($n['children']));
    }

    return $o;
};
t('فقط آیتم‌های مجاز، گروه خالی و والد غیرفعال پنهان', fn () => $ids(MenuTree::visible($items, $visible)) === [9, 1, 6, 7, 8]);
t('مرتب‌سازی بر اساس sort', fn () => MenuTree::visible($items, $visible)[0]['id'] === 9);
t('اولین صفحه', fn () => MenuTree::firstPage(MenuTree::visible($items, $visible))['id'] === 9);
t('چرخه رد می‌شود', fn () => str_contains((string) MenuTree::moveError($items, 6, 7), 'خودش'));
t('والد غیرگروه رد می‌شود', fn () => str_contains((string) MenuTree::moveError($items, 3, 1), 'گروه'));
t('عمق بیش از ۳ رد می‌شود', fn () => str_contains((string) MenuTree::moveError($items, 6, 2), 'عمق'));
t('جابه‌جایی مجاز', fn () => MenuTree::moveError($items, 3, 4) === null && MenuTree::moveError($items, 7, null) === null);

echo "صفحهٔ شروع\n";
$deny = fn ($r) => $r === 'admin.secret' ? 'مجوز ندارد' : null;
$res = StartPageResolver::resolve([
    ['label' => 'intended', 'target' => null, 'reason' => 'Open Redirect'],
    ['label' => 'کاربر', 'target' => null],
    ['label' => 'نقش', 'target' => 'admin.secret'],
    ['label' => 'پیش‌فرض', 'target' => 'panel.home'],
    ['label' => 'امن', 'target' => 'account'],
], $deny);
t('اولین گزینهٔ مجاز انتخاب می‌شود', fn () => $res['target'] === 'panel.home');
t('مسیر تصمیم کامل ثبت می‌شود', fn () => array_column($res['trace'], 'status') === ['rejected', 'empty', 'rejected', 'chosen', 'skipped']);

echo "ظرفیت\n";
t('نامحدود صریح', fn () => SeatPolicy::unlimited()->blocks(10000) === null);
t('ظرفیت صفر = تک‌کاربره', fn () => str_contains((string) SeatPolicy::of(0)->blocks(0), 'امکان'));
t('ظرفیت پر', fn () => SeatPolicy::of(3)->blocks(2) === null && SeatPolicy::of(3)->blocks(3) !== null);

echo "ماژول‌ها\n";
$reg = new ModuleRegistry();
$reg->register(new CoreModule());
t('کاتالوگ مجوز هسته', fn () => isset($reg->permissionCatalog()['members.manage']) && $reg->permissionCatalog()['members.manage']['is_write'] === true);
t('صفحات هسته', fn () => $reg->page('sazeh.workspace.members')['permission'] === 'members.view');
t('ماژول تکراری رد می‌شود', function () use ($reg) {
    try {
        $reg->register(new CoreModule());

        return 'رد نشد';
    } catch (InvalidArgumentException) {
        return true;
    }
});
t('مجوز تکراری بین ماژول‌ها رد می‌شود', function () use ($reg) {
    $r = new ModuleRegistry();
    $r->register(new CoreModule());
    $r->register(new class extends Module {
        public function key(): string { return 'dup'; }
        public function permissions(): array { return [['key' => 'menus.manage', 'panel' => 'platform', 'label' => 'x']]; }
    });
    try {
        $r->permissionCatalog();

        return 'رد نشد';
    } catch (InvalidArgumentException) {
        return true;
    }
});
t('منوی هسته فقط به صفحات ثبت‌شده اشاره می‌کند', function () {
    $m = new CoreModule();
    $routes = array_column($m->pages(), 'route');
    foreach ($m->menu() as $i) {
        if (isset($i['route']) && ! in_array($i['route'], $routes, true)) {
            return $i['route'];
        }
    }

    return true;
});
t('صفحهٔ شروع نقش‌های قالب، صفحهٔ ثبت‌شده است', function () {
    $m = new CoreModule();
    $routes = array_column($m->pages(), 'route');
    foreach ($m->roles() as $r) {
        if (! empty($r['start']) && ! in_array($r['start'], $routes, true)) {
            return $r['start'];
        }
    }

    return true;
});

echo "صفحه‌های فایلی\n";
$tmp = sys_get_temp_dir().'/sazeh-pages-'.uniqid();
@mkdir($tmp.'/workspace/reports', 0777, true);
@mkdir($tmp.'/platform', 0777, true);
file_put_contents($tmp.'/workspace/reports/sales.blade.php', "{{-- title: گزارش فروش --}}\n{{-- icon: chart --}}\n<div>x</div>");
file_put_contents($tmp.'/workspace/help.blade.php', "{{-- title: راهنما --}}\n{{-- access: all --}}\n{{-- sort: 5 --}}\nhi");
file_put_contents($tmp.'/workspace/Bad_Name.blade.php', 'x');
file_put_contents($tmp.'/workspace/_partial.blade.php', 'x');
file_put_contents($tmp.'/platform/stats.blade.php', 'no header');
$fr = new \Sazeh\Core\Pages\FilePageRegistry($tmp);
$all = $fr->all();
t('کشف صفحه‌ها و رد نام نامعتبر و فایل‌های _', fn () => array_keys($all) === ['sazeh.page.platform.stats', 'sazeh.page.workspace.help', 'sazeh.page.workspace.reports.sales']);
t('مسیر تودرتو، عنوان و آیکون از سرآیند', fn () => $all['sazeh.page.workspace.reports.sales']['path'] === 'reports/sales'
    && $all['sazeh.page.workspace.reports.sales']['title'] === 'گزارش فروش' && $all['sazeh.page.workspace.reports.sales']['icon'] === 'chart'
    && $all['sazeh.page.workspace.reports.sales']['view'] === 'pages::workspace.reports.sales');
t('مجوز خودکار برای هر صفحه', fn () => $all['sazeh.page.workspace.reports.sales']['permission'] === 'page.workspace.reports.sales');
t('access: all یعنی بدون مجوز جدا', fn () => $all['sazeh.page.workspace.help']['permission'] === null && $all['sazeh.page.workspace.help']['sort'] === 5);
t('بدون سرآیند: عنوان = مسیر', fn () => $all['sazeh.page.platform.stats']['title'] === 'stats');
$pm = new \Sazeh\Core\Pages\PagesModule($tmp);
$reg2 = new ModuleRegistry();
$reg2->register(new CoreModule());
$reg2->register($pm);
t('ماژول صفحه‌ها: مجوز در کاتالوگ با پنل درست', fn () => ($reg2->permissionCatalog()['page.workspace.reports.sales']['panel'] ?? null) === 'workspace'
    && ! isset($reg2->permissionCatalog()['page.workspace.help']));
t('ماژول صفحه‌ها: آیتم منو غیرفعال ساخته می‌شود', fn () => array_column($pm->menu(), 'active') === [false, false, false]
    && $pm->menu()[2]['route'] === 'sazeh.page.workspace.reports.sales');
t('ماژول صفحه‌ها: صفحه در رجیستری', fn () => $reg2->page('sazeh.page.workspace.reports.sales')['permission'] === 'page.workspace.reports.sales');
array_map('unlink', glob($tmp.'/*/*/*.php') ?: []); array_map('unlink', glob($tmp.'/*/*.php') ?: []);

echo "تاریخ شمسی\n";
use Sazeh\Core\Support\Jalali;
t('میلادی به شمسی', fn () => Jalali::fromGregorian(2026, 11, 20) === [1405, 8, 29] && Jalali::fromGregorian(2026, 3, 21) === [1405, 1, 1]);
t('شمسی به میلادی', fn () => Jalali::toGregorian(1405, 1, 1) === [2026, 3, 21] && Jalali::toGregorian(1370, 5, 12) === [1991, 8, 3]);
t('رفت و برگشت برای ۲۰۰۰ روز', function () {
    $d = new DateTimeImmutable('1990-01-01');
    for ($i = 0; $i < 2000; $i++, $d = $d->modify('+7 day')) {
        [$y, $m, $dd] = Jalali::fromGregorian((int) $d->format('Y'), (int) $d->format('n'), (int) $d->format('j'));
        if (Jalali::toGregorian($y, $m, $dd) !== [(int) $d->format('Y'), (int) $d->format('n'), (int) $d->format('j')]) {
            return $d->format('Y-m-d');
        }
    }

    return true;
});
t('خواندن ورودی فرم با ارقام فارسی', fn () => Jalali::parse('۱۳۷۰/۰۵/۱۲') === '1991-08-03' && Jalali::parse('1405-1-1') === '2026-03-21');
t('تاریخ نامعتبر رد می‌شود', fn () => Jalali::parse('1404/12/30') === null && Jalali::parse('1370/13/01') === null && Jalali::parse('abc') === null && Jalali::parse('1370/07/31') === null);
t('مقدار پیش‌فرض فرم', fn () => Jalali::toInput('1991-08-03') === '1370/05/12' && Jalali::toInput(null) === '');

echo "\n— دسترسی از منوساز —\n";
use Sazeh\Core\Menu\MenuAccess;
$ga = [1 => true, 2 => false, 3 => false, 4 => false];
t('تیک = دادن مجوز، برداشتن تیک = گرفتن', fn () => MenuAccess::plan($ga, [2, 4], [2, 3], false) === ['grant' => [3], 'revoke' => [4], 'kept' => []]);
t('نقش «همهٔ دسترسی‌ها» هرگز تغییر نمی‌کند', fn () => MenuAccess::plan($ga, [], [1], false)['grant'] === [] && MenuAccess::plan($ga, [1], [], false)['revoke'] === []);
t('مجوز مشترک گرفته نمی‌شود، فقط داده می‌شود', fn () => MenuAccess::plan($ga, [2, 4], [3], true) === ['grant' => [3], 'revoke' => [], 'kept' => [2, 4]]);
t('نقش ناشناخته (پنل دیگر) نادیده گرفته می‌شود', fn () => MenuAccess::plan($ga, [99], [98, 2], false) === ['grant' => [2], 'revoke' => [], 'kept' => []]);
t('بدون تغییر، برنامه خالی است', fn () => MenuAccess::plan($ga, [2], [2], false) === ['grant' => [], 'revoke' => [], 'kept' => []]);
$rp = [1 => true, 2 => ['page.workspace.a', 'x'], 3 => ['x'], 4 => []];
t('مخاطبان: مجوز صفحه', fn () => MenuAccess::audience($rp, ['page.workspace.a'], []) === [1, 2]);
t('مخاطبان: مجوز صفحه + مجوز اضافه', fn () => MenuAccess::audience($rp, ['page.workspace.a', 'x'], []) === [1, 2] && MenuAccess::audience($rp, ['x', 'y'], []) === [1]);
t('مخاطبان: بدون مجوز = همه، با محدودیت نقش = همان‌ها', fn () => MenuAccess::audience($rp, [], []) === [1, 2, 3, 4] && MenuAccess::audience($rp, [], [3, 4]) === [3, 4]);
t('نشان «جدید» فقط برای صفحهٔ فایلی ویرایش‌نشده', function () {
    $base = ['type' => 'page', 'route' => 'r', 'module' => 'pages', 'is_active' => false, 'created_at' => '2026-01-01 10:00:00', 'updated_at' => '2026-01-01 10:00:00'];

    return MenuAccess::badges($base, true) === ['new', 'inactive']
        && MenuAccess::badges(['updated_at' => '2026-01-02 10:00:00'] + $base, true) === ['inactive']
        && MenuAccess::badges(['module' => 'core'] + $base, true) === ['inactive'];
});
t('نشان «فایل موجود نیست» و «بدون مقصد»', fn () => MenuAccess::badges(['type' => 'page', 'route' => 'gone', 'is_active' => true], false) === ['missing']
    && MenuAccess::badges(['type' => 'page', 'route' => null, 'is_active' => true], false) === ['no_target']
    && MenuAccess::badges(['type' => 'html', 'html_page_id' => null, 'is_active' => true], false) === ['no_target']);
t('یافتن Route در درخت تودرتو', function () {
    $tree = [['type' => 'group', 'children' => [['type' => 'page', 'route' => 'a', 'children' => []]]], ['type' => 'page', 'route' => 'b', 'children' => []]];

    return MenuAccess::routeInTree($tree, 'a') && MenuAccess::routeInTree($tree, 'b') && ! MenuAccess::routeInTree($tree, 'c');
});
t('اثر انگشت صفحه‌ها مستقل از ترتیب است', fn () => MenuAccess::fingerprint([['route' => 'a', 'title' => 'A'], ['route' => 'b', 'title' => 'B']])
    === MenuAccess::fingerprint([['route' => 'b', 'title' => 'B'], ['route' => 'a', 'title' => 'A']])
    && MenuAccess::fingerprint([['route' => 'a', 'title' => 'A']]) !== MenuAccess::fingerprint([['route' => 'a', 'title' => 'AA']]));

echo "\nنتیجه: {$pass} موفق، {$fail} ناموفق\n";
exit($fail ? 1 : 0);
