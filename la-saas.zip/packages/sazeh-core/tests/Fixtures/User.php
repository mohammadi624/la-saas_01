<?php

namespace Sazeh\Core\Tests\Fixtures;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Sazeh\Core\Concerns\HasSazehAccess;

class User extends Authenticatable
{
    use HasSazehAccess;

    protected $table = 'users';

    protected $fillable = ['name', 'email', 'password'];

    protected $hidden = ['password', 'remember_token'];
}
