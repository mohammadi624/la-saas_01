<?php

namespace Sazeh\Core\Tests\Fixtures;

use Sazeh\Core\Sms\SmsGateway;

class FakeSms implements SmsGateway
{
    public array $sent = [];

    public function send(string $mobile, string $message): void
    {
        $this->sent[] = [$mobile, $message];
    }

    public function lastCode(): ?string
    {
        $last = end($this->sent);

        return $last && preg_match('/(\d{6})/', $last[1], $m) ? $m[1] : null;
    }
}
