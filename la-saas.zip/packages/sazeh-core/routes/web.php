<?php

use Illuminate\Support\Facades\Route;
use Sazeh\Core\Http\Controllers\AccountController;
use Sazeh\Core\Http\Controllers\Auth\LoginController;
use Sazeh\Core\Http\Controllers\Auth\RegisterController;
use Sazeh\Core\Http\Controllers\ContextController;
use Sazeh\Core\Http\Controllers\DashboardController;
use Sazeh\Core\Http\Controllers\Platform\AuditController;
use Sazeh\Core\Http\Controllers\Platform\MenuController;
use Sazeh\Core\Http\Controllers\Platform\RoleController;
use Sazeh\Core\Http\Controllers\Platform\UserController;
use Sazeh\Core\Http\Controllers\Platform\WorkspaceController;
use Sazeh\Core\Http\Controllers\Workspace\MemberController;

/*
| قرارداد:
|  - صفحه‌ها (GET) ← middleware 'sazeh'  (ورود + بخش معتبر + دسترسی صفحه از رجیستری ماژول)
|  - عملیات (POST/PUT/DELETE) ← 'sazeh.context' + 'sazeh.can:مجوز'
*/

// ---------- ورود، OTP، ثبت‌نام، خروج ----------
Route::get('/login', [LoginController::class, 'show'])->name('sazeh.login');
Route::post('/login', [LoginController::class, 'password'])->middleware('throttle:30,1')->name('sazeh.login.password');
Route::post('/login/otp', [LoginController::class, 'otpRequest'])->middleware('throttle:10,1')->name('sazeh.login.otp');
Route::get('/login/otp/verify', [LoginController::class, 'otpForm'])->name('sazeh.login.otp.form');
Route::post('/login/otp/verify', [LoginController::class, 'otpVerify'])->middleware('throttle:30,1')->name('sazeh.login.otp.verify');
Route::get('/register', [RegisterController::class, 'show'])->name('sazeh.register');
Route::post('/register', [RegisterController::class, 'store'])->middleware('throttle:10,1')->name('sazeh.register.store');
Route::post('/logout', [LoginController::class, 'logout'])->middleware('auth')->name('sazeh.logout');

// ---------- انتخاب بخش و صفحهٔ شروع ----------
Route::middleware('auth')->group(function () {
    Route::get('/context', [ContextController::class, 'pick'])->name('sazeh.context.pick');
    Route::post('/context', [ContextController::class, 'select'])->name('sazeh.context.select');
});
Route::get('/home', [ContextController::class, 'home'])->middleware('sazeh.context')->name('sazeh.home');

// ---------- امنیت حساب (هر دو پنل) ----------
Route::get('/account/security', [AccountController::class, 'security'])->middleware('sazeh')->name('sazeh.account.security');
Route::post('/account/password', [AccountController::class, 'password'])->middleware('sazeh.context')->name('sazeh.account.password');

// ---------- پنل پلتفرم (مالک سایت / ادمین / طراح) ----------
Route::prefix(config('sazeh.panels.platform.prefix', 'admin'))->name('sazeh.platform.')->group(function () {
    Route::middleware('sazeh')->group(function () {
        Route::get('/', [DashboardController::class, 'platform'])->name('dashboard');
        Route::get('/menus', [MenuController::class, 'index'])->name('menus');
        Route::get('/roles', [RoleController::class, 'index'])->name('roles');
        Route::get('/users', [UserController::class, 'index'])->name('users');
        Route::get('/workspaces', [WorkspaceController::class, 'index'])->name('workspaces');
        Route::get('/audit', [AuditController::class, 'index'])->name('audit');
        Route::get('/h/{item}', [\Sazeh\Core\Http\Controllers\HtmlPageController::class, 'show'])->whereNumber('item')->name('html');
    });

    Route::middleware(['sazeh.context', 'sazeh.can:menus.manage'])->group(function () {
        Route::post('/menus', [MenuController::class, 'store'])->name('menus.store');
        Route::put('/menus/{item}', [MenuController::class, 'update'])->name('menus.update');
        Route::post('/menus/{item}/toggle', [MenuController::class, 'toggle'])->name('menus.toggle');
        Route::post('/menus/{item}/move', [MenuController::class, 'move'])->name('menus.move');
        Route::delete('/menus/{item}', [MenuController::class, 'destroy'])->name('menus.destroy');
        Route::post('/menus/{id}/restore', [MenuController::class, 'restore'])->whereNumber('id')->name('menus.restore');
    });
    Route::middleware(['sazeh.context', 'sazeh.can:roles.manage'])->group(function () {
        Route::post('/roles', [RoleController::class, 'store'])->name('roles.store');
        Route::put('/roles/matrix', [RoleController::class, 'matrix'])->name('roles.matrix');
        Route::delete('/roles/{role}', [RoleController::class, 'destroy'])->name('roles.destroy');
    });
    Route::middleware(['sazeh.context', 'sazeh.can:users.manage'])->group(function () {
        Route::post('/users', [UserController::class, 'store'])->name('users.store');
        Route::put('/users/{id}', [UserController::class, 'update'])->whereNumber('id')->name('users.update');
    });
    Route::middleware(['sazeh.context', 'sazeh.can:workspaces.manage'])->group(function () {
        Route::post('/workspaces', [WorkspaceController::class, 'store'])->name('workspaces.store');
        Route::put('/workspaces/{workspace}/status', [WorkspaceController::class, 'status'])->name('workspaces.status');
    });
});

// ---------- پنل فضای کاری (خریدار / کاربر) ----------
Route::prefix(config('sazeh.panels.workspace.prefix', 'panel'))->name('sazeh.workspace.')->group(function () {
    Route::middleware('sazeh')->group(function () {
        Route::get('/', [DashboardController::class, 'workspace'])->name('dashboard');
        Route::get('/members', [MemberController::class, 'index'])->name('members');
        Route::get('/h/{item}', [\Sazeh\Core\Http\Controllers\HtmlPageController::class, 'show'])->whereNumber('item')->name('html');
    });
    Route::middleware(['sazeh.context', 'sazeh.can:members.manage'])->group(function () {
        Route::post('/members', [MemberController::class, 'store'])->name('members.store');
        Route::put('/members/{membership}', [MemberController::class, 'update'])->whereNumber('membership')->name('members.update');
        Route::delete('/members/{membership}', [MemberController::class, 'destroy'])->whereNumber('membership')->name('members.destroy');
    });
});
