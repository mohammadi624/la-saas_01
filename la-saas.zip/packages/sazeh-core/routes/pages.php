<?php

use Illuminate\Support\Facades\Route;
use Sazeh\Core\Http\Controllers\FilePageController;
use Sazeh\Core\Modules\ModuleRegistry;

/** Routeهای صفحه‌های فایلی:  /admin/p/{مسیر}  و  /panel/p/{مسیر} */
$module = app(ModuleRegistry::class)->all()['pages'] ?? null;
if ($module) {
    foreach ($module->registry()->all() as $page) {
        $prefix = config('sazeh.panels.'.$page['panel'].'.prefix');
        Route::get($prefix.'/p/'.$page['path'], [FilePageController::class, 'show'])
            ->middleware('sazeh')
            ->name($page['route']);
    }
}
