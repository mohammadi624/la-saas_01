@extends('sazeh::layouts.dashboard')
@section('heading', 'لاگ امنیتی')
@section('content')
<div class="card">
    <div class="hd"><div><p class="desc" style="margin:0">رمز، کد OTP و توکن هرگز ثبت نمی‌شوند.</p></div>
        <form method="get" class="row"><input type="text" name="q" value="{{ $q }}" placeholder="مثلاً login" dir="ltr"><button class="btn sm">فیلتر</button></form></div>
    <div class="tw"><table><thead><tr><th>زمان</th><th>رویداد</th><th>عامل</th><th>فضا</th><th>جزئیات</th><th>IP</th></tr></thead><tbody>
    @forelse ($logs as $l)
        <tr><td class="small">{{ $l->created_at }}</td><td><code>{{ $l->action }}</code></td><td>{{ $l->actor?->name ?? '—' }}</td><td>{{ $l->workspace_id ?? '—' }}</td>
        <td class="small"><code>{{ $l->meta ? json_encode($l->meta, JSON_UNESCAPED_UNICODE) : '' }}</code></td><td><code>{{ $l->ip }}</code></td></tr>
    @empty
        <tr><td colspan="6" class="muted">رویدادی نیست.</td></tr>
    @endforelse
    </tbody></table></div>
    <div class="pager">{{ $logs->links() }}</div>
</div>
@endsection
