@extends('sazeh::layouts.dashboard')
@section('heading', 'فضاهای کاری')
@section('content')
<div class="grid g75">
<div class="card">
    <div class="hd"><div><h2>فضاهای کاری / خریداران</h2><p class="desc" style="margin:0">مدیر پلتفرم بدون عضویت به دادهٔ داخل فضاها دسترسی ندارد. تغییر وضعیت بلافاصله روی ورود اعضای آن فضا اثر دارد.</p></div>
        <form method="get" class="row"><input type="text" name="q" value="{{ $q }}" placeholder="جستجو"><button class="btn sm">جستجو</button></form></div>
    <div class="tw"><table><thead><tr><th>فضای کاری</th><th>مالک</th><th>کاربران / ظرفیت</th><th>پلن</th><th>وضعیت</th></tr></thead><tbody>
    @foreach ($workspaces as $w)
        @php($seats = $ent->seats($w))
        <tr><td><b>{{ $w->name }}</b> <code>{{ $w->slug }}</code></td><td>{{ $w->owner?->name }}<div class="small"><code>{{ $w->owner?->mobile }}</code></div></td>
        <td>{{ $w->memberships_count }} / {{ $seats->unlimited ? 'نامحدود' : $seats->limit }}</td><td>{{ $w->plan?->title ?? '—' }}</td>
        <td><form method="post" action="{{ route('sazeh.platform.workspaces.status', $w) }}">@csrf @method('put')<select name="status" onchange="this.form.submit()">@foreach (\Sazeh\Core\Models\Workspace::STATUSES as $k => $v)<option value="{{ $k }}" @selected($w->status === $k)>{{ $v }}</option>@endforeach</select></form></td></tr>
    @endforeach
    </tbody></table></div>
    <div class="pager">{{ $workspaces->links() }}</div>
</div>
<div class="card"><h2>خریدار / فضای کاری جدید</h2><p class="desc">یک فضای کاری ساخته می‌شود و این شخص مالک آن است. او کاربران خودش را از پنلش اضافه می‌کند.</p>
<form method="post" action="{{ route('sazeh.platform.workspaces.store') }}">@csrf
    <div class="grid g2" style="gap:10px">
        <label class="f"><span>نام فضای کاری / سایت</span><input type="text" name="ws_name" value="{{ old('ws_name') }}" required></label>
        <label class="f"><span>نامک لاتین</span><input type="text" name="slug" value="{{ old('slug') }}" dir="ltr" required placeholder="my-shop"></label>
    </div>
    @if (config('sazeh.billing.enabled'))
    <label class="f"><span>پلن</span><select name="plan_id"><option value="">—</option>@foreach ($plans as $p)<option value="{{ $p->id }}">{{ $p->title }}</option>@endforeach</select></label>
    @endif
    <p class="small" style="margin:6px 0"><b>مالک:</b></p>
    @include('sazeh::partials.identity-fields')
    <button class="btn pri">ساخت</button>
</form></div>
</div>
@endsection
