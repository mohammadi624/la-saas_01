@foreach ($nodes as $n)
    @php
        $m = $n['model'];
        $x = $meta[$m->id] ?? ['badges' => [], 'audience' => null, 'page' => null];
        $aud = $x['audience'];
        $totalRoles = count($roleTitles);
    @endphp
    <div>
        <div class="tnode {{ $selected?->id == $m->id ? 'sel' : '' }} {{ $m->is_active ? '' : 'off' }} {{ $m->type === 'group' ? 'grp' : '' }}">
            <span class="tico">@sazehIcon($m->icon)</span>
            <a class="tmain" href="{{ route('sazeh.platform.menus', ['panel' => $panel, 'item' => $m->id]) }}">
                <div class="tt">
                    {{ $m->title }}
                    @if (in_array('new', $x['badges'], true))<span class="b b-new">جدید</span>@endif
                    @if (in_array('missing', $x['badges'], true))<span class="b b-no">فایل موجود نیست</span>@endif
                    @if (in_array('no_target', $x['badges'], true))<span class="b b-warn">بدون مقصد</span>@endif
                    @unless ($m->is_active)<span class="b b-mut">غیرفعال</span>@endunless
                    @if ($m->is_system)<span class="b b-pri">سیستمی</span>@endif
                </div>
                <div class="ts">
                    <span>{{ $typeLabels[$m->type] ?? $m->type }}</span>
                    @if ($m->type === 'page' && $m->route)
                        · <code>{{ $x['page'] && \Illuminate\Support\Facades\Route::has($m->route) ? route($m->route, [], false) : $m->route }}</code>
                    @elseif ($m->type === 'external')
                        · <code>{{ $m->url }}</code>
                    @elseif ($m->type === 'html')
                        · <code>{{ $m->htmlPage?->original_name ?? '—' }}</code>
                    @endif
                    @if ($aud !== null)
                        · <span class="chips">
                            @if ($aud === [])<span class="chip none">هیچ نقشی</span>
                            @elseif (count($aud) === $totalRoles)<span class="chip all">همهٔ نقش‌ها</span>
                            @else
                                @foreach (array_slice($aud, 0, 3) as $rid)<span class="chip">{{ $roleTitles[$rid] ?? '#'.$rid }}</span>@endforeach
                                @if (count($aud) > 3)<span class="chip">+{{ \Sazeh\Core\Support\Jalali::digits(count($aud) - 3) }}</span>@endif
                            @endif
                        </span>
                    @endif
                </div>
            </a>
            <span class="tacts">
                @unless ($m->is_system)
                <form method="post" action="{{ route('sazeh.platform.menus.toggle', $m) }}">@csrf<button class="ibtn" title="{{ $m->is_active ? 'غیرفعال کن' : 'فعال کن' }}">@sazehIcon($m->is_active ? 'pause' : 'play')</button></form>
                @endunless
                @foreach (['up' => ['up', 'بالا'], 'down' => ['down', 'پایین'], 'in' => ['indent', 'زیرمجموعهٔ گروه قبلی'], 'out' => ['outdent', 'یک سطح بیرون']] as $dir => [$ic, $tip])
                <form method="post" action="{{ route('sazeh.platform.menus.move', $m) }}">@csrf<input type="hidden" name="dir" value="{{ $dir }}"><button class="ibtn" title="{{ $tip }}">@sazehIcon($ic)</button></form>
                @endforeach
            </span>
        </div>
        @if ($n['children'])<div class="tkids">@include('sazeh::platform.partials.menu-node', ['nodes' => $n['children']])</div>@endif
    </div>
@endforeach
