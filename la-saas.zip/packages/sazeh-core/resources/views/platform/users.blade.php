@extends('sazeh::layouts.dashboard')
@php($pc = config('sazeh.panels.platform'))
@section('heading', $pc['members_label'])
@section('content')
<div class="owner-box">@sazehIcon('shield')
    <div>این کاربران <b>زیرمجموعهٔ {{ $pc['owner_label'] }}</b> هستند و فقط «{{ $pc['title'] }}» را می‌بینند.
    <span class="small">کاربران هر {{ config('sazeh.panels.workspace.owner_label') }} را خودش از پنل خودش تعریف می‌کند و اینجا نمایش داده نمی‌شوند.</span></div>
</div>
<div class="grid g75">
<div class="card">
    <div class="hd"><div><h2>{{ $pc['members_label'] }} <span class="b b-pri">{{ $users->total() }} نفر</span></h2></div>
        <form method="get" class="row"><input type="text" name="q" value="{{ $q }}" placeholder="جستجو"><button class="btn sm">جستجو</button></form></div>
    <div class="tw"><table><thead><tr><th>کاربر</th><th>زیرمجموعهٔ</th><th>نقش و دسترسی‌ها</th><th>وضعیت</th><th></th></tr></thead><tbody>
    @foreach ($users as $u)
        @php($self = $u->id == auth()->id())
        <tr>
        <td><b>{{ $u->name }}</b>@if ($self) <span class="b b-mut">شما</span>@endif
            <div class="small"><code>{{ $u->mobile }}</code> @if ($u->email)<code>{{ $u->email }}</code>@endif</div>
            <div class="small muted">آخرین ورود: {{ $u->last_login_at ?? '—' }}</div></td>
        <td><span class="b b-pri">{{ $pc['owner_label'] }}</span></td>
        <td style="min-width:230px">
            @if ($self)<b>{{ $u->platformRole?->title }}</b>
            @else
            <form method="post" action="{{ route('sazeh.platform.users.update', $u->id) }}">@csrf @method('put')
                <select name="role_id" onchange="this.form.submit()">@foreach ($roles as $r)<option value="{{ $r->id }}" @selected($u->platform_role_id == $r->id)>{{ $r->title }}</option>@endforeach</select></form>
            @endif
            <div style="margin-top:4px">@include('sazeh::partials.role-perms', ['role' => $u->platformRole])</div>
            <div class="small muted">پس از ورود: {{ $starts[$u->platformRole?->start_route] ?? 'اولین صفحهٔ مجاز منو' }}</div>
        </td>
        <td>{!! ($u->status ?? 'active') === 'active' ? '<span class="b b-ok">فعال</span>' : '<span class="b b-mut">غیرفعال</span>' !!}</td>
        <td>@unless ($self)<div class="row">
            <form method="post" action="{{ route('sazeh.platform.users.update', $u->id) }}">@csrf @method('put')<input type="hidden" name="status" value="{{ ($u->status ?? 'active') === 'active' ? 'inactive' : 'active' }}"><button class="btn sm">{{ ($u->status ?? 'active') === 'active' ? 'غیرفعال' : 'فعال' }}</button></form>
            <form method="post" action="{{ route('sazeh.platform.users.update', $u->id) }}" onsubmit="return confirm('از {{ $pc['members_label'] }} خارج شود؟ حساب او باقی می‌ماند.')">@csrf @method('put')<input type="hidden" name="remove" value="1"><button class="btn sm dng">خروج</button></form>
        </div>@endunless</td></tr>
    @endforeach
    </tbody></table></div>
    <div class="pager">{{ $users->links() }}</div>
</div>
<div class="card"><h2>افزودن به {{ $pc['members_label'] }}</h2>
    <p class="desc">کاربر جدید زیرمجموعهٔ <b>{{ $pc['owner_label'] }}</b> ثبت می‌شود و فقط به بخش‌هایی دسترسی دارد که نقشش اجازه می‌دهد.</p>
    <form method="post" action="{{ route('sazeh.platform.users.store') }}">@csrf
        @include('sazeh::partials.identity-fields')
        @include('sazeh::partials.role-picker', ['roles' => $roles, 'starts' => $starts])
        <button class="btn pri">افزودن به {{ $pc['members_label'] }}</button>
    </form>
    <p class="small muted" style="margin:10px 0 0">دسترسی هر نقش را در «نقش‌ها و دسترسی‌ها» تغییر دهید.</p>
</div>
</div>
@endsection
