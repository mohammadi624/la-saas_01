@extends('sazeh::layouts.dashboard')
@section('heading', 'نقش‌ها و دسترسی‌ها')
@section('content')
<div class="card">
<div class="hd"><div class="row">
    <a class="btn {{ $panel === 'platform' ? 'pri' : '' }}" href="{{ route('sazeh.platform.roles', ['panel' => 'platform']) }}">نقش‌های {{ config('sazeh.panels.platform.members_label') }}</a>
    <a class="btn {{ $panel === 'workspace' ? 'pri' : '' }}" href="{{ route('sazeh.platform.roles', ['panel' => 'workspace']) }}">نقش‌های {{ config('sazeh.panels.workspace.owner_label') }} و کاربرانش</a>
</div>
<form method="post" action="{{ route('sazeh.platform.roles.store') }}" class="row">@csrf<input type="hidden" name="panel" value="{{ $panel }}"><input type="text" name="title" placeholder="عنوان نقش جدید" required maxlength="60"><button class="btn pri">+ نقش</button></form></div>
<p class="desc">نقش‌های «همهٔ مجوزها» (مدیر کل، مالک) قفل‌اند. صفحهٔ شروع هر نقش تعیین می‌کند کاربر بعد از ورود کجا برود؛ اگر به آن دسترسی نداشته باشد، اولین صفحهٔ مجاز منو باز می‌شود.</p>
<form method="post" action="{{ route('sazeh.platform.roles.matrix') }}">@csrf @method('put')<input type="hidden" name="panel" value="{{ $panel }}">
<div class="tw mx"><table>
<thead><tr><th>مجوز</th>@foreach ($roles as $r)<th class="c">{{ $r->title }}@if ($r->grants_all)<br><span class="b b-pri">همهٔ مجوزها</span>@endif</th>@endforeach</tr></thead>
<tbody>
<tr style="background:#f6f8fc"><td><b>صفحهٔ شروع پس از ورود</b></td>
@foreach ($roles as $r)<td class="c"><select name="start[{{ $r->id }}]" style="max-width:180px"><option value="">— اولین صفحهٔ منو —</option>@foreach ($starts as $route => $title)<option value="{{ $route }}" @selected($r->start_route === $route)>{{ $title }}</option>@endforeach</select></td>@endforeach</tr>
@foreach ($permissions as $module => $perms)
    <tr><td colspan="{{ $roles->count() + 1 }}" style="background:#fafbfd;font-weight:700">ماژول: {{ $module }}</td></tr>
    @foreach ($perms as $p)
    <tr><td>{{ $p->label }} <code>{{ $p->key }}</code> @if ($p->is_write)<span class="b b-mut">نوشتنی</span>@endif</td>
    @foreach ($roles as $r)<td class="c"><input type="checkbox" name="perm[{{ $r->id }}][{{ $p->key }}]" value="1" @checked($r->grants_all || $r->permissions->contains('key', $p->key)) @disabled($r->grants_all)></td>@endforeach</tr>
    @endforeach
@endforeach
<tr><td></td>@foreach ($roles as $r)<td class="c">@unless ($r->is_system)<button form="del-role-{{ $r->id }}" class="btn sm dng">حذف نقش</button>@endunless</td>@endforeach</tr>
</tbody></table></div>
<div class="row" style="margin-top:12px"><button class="btn pri">ذخیرهٔ ماتریس و صفحه‌های شروع</button></div>
</form>
@foreach ($roles as $r)@unless ($r->is_system)<form id="del-role-{{ $r->id }}" method="post" action="{{ route('sazeh.platform.roles.destroy', $r) }}" onsubmit="return confirm('نقش حذف شود؟')">@csrf @method('delete')</form>@endunless @endforeach
</div>
@endsection
