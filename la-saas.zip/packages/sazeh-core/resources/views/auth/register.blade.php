@extends('sazeh::layouts.auth')
@section('title', 'ثبت‌نام')
@section('content')
<h1>ثبت‌نام</h1>
<p class="desc">پس از ثبت‌نام مستقیم وارد داشبورد خود می‌شوید.</p>
@include('sazeh::partials.flash')
<form method="post" action="{{ route('sazeh.register.store') }}">@csrf
    <label class="f"><span>نام و نام خانوادگی</span><input type="text" name="name" value="{{ old('name') }}" required></label>
    <label class="f"><span>موبایل</span><input type="tel" name="mobile" value="{{ old('mobile') }}" dir="ltr" required></label>
    <label class="f"><span>ایمیل {{ config('sazeh.registration.require_email') ? '' : '(اختیاری)' }}</span><input type="email" name="email" value="{{ old('email') }}" dir="ltr" @required(config('sazeh.registration.require_email'))></label>
    @if (config('sazeh.registration.on_register') === 'own_workspace' && config('sazeh.tenancy') === 'multi')
        <label class="f"><span>نام کسب‌وکار / سایت شما</span><input type="text" name="workspace_name" value="{{ old('workspace_name') }}" required></label>
    @endif
    <label class="f"><span>رمز عبور (حداقل {{ config('sazeh.password_min') }} نویسه)</span><input type="password" name="password" dir="ltr" required></label>
    <label class="f"><span>تکرار رمز عبور</span><input type="password" name="password_confirmation" dir="ltr" required></label>
    <button class="btn pri">ثبت‌نام</button>
</form>
<p class="small muted" style="text-align:center;margin:14px 0 0">حساب دارید؟ <a href="{{ route('sazeh.login') }}">ورود</a></p>
@endsection
