@extends('sazeh::layouts.auth')
@section('title', 'ورود')
@section('content')
@php($tab = request('tab') === 'otp' && config('sazeh.login.otp') ? 'otp' : 'password')
<h1>ورود به داشبورد</h1>
<p class="desc">یک صفحهٔ ورود برای همهٔ کاربران؛ هر کس به صفحهٔ نقش خودش می‌رود.</p>
@if (config('sazeh.login.otp'))
<div class="tabs"><a href="{{ route('sazeh.login') }}" class="{{ $tab === 'password' ? 'on' : '' }}">رمز عبور</a><a href="{{ route('sazeh.login', ['tab' => 'otp']) }}" class="{{ $tab === 'otp' ? 'on' : '' }}">کد پیامکی</a></div>
@endif
@include('sazeh::partials.flash')
@if ($tab === 'password')
<form method="post" action="{{ route('sazeh.login.password') }}">@csrf
    <label class="f"><span>ایمیل، موبایل یا نام کاربری</span><input type="text" name="identifier" value="{{ old('identifier') }}" autocomplete="username" dir="auto" required autofocus></label>
    <label class="f"><span>رمز عبور</span><input type="password" name="password" autocomplete="current-password" dir="ltr" required></label>
    <label class="row small" style="margin-bottom:10px"><input type="checkbox" name="remember" value="1"> مرا به خاطر بسپار</label>
    <button class="btn pri">ورود</button>
</form>
@else
<form method="post" action="{{ route('sazeh.login.otp') }}">@csrf
    <label class="f"><span>شمارهٔ موبایل</span><input type="tel" name="mobile" value="{{ old('mobile') }}" dir="ltr" inputmode="tel" placeholder="09xxxxxxxxx" required autofocus></label>
    <button class="btn pri">ارسال کد</button>
</form>
@endif
@if (config('sazeh.registration.mode') === 'public')
<p class="small muted" style="text-align:center;margin:14px 0 0">حساب ندارید؟ <a href="{{ route('sazeh.register') }}">ثبت‌نام</a></p>
@endif
@endsection
