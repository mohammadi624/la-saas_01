@extends('sazeh::layouts.auth')
@section('title', 'تأیید کد')
@section('content')
<h1>کد تأیید</h1>
<p class="desc">کد {{ config('sazeh.otp.length') }} رقمی ارسال‌شده به <code>{{ $mobile }}</code> را وارد کنید. اعتبار کد {{ config('sazeh.otp.ttl_seconds') }} ثانیه است.</p>
@include('sazeh::partials.flash')
<form method="post" action="{{ route('sazeh.login.otp.verify') }}">@csrf
    <input type="text" name="code" class="otp" maxlength="{{ config('sazeh.otp.length') }}" inputmode="numeric" autocomplete="one-time-code" required autofocus style="width:100%;margin-bottom:12px">
    <button class="btn pri">تأیید و ورود</button>
</form>
<form method="post" action="{{ route('sazeh.login.otp') }}" class="row" style="justify-content:space-between;margin-top:12px">@csrf
    <input type="hidden" name="mobile" value="{{ $mobile }}">
    <button class="btn sm" type="submit">ارسال مجدد</button><a class="small" href="{{ route('sazeh.login', ['tab' => 'otp']) }}">تغییر شماره</a>
</form>
@endsection
