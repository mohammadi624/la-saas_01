@extends('sazeh::layouts.auth')
@section('title', 'انتخاب بخش')
@section('content')
<h1>به کدام بخش وارد می‌شوید؟</h1>
<p class="desc">{{ auth()->user()->name }}، شما به چند بخش دسترسی دارید.</p>
@include('sazeh::partials.flash')
<form method="post" action="{{ route('sazeh.context.select') }}">@csrf
@foreach ($contexts as $c)
    <button class="ctx" name="context" value="{{ $c['key'] }}" @disabled(! $c['ok'])>
        <span class="logo" style="width:38px;height:38px;border-radius:10px;display:grid;place-items:center;background:#eef2ff;color:#3157c8">@sazehIcon($c['panel'] === 'workspace' ? 'globe' : 'shield')</span>
        <span style="flex:1"><b>{{ $c['title'] }}</b><span class="small muted" style="display:block">{{ $c['role']->title }}{{ $c['ok'] ? '' : ' — '.$c['why'] }}</span></span>
    </button>
@endforeach
</form>
<form method="post" action="{{ route('sazeh.logout') }}" style="text-align:center;margin-top:10px">@csrf<button class="btn sm">خروج</button></form>
@endsection
