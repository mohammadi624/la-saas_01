@extends('sazeh::layouts.dashboard')
@php($wc = config('sazeh.panels.workspace'))
@section('heading', $wc['members_label'])
@section('content')
<div class="owner-box">@sazehIcon('globe')
    <div>این کاربران <b>زیرمجموعهٔ {{ $wc['owner_label'] }} «{{ $ws->owner?->name }}»</b> در «{{ $ws->name }}» هستند و فقط به همین فضا دسترسی دارند.
    <span class="small">ظرفیت: <b>{{ $seatText }}</b> ({{ $wc['owner_label'] }} شمرده نمی‌شود)</span></div>
</div>
<div class="grid {{ $canManage ? 'g75' : '' }}">
<div class="card">
    <div class="hd"><div><h2>{{ $wc['members_label'] }} <span class="b b-pri">{{ $members->count() }} نفر</span></h2></div></div>
    <div class="tw"><table><thead><tr><th>کاربر</th><th>زیرمجموعهٔ</th><th>نقش و دسترسی‌ها</th><th>وضعیت</th>@if ($canManage)<th></th>@endif</tr></thead><tbody>
    @foreach ($members as $m)
        @php($isOwner = $ws->isOwnedBy($m->user))
        @php($locked = ! $canManage || $isOwner || $m->user_id == $me->getKey())
        <tr>
        <td><b>{{ $m->user?->name }}</b>@if ($m->user_id == $me->getKey()) <span class="b b-mut">شما</span>@endif
            <div class="small"><code>{{ $m->user?->mobile }}</code></div>
            <div class="small muted">افزوده‌شده توسط: {{ $m->inviter?->name ?? '—' }}</div></td>
        <td>@if ($isOwner)<span class="b b-ok">{{ $wc['owner_label'] }} (صاحب فضا)</span>@else<span class="b b-pri">{{ $wc['owner_label'] }}: {{ $ws->owner?->name }}</span>@endif</td>
        <td style="min-width:230px">
            @if ($locked)<b>{{ $m->role->title }}</b>
            @else
            <form method="post" action="{{ route('sazeh.workspace.members.update', $m->id) }}">@csrf @method('put')<select name="role_id" onchange="this.form.submit()">
                @unless ($roles->contains('id', $m->role_id))<option value="" selected disabled>{{ $m->role->title }}</option>@endunless
                @foreach ($roles as $r)<option value="{{ $r->id }}" @selected($m->role_id == $r->id)>{{ $r->title }}</option>@endforeach</select></form>
            @endif
            <div style="margin-top:4px">@include('sazeh::partials.role-perms', ['role' => $m->role])</div>
            <div class="small muted">پس از ورود: {{ $starts[$m->role->start_route] ?? 'اولین صفحهٔ مجاز منو' }}</div>
        </td>
        <td>{!! $m->status === 'active' ? '<span class="b b-ok">فعال</span>' : '<span class="b b-no">تعلیق</span>' !!}</td>
        @if ($canManage)<td>@unless ($locked)<div class="row">
            <form method="post" action="{{ route('sazeh.workspace.members.update', $m->id) }}">@csrf @method('put')<input type="hidden" name="status" value="{{ $m->status === 'active' ? 'suspended' : 'active' }}"><button class="btn sm">{{ $m->status === 'active' ? 'تعلیق' : 'فعال‌سازی' }}</button></form>
            <form method="post" action="{{ route('sazeh.workspace.members.destroy', $m->id) }}" onsubmit="return confirm('از این فضا حذف شود؟ حساب او باقی می‌ماند.')">@csrf @method('delete')<button class="btn sm dng">حذف</button></form>
        </div>@endunless</td>@endif</tr>
    @endforeach
    </tbody></table></div>
</div>
@if ($canManage)
<div class="card"><h2>افزودن به {{ $wc['members_label'] }}</h2>
    <p class="desc">کاربر جدید زیرمجموعهٔ <b>{{ $wc['owner_label'] }} «{{ $ws->owner?->name }}»</b> ثبت می‌شود، فقط «{{ $ws->name }}» را می‌بیند و فقط به بخش‌هایی دسترسی دارد که نقشش اجازه می‌دهد.</p>
    @if ($roles->isEmpty())
        <div class="alert warn">نقشی برای واگذاری وجود ندارد. {{ config('sazeh.panels.platform.owner_label') }} باید نقش‌های کاربران را تعریف کند.</div>
    @else
    <form method="post" action="{{ route('sazeh.workspace.members.store') }}">@csrf
        @include('sazeh::partials.identity-fields')
        @include('sazeh::partials.role-picker', ['roles' => $roles, 'starts' => $starts])
        <button class="btn pri">افزودن</button>
    </form>
    @endif
</div>
@endif
</div>
@endsection
