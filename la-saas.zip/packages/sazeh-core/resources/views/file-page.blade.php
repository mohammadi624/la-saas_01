@extends('sazeh::layouts.dashboard')
@section('title', $page['title'])
@section('heading', $page['title'])
@section('content')
    @include($page['view'])
@endsection
