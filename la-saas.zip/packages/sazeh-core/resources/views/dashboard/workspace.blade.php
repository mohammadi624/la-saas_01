@extends('sazeh::layouts.dashboard')
@section('heading', 'داشبورد')
@section('content')
<div class="grid g4" style="margin-bottom:16px">
@foreach ($stats as $label => $value)<div class="stat"><b>{{ $value }}</b><span>{{ $label }}</span></div>@endforeach
</div>
<div class="grid g2">
    @php($ows = $sazehCtx->workspace())
    @php($olabel = config('sazeh.panels.workspace.owner_label', 'مالک'))
    <div class="card"><h2>{{ $ows->name }}</h2>
        @if ($sazehCtx->isWorkspaceOwner())
            <p class="desc">شما <b>{{ $olabel }}</b> این فضای کاری هستید و کاربرانی که از بخش «کاربران» اضافه می‌کنید زیرمجموعهٔ شما خواهند بود.</p>
        @else
            <p class="desc">شما با نقش «{{ $sazehCtx->role()->title }}» <b>زیرمجموعهٔ {{ $olabel }} «{{ $ows->owner?->name }}»</b> هستید و فقط به بخش‌هایی از این فضا دسترسی دارید که نقش‌تان اجازه می‌دهد.</p>
            <table><tr><td>{{ $olabel }}</td><td><b>{{ $ows->owner?->name }}</b></td></tr>
            <tr><td>عضو از</td><td>{{ $sazehCtx->membership()?->created_at }}</td></tr>
            <tr><td>افزوده‌شده توسط</td><td>{{ $sazehCtx->membership()?->inviter?->name ?? '—' }}</td></tr></table>
        @endif
    </div>
    @include('sazeh::partials.trace')
</div>
@endsection
