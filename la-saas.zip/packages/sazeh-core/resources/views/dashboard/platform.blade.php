@extends('sazeh::layouts.dashboard')
@section('heading', 'داشبورد مدیریت')
@section('content')
<div class="grid g4" style="margin-bottom:16px">
@foreach ($stats as $label => $value)<div class="stat"><b>{{ is_numeric($value) ? number_format($value) : $value }}</b><span>{{ $label }}</span></div>@endforeach
</div>
<div class="grid g2">
    <div class="card"><h2>خوش آمدید</h2><p class="desc">این داشبورد پایه است. ماژول‌های پروژه ابزارک‌ها و صفحه‌های خودشان را اضافه می‌کنند.</p>
        <ul style="margin:0;padding-right:18px"><li>منوی کناری فقط آیتم‌های نقش شما را نشان می‌دهد.</li><li>منوها از «تنظیمات سیستم › مدیریت منوها» قابل ویرایش‌اند.</li><li>صفحهٔ شروع هر نقش از «نقش‌ها و دسترسی‌ها» تنظیم می‌شود.</li></ul></div>
    @include('sazeh::partials.trace')
</div>
@endsection
