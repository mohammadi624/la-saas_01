<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title', 'ورود') — {{ config('app.name') }}</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css">
@include('sazeh::partials.styles')
</head>
<body>
<div class="auth"><div class="auth-card">
    <div class="brand" style="justify-content:center;border:0;color:var(--ink)"><span class="logo" style="color:#fff">@sazehIcon('shield')</span></div>
    @yield('content')
</div></div>
</body>
</html>
