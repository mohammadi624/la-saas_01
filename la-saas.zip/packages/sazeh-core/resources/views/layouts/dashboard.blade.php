@php
    $panel = $sazehCtx->panel();
    $pcfg = config('sazeh.panels.'.$panel, []);
    $ws = $sazehCtx->workspace();
@endphp
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>@yield('title', 'داشبورد') — {{ config('app.name') }}</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css">
@include('sazeh::partials.styles', ['color' => $pcfg['color'] ?? null, 'sidebar' => $pcfg['sidebar'] ?? null])
@stack('head')
</head>
<body>
<div class="app">
    <aside class="side" id="side">
        <div class="brand"><span class="logo">@sazehIcon($panel === 'workspace' ? 'globe' : 'shield')</span>
            <div>{{ $ws?->name ?? ($pcfg['title'] ?? config('app.name')) }}<small>{{ auth()->user()->name }} · {{ $sazehCtx->role()?->title }}</small>
                @if ($ws && ! $sazehCtx->isWorkspaceOwner())<small>زیرمجموعهٔ {{ $pcfg['owner_label'] ?? 'مالک' }}: {{ $ws->owner?->name }}</small>@endif
            </div></div>
        @if ($sazehMenu)
            @include('sazeh::partials.menu', ['items' => $sazehMenu])
        @else
            <p class="small" style="color:#f3b8bb;padding:8px">هیچ آیتم منویی برای شما فعال نیست.</p>
        @endif
    </aside>
    <div class="main">
        <div class="top">
            <button class="btn hamb" type="button" onclick="document.getElementById('side').classList.toggle('open')" aria-label="منو">@sazehIcon('menu')</button>
            <span class="sp"></span>
            @if ($sazehContexts->count() > 1)
                <form method="post" action="{{ route('sazeh.context.select') }}" class="row">@csrf
                    <span class="small muted">بخش:</span>
                    <select name="context" onchange="this.form.submit()">
                        @foreach ($sazehContexts as $c)<option value="{{ $c['key'] }}" @selected($c['key'] === $sazehCtx->key())>{{ $c['title'] }}</option>@endforeach
                    </select>
                </form>
            @endif
            <span class="btn sm" style="cursor:default">@sazehIcon('users') {{ auth()->user()->name }}</span>
            <form method="post" action="{{ route('sazeh.logout') }}">@csrf<button class="btn sm">@sazehIcon('logout') خروج</button></form>
        </div>
        <div class="content">
            @if ($ws && $ws->status !== 'active')
                <div class="alert {{ $ws->status === 'suspended' ? 'no' : 'warn' }}">
                    {{ ['grace' => 'مهلت پرداخت: اشتراک به‌زودی منقضی می‌شود.', 'read_only' => 'حالت فقط‌خواندنی: مشاهده آزاد است ولی ثبت و ویرایش ممکن نیست.', 'suspended' => 'اشتراک این فضا معلق است؛ فقط صفحات پرداخت باز است.'][$ws->status] ?? '' }}
                </div>
            @endif
            @hasSection('heading')<div class="page-hd"><h1>@yield('heading')</h1></div>@endif
            @include('sazeh::partials.flash')
            @yield('content')
        </div>
    </div>
</div>
@stack('scripts')
</body>
</html>
