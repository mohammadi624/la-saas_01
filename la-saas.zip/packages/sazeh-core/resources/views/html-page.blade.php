@extends('sazeh::layouts.dashboard')
@section('title', $item->title)
@section('content')
<iframe id="sazeh-html-page" title="{{ $item->title }}"
        sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-forms"
        referrerpolicy="no-referrer"
        style="width:100%;min-height:70vh;border:0;border-radius:12px;background:#fff;display:block"
        srcdoc="{{ $page->srcdoc() }}"></iframe>
@push('scripts')
<script>
addEventListener('message', function (e) {
    var f = document.getElementById('sazeh-html-page');
    if (f && e.source === f.contentWindow && e.data && typeof e.data.sazehHeight === 'number') {
        f.style.height = Math.min(Math.max(e.data.sazehHeight, 300), 20000) + 'px';
    }
});
</script>
@endpush
@endsection
