@if (session('success'))<div class="alert ok">{{ session('success') }}</div>@endif
@if (session('info'))<div class="alert info">{{ session('info') }}</div>@endif
@if ($errors->any())<div class="alert no">@foreach ($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif
