{{-- دسترسی‌های یک نقش به‌صورت برچسب --}}
@if (! $role)
    <span class="muted small">—</span>
@elseif ($role->grants_all)
    <span class="b b-ok">همهٔ دسترسی‌های این پنل</span>
@elseif ($role->permissions->isEmpty())
    <span class="b b-mut">فقط داشبورد و حساب کاربری</span>
@else
    <span class="perms">@foreach ($role->permissions as $p)<span class="b b-mut">{{ $p->label }}</span> @endforeach</span>
@endif
