{{-- انتخاب نقش + نمایش زندهٔ دسترسی‌ها و صفحهٔ شروع نقش انتخاب‌شده --}}
@php($pickerId = 'rp'.uniqid())
<label class="f"><span>نقش</span>
    <select name="role_id" required id="{{ $pickerId }}" onchange="sazehRolePreview('{{ $pickerId }}')">
        @foreach ($roles as $r)
            <option value="{{ $r->id }}"
                data-all="{{ $r->grants_all ? 1 : 0 }}"
                data-start="{{ $starts[$r->start_route] ?? 'اولین صفحهٔ مجاز منو' }}"
                data-perms='@json($r->permissions->pluck('label')->values())'>{{ $r->title }}</option>
        @endforeach
    </select>
</label>
<div class="role-preview" id="{{ $pickerId }}-preview"></div>
@once
@push('scripts')
<script>
function sazehRolePreview(id) {
    var sel = document.getElementById(id), box = document.getElementById(id + '-preview');
    if (!sel || !box) return;
    var o = sel.options[sel.selectedIndex], perms = [];
    try { perms = JSON.parse(o.getAttribute('data-perms') || '[]'); } catch (e) {}
    var html = '<div class="small muted" style="margin-bottom:4px">دسترسی‌های این نقش:</div>';
    if (o.getAttribute('data-all') === '1') html += '<span class="b b-ok">همهٔ دسترسی‌های این پنل</span>';
    else if (!perms.length) html += '<span class="b b-mut">فقط داشبورد و حساب کاربری</span>';
    else perms.forEach(function (p) { var s = document.createElement('span'); s.className = 'b b-mut'; s.textContent = p; html += s.outerHTML + ' '; });
    var st = document.createElement('b'); st.textContent = o.getAttribute('data-start') || '';
    html += '<div class="small muted" style="margin-top:6px">پس از ورود به این صفحه می‌رود: ' + st.outerHTML + '</div>';
    box.innerHTML = html;
}
document.querySelectorAll('.role-preview').forEach(function (b) { sazehRolePreview(b.id.replace('-preview', '')); });
</script>
@endpush
@endonce
