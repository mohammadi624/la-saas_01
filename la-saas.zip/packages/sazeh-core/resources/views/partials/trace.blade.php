<div class="card"><h2>چرا این صفحه پس از ورود باز شد؟</h2><p class="desc">ترتیب انتخاب صفحهٔ شروع بر اساس نقش شما:</p>
<ol class="trace" style="margin:0;padding-right:18px">
@foreach ($trace as $t)
    <li class="{{ $t['status'] }}"><b>{{ $t['label'] }}</b>@if ($t['target']) <code>{{ $t['target'] }}</code>@endif — {{ $t['message'] }}</li>
@endforeach
</ol></div>
