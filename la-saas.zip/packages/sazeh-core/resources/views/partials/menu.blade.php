@foreach ($items as $item)
    @if ($item['type'] === 'group')
        <details class="mg" open>
            <summary>@sazehIcon($item['icon']) <span>{{ $item['title'] }}</span></summary>
            <div class="sub">@include('sazeh::partials.menu', ['items' => $item['children']])</div>
        </details>
    @elseif ($item['type'] === 'html')
        @php($hr = 'sazeh.'.($item['panel'] ?? 'workspace').'.html')
        <a class="mi {{ request()->routeIs($hr) && (int) request()->route('item') === $item['id'] ? 'on' : '' }}" href="{{ route($hr, $item['id']) }}">@sazehIcon($item['icon']) <span>{{ $item['title'] }}</span></a>
    @elseif ($item['type'] === 'external')
        <a class="mi" href="{{ $item['url'] }}" target="_blank" rel="noopener noreferrer">@sazehIcon($item['icon']) <span>{{ $item['title'] }}</span> @sazehIcon('external')</a>
    @else
        @php($active = request()->routeIs($item['route']) || request()->routeIs($item['route'].'.*'))
        <a class="mi {{ $active ? 'on' : '' }}" href="{{ route($item['route']) }}">@sazehIcon($item['icon']) <span>{{ $item['title'] }}</span></a>
    @endif
@endforeach
