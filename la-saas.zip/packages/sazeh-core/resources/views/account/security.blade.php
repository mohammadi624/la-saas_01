@extends('sazeh::layouts.dashboard')
@section('heading', 'امنیت حساب')
@section('content')
<div class="grid g2">
<div class="card"><h2>تغییر رمز عبور</h2><p class="desc">پس از تغییر رمز، نشست‌های دیگر شما باطل می‌شوند.</p>
<form method="post" action="{{ route('sazeh.account.password') }}">@csrf
    <label class="f"><span>رمز فعلی</span><input type="password" name="current_password" dir="ltr" required></label>
    <label class="f"><span>رمز جدید (حداقل {{ config('sazeh.password_min') }} نویسه)</span><input type="password" name="password" dir="ltr" required></label>
    <label class="f"><span>تکرار رمز جدید</span><input type="password" name="password_confirmation" dir="ltr" required></label>
    <button class="btn pri">ذخیره</button>
</form></div>
<div class="card"><h2>اطلاعات ورود</h2><table>
    <tr><td>موبایل</td><td><code>{{ $user->mobile ?? '—' }}</code></td></tr>
    <tr><td>ایمیل</td><td><code>{{ $user->email ?? '—' }}</code></td></tr>
    <tr><td>آخرین ورود</td><td>{{ $user->last_login_at ?? '—' }}</td></tr>
    <tr><td>IP آخرین ورود</td><td><code>{{ $user->last_login_ip ?? '—' }}</code></td></tr>
</table></div>
</div>
@endsection
