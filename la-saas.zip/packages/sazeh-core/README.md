# سازه (sazeh/core) — هستهٔ قابل استفادهٔ مجدد برای پروژه‌های Laravel

یک هستهٔ مشترک برای هر سایتی که پنل مدیریت و کاربر دارد: سایت شرکتی، سایت عمومی با ثبت‌نام آزاد، فروشگاه، کلینیک، آموزشگاه یا پلتفرم SaaS با فروش اشتراک. فروش اشتراک و چندمستاجری **اختیاری** است.

## چه چیزی در هسته هست

| بخش | توضیح |
|---|---|
| ورود | یک صفحهٔ ورود برای همه؛ رمز عبور (ایمیل/موبایل/نام کاربری) یا کد پیامکی؛ نرمال‌سازی ارقام فارسی و قالب‌های `+98`؛ پیام خطای یکسان؛ قفل پس از ۵ تلاش؛ OTP هش‌شده، ۱۲۰ ثانیه، یک‌بارمصرف |
| ثبت‌نام عمومی | قابل روشن/خاموش؛ ثبت‌نام‌کننده یا عضو فضای پیش‌فرض سایت می‌شود یا فضای کاری خودش را می‌گیرد |
| داشبورد واحد | یک قالب، دو مجموعه‌منو: **پلتفرم** (مالک سایت و تیمش، آدرس `/admin`) و **فضای کاری** (خریدار/کاربر، آدرس `/panel`) |
| نقش و مجوز | نقش‌های قالب برای هر پنل، ماتریس مجوز، **صفحهٔ شروع هر نقش**، ضد ارتقای مجوز |
| زیرمجموعه‌ها | کاربری که مالک سایت اضافه می‌کند ← تیم پلتفرم. کاربری که خریدار اضافه می‌کند ← عضو فضای کاری همان خریدار |
| منوساز | ساخت آیتم و زیرمنو تا ۳ سطح، انتخاب صفحه + تیک نقش = دسترسی، کشف خودکار صفحه‌های جدید، نشان «جدید» و «فایل موجود نیست»، حذف و بازیابی |
| جداسازی داده | Trait `BelongsToWorkspace` برای مدل‌های ماژول‌ها؛ رکورد فضای دیگر = ۴۰۴ |
| اشتراک (اختیاری) | پلن و قابلیت، ظرفیت کاربران، وضعیت‌های مهلت/فقط‌خواندنی/معلق |
| ماژول | هر قابلیت جدید (وبلاگ، فروشگاه، نوبت‌دهی…) یک کلاس ماژول است که مجوز، صفحه، منو و نقشش را به هسته معرفی می‌کند |
| لاگ امنیتی | ورود، خطا، تغییر نقش، منو، عضویت — بدون ذخیرهٔ رمز و کد |

## نصب روی یک پروژهٔ Laravel 12

```bash
# 1) پوشهٔ پکیج را در پروژه قرار دهید:  packages/sazeh-core
# 2) در composer.json پروژه:
#    "repositories": [{ "type": "path", "url": "packages/sazeh-core" }]
composer require sazeh/core:@dev
```

**3) مدل User:**
```php
use Sazeh\Core\Concerns\HasSazehAccess;

class User extends Authenticatable
{
    use HasSazehAccess;
    // platform_role_id و status را در $fillable قرار ندهید
}
```

**4) هدایت پیش‌فرض Laravel** در `bootstrap/app.php`:
```php
->withMiddleware(function (Middleware $middleware) {
    $middleware->redirectGuestsTo(fn () => route('sazeh.login'));
    $middleware->redirectUsersTo(fn () => route('sazeh.home'));
    $middleware->web(append: [\Illuminate\Session\Middleware\AuthenticateSession::class]); // برای باطل‌کردن نشست‌های دیگر
})
```

**5) تنظیمات در `.env`** (جدول سناریوها در ادامه):
```env
SAZEH_TENANCY=single
SAZEH_BILLING=false
SAZEH_REGISTRATION=disabled
SAZEH_SMS_DRIVER=log
```

**6) اجرا:**
```bash
php artisan migrate
php artisan sazeh:install          # مدیر کل + فضای پیش‌فرض (موبایل و رمز را می‌پرسد)
php artisan vendor:publish --tag=sazeh-config   # اختیاری
```
سپس به `/login` بروید.

> جداول با پیشوند `core_` ساخته می‌شوند و با جداول موجود (مثل `roles`) تداخلی ندارند. روی `users` فقط ستون‌های `mobile`، `username`، `status`، `platform_role_id`، `last_login_at`، `last_login_ip` اضافه می‌شود (اگر وجود نداشته باشند) و `email` اختیاری می‌شود. هیچ ستونی حذف یا تغییر نام داده نمی‌شود.

## سناریوها فقط با تنظیمات

| نوع سایت | `TENANCY` | `BILLING` | `REGISTRATION` | `ON_REGISTER` |
|---|---|---|---|---|
| سایت شرکتی (فقط مدیر و کارمندان) | single | false | disabled | — |
| سایت عمومی / انجمن / آموزشی (همه ثبت‌نام می‌کنند) | single | false | public | default_workspace |
| فروش سایت/خدمات به خریداران (مدیر خریدار را می‌سازد) | multi | true یا false | disabled | — |
| SaaS خودخدمت (هر کس ثبت‌نام کند فضای خودش را می‌گیرد) | multi | true | public | own_workspace |

## تغییر نام نقش مالک فضای کاری (مثلاً subscriber)

```env
SAZEH_OWNER_ROLE_KEY=subscriber
SAZEH_OWNER_ROLE_TITLE="خریدار اشتراک"
```
- **نصب تازه:** فقط همین دو خط را قبل از `sazeh:install` بگذارید.
- **اگر قبلاً نصب کرده‌اید:** اول ردیف موجود را به‌روز کنید، بعد `.env` را تغییر دهید و `php artisan config:clear` بزنید. ترتیب مهم است؛ وگرنه `sazeh:sync` یک نقش مالک دوم می‌سازد.
```sql
UPDATE core_roles SET `key` = 'subscriber', title = 'خریدار اشتراک'
WHERE panel = 'workspace' AND workspace_id IS NULL AND `key` = 'owner';
```

## برچسب‌های پنل‌ها (چه کسی صاحب کدام کاربران است)

```env
SAZEH_PLATFORM_TITLE="پنل مالک سایت"
SAZEH_PLATFORM_OWNER_LABEL="مالک سایت"
SAZEH_PLATFORM_MEMBERS_LABEL="کاربران مالک سایت"
SAZEH_WORKSPACE_TITLE="پنل خریدار اشتراک"
SAZEH_WORKSPACE_OWNER_LABEL="خریدار اشتراک"
SAZEH_WORKSPACE_MEMBERS_LABEL="کاربران خریدار اشتراک"
```
صفحه‌های افزودن کاربر با همین برچسب‌ها نشان می‌دهند کاربر زیرمجموعهٔ چه کسی است، و هنگام انتخاب نقش، دسترسی‌ها و صفحهٔ شروع آن نقش نمایش داده می‌شود.

## مفاهیم اصلی

**دو پنل، یک داشبورد.** پنل کاربر از نقشش تعیین می‌شود:
- `users.platform_role_id` پر باشد ← عضو تیم پلتفرم ← منوی پلتفرم
- ردیف در `core_memberships` ← عضو یک فضای کاری ← منوی فضای کاری
- اگر کسی چند بخش داشته باشد، بعد از ورود انتخاب می‌کند و از نوار بالا تعویض می‌کند.

**چه کسی کاربر می‌سازد، کاربر زیرمجموعهٔ کجاست:**

| سازنده | صفحه | نتیجه |
|---|---|---|
| مدیر پلتفرم | `/admin/users` | عضو تیم پلتفرم با نقش پلتفرم |
| مدیر پلتفرم | `/admin/workspaces` | فضای کاری جدید + مالک آن (خریدار) |
| مالک/مدیر فضا | `/panel/members` | عضو همان فضا؛ فضای مقصد هرگز از فرم پذیرفته نمی‌شود |
| ثبت‌نام عمومی | `/register` | عضو فضای پیش‌فرض یا مالک فضای جدید |

هویت سراسری است: اگر موبایل یا ایمیل قبلاً حساب داشته باشد، حساب تکراری ساخته نمی‌شود و همان شخص اضافه می‌شود.

**صفحهٔ شروع پس از ورود:** صفحهٔ درخواستی پیش از ورود (اگر مجاز و امن باشد) ← صفحهٔ شروع نقش ← اولین آیتم مجاز منو ← صفحهٔ امنیت حساب. صفحهٔ شروع هر نقش از «نقش‌ها و دسترسی‌ها» تنظیم می‌شود.

**ترتیب تصمیم دسترسی** (`AccessResolver`، تنها نقطهٔ تصمیم): هویت فعال ← عضویت فعال ← اشتراک معلق (فقط مالک و فقط پرداخت) ← صفحهٔ بدون مجوز ← مجوز همان پنل ← فقط‌خواندنی ← قابلیت پلن ← نقش ← منع پیش‌فرض.

## صفحهٔ HTML بدون کدنویسی (از منوساز)

۱) «مدیریت منوها» ← تب پنل موردنظر ← «+ آیتم»
۲) نوع: **«صفحهٔ HTML (انتخاب فایل)»** ← فایل `.html` را انتخاب کنید ← عنوان و آیکون ← فعال ← ذخیره

- آدرس صفحه خودکار ساخته می‌شود: `/admin/h/{شماره}` یا `/panel/h/{شماره}`.
- دسترسی همان تنظیمات آیتم منو است (فعال بودن، «فقط برای این نقش‌ها»، مجوز اضافه) — با آدرس مستقیم هم دور زده نمی‌شود.
- برای به‌روزرسانی، فایل جدید را روی همان آیتم انتخاب کنید.
- محتوا در `iframe` ایزوله (`sandbox` بدون `allow-same-origin`) نمایش داده می‌شود: کد PHP/Blade هرگز اجرا نمی‌شود و اسکریپت داخل فایل به نشست و کوکی کاربران دسترسی ندارد. به همین دلیل صفحهٔ HTML نام کاربر یا دادهٔ دیتابیس را نمی‌بیند؛ برای صفحهٔ پویا از «صفحه‌های فایلی» استفاده کنید.
- فقط `.html`/`.htm` تا ۲ مگابایت؛ فایل‌های فارسی قدیمی (Windows-1256) خودکار به UTF-8 تبدیل می‌شوند.

## ساخت صفحه‌های جدید (صفحه‌های فایلی) — ساده‌ترین راه

هر فایل Blade در `resources/views/pages/{platform|workspace}/` خودکار یک صفحهٔ داشبورد می‌شود:

```cmd
php artisan sazeh:page workspace reports/sales "Sales Report" --icon=chart
```
| چه چیزی ساخته می‌شود | مقدار |
|---|---|
| فایل | `resources/views/pages/workspace/reports/sales.blade.php` |
| آدرس | `/panel/p/reports/sales` |
| مجوز (در ماتریس نقش‌ها) | `صفحهٔ «…»` با کلید `page.workspace.reports.sales` |
| آیتم منو | در منوساز، **غیرفعال**؛ فعال کنید، جابه‌جا کنید یا نام فارسی بدهید |

سرآیند اختیاری فایل:
```blade
{{-- title: گزارش فروش --}}
{{-- icon: chart --}}
{{-- access: all --}}   {{-- همهٔ نقش‌های این پنل، بدون مجوز جدا --}}
{{-- sort: 30 --}}
```
- محتوای فایل فقط بدنهٔ صفحه است؛ قالب داشبورد، منو و کنترل دسترسی خودکار اعمال می‌شود. `$sazehCtx` (کاربر، نقش، فضای کاری) در دسترس است.
- فایل را دستی ساختید؟ کافی است «مدیریت منوها» را باز کنید؛ صفحه خودکار پیدا می‌شود (نیازی به `sazeh:sync` نیست). اگر از `php artisan route:cache` استفاده می‌کنید، بعد از افزودن فایل آن را دوباره اجرا کنید.
- **صفحهٔ فایلی بدون آیتم منوی فعال بسته است**، حتی برای کسی که مجوزش را دارد. برای خاموش کردن این قاعده: `SAZEH_PAGES_REQUIRE_MENU=false`.
- نام فایل فقط حروف کوچک لاتین، عدد و خط تیره. فایل‌هایی که با `_` شروع شوند صفحه نیستند (برای partial).
- صفحه‌ای که فرم ذخیره‌سازی، جدول دیتابیس یا Controller لازم دارد را به‌صورت **ماژول** بسازید (بخش بعد).

## دسترسی از منوساز (بدون رفتن به ماتریس نقش‌ها)

۱. در «مدیریت منوها» → «صفحه‌های بدون منو»، کنار صفحه «افزودن به منو» را بزنید (یا صفحهٔ جدیدی که با نشان **جدید** آمده را انتخاب کنید).
۲. در بخش «چه نقش‌هایی دسترسی دارند؟» نقش‌ها را تیک بزنید.
۳. «فعال در منو» را روشن کنید و ذخیره کنید.

| مقصد | معنی تیک |
|---|---|
| صفحه‌ای که مجوز دارد + کاربر با `roles.manage` | مجوز صفحه به نقش‌های تیک‌خورده **داده** و از بقیه **گرفته** می‌شود (همان ماتریس نقش‌ها، از مسیر کوتاه‌تر) |
| صفحه‌ای که مجوزش در جای دیگری هم استفاده می‌شود | فقط داده می‌شود؛ گرفتن از ماتریس نقش‌ها |
| صفحهٔ بدون مجوز، HTML، لینک خارجی | فقط تعیین می‌کند چه نقش‌هایی ببینند (هیچ تیک = همه) |
| کاربر بدون `roles.manage` | فقط نمایش محدود می‌شود؛ مجوزی داده نمی‌شود (جلوگیری از افزایش دسترسی) |

نقش‌های «همهٔ دسترسی‌ها» (مالک سایت، خریدار اشتراک) همیشه تیک‌خورده و غیرقابل تغییرند. هر تغییر در لاگ امنیتی با عنوان `menu.access` ثبت می‌شود.

## افزودن یک ماژول جدید

نمونهٔ کامل در `examples/Blog` است (مدل، Migration، Route، Controller، View). خلاصه:

```php
class BlogModule extends \Sazeh\Core\Modules\Module
{
    public function key(): string { return 'blog'; }
    public function permissions(): array { return [['key' => 'posts.manage', 'panel' => 'workspace', 'label' => 'مدیریت مطالب', 'is_write' => true]]; }
    public function pages(): array { return [['route' => 'blog.posts', 'panel' => 'workspace', 'title' => 'مطالب', 'permission' => 'posts.view']]; }
    public function menu(): array { return [['key' => 'w.blog', 'panel' => 'workspace', 'title' => 'وبلاگ', 'icon' => 'edit', 'route' => 'blog.posts']]; }
    public function routes(): ?string { return __DIR__.'/routes.php'; }
    public function views(): ?string { return __DIR__.'/views'; }
}
```
سپس در `config/sazeh.php` به `modules` اضافه کنید و `php artisan sazeh:sync` بزنید. `sazeh:sync` تکرارپذیر است و تغییراتی که مدیر در منو و نقش‌ها داده را بازنویسی نمی‌کند.

**قرارداد Routeها:**
- صفحه (GET): `->middleware('sazeh')` — نام Route باید در `pages()` ماژول ثبت شده باشد.
- عملیات (POST/PUT/DELETE): `->middleware(['sazeh.context', 'sazeh.can:posts.manage'])`
- در Blade و کد: `@can('posts.manage')` و `$user->can('posts.manage')` مستقیم کار می‌کند.
- مدل‌هایی که دادهٔ هر فضاست: `use BelongsToWorkspace;` و `workspace_id` را در `$fillable` نگذارید.

**درگاه پیامک واقعی:** کلاسی که `Sazeh\Core\Sms\SmsGateway` را پیاده می‌کند بسازید و نام کامل آن را در `SAZEH_SMS_DRIVER` بگذارید.

## تست‌ها

```bash
php tests/Pure/run.php            # منطق خالص (بدون Laravel) — ۳۸ تست
composer install && vendor/bin/phpunit   # تست‌های Feature با Orchestra Testbench (روی SQLite در حافظه)
```
تست‌های Feature سناریوهای اصلی را پوشش می‌دهند: ورود با ارقام فارسی و هدایت به صفحهٔ نقش، پیام خطای یکسان و قفل، OTP یک‌بارمصرف، افزودن کاربر در دو محدوده، ضد ارتقای مجوز، جداسازی فضاها (۴۰۴)، ظرفیت، اشتراک معلق، غیرفعال‌شدن هویت، ثبت‌نام عمومی، Open Redirect، منوی غیرفعال و صفحهٔ شروع نقش.

## ساختار

```
config/sazeh.php                 تنظیمات
database/migrations/             جداول core_*
routes/web.php                   Routeهای هسته
resources/views/                 قالب داشبورد واحد، ورود، صفحه‌های مدیریت
src/Access/                      AccessResolver (خالص)، Gatekeeper
src/Actions/                     CreatePlatformUser، CreateWorkspace، AddWorkspaceMember، ChangeMembership، RegisterUser
src/Auth/                        StartPage، OtpService، StartPageResolver (خالص)
src/Menu/                        MenuTree (خالص)، MenuService
src/Modules/                     Module، ModuleRegistry، CoreModule، ModuleSynchronizer
src/Tenancy/                     CurrentContext، BelongsToWorkspace
src/Billing/                     EntitlementService
src/Http/                        Controllerها و Middlewareها
examples/Blog/                   نمونهٔ ماژول
tests/                           تست‌های خالص و Feature
```

## محدودیت‌های نسخهٔ ۱ و نقشهٔ راه

- ورود دومرحله‌ای (TOTP)، دعوت‌نامه با لینک، و انتقال مالکیت هنوز پیاده نشده‌اند؛ جایشان در طراحی باز است.
- رابط مدیریت پلن‌ها و تنظیمات (جدول `core_settings`) و نقش‌های اختصاصی هر فضا در نسخهٔ بعد؛ فعلاً پلن‌ها از دیتابیس/Seeder تعریف می‌شوند.
- مرتب‌سازی منو با دکمه است؛ کشیدن‌ورها‌کردن در نسخهٔ بعد.
- صفحه‌ساز بصری به‌صورت یک ماژول جدا روی همین هسته ساخته می‌شود.
