<?php

namespace App\Modules\Blog;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class PostController extends Controller
{
    public function index()
    {
        return view('blog::index', ['posts' => Post::latest()->paginate(20)]);
    }

    public function store(Request $request)
    {
        Post::create($request->validate(['title' => 'required|string|max:200', 'body' => 'nullable|string']));

        return back()->with('success', 'مطلب ذخیره شد.');
    }

    public function destroy(Post $post) // پست فضای دیگر ← 404 به‌خاطر Global Scope
    {
        $post->delete();

        return back()->with('success', 'حذف شد.');
    }
}
