<?php

use App\Modules\Blog\PostController;
use Illuminate\Support\Facades\Route;

Route::prefix(config('sazeh.panels.workspace.prefix', 'panel').'/blog')->name('blog.')->group(function () {
    Route::get('/', [PostController::class, 'index'])->middleware('sazeh')->name('posts');                       // صفحه
    Route::middleware(['sazeh.context', 'sazeh.can:posts.manage'])->group(function () {                        // عملیات
        Route::post('/', [PostController::class, 'store'])->name('posts.store');
        Route::delete('/{post}', [PostController::class, 'destroy'])->name('posts.destroy');
    });
});
