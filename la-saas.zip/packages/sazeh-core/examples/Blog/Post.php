<?php

namespace App\Modules\Blog;

use Illuminate\Database\Eloquent\Model;
use Sazeh\Core\Tenancy\BelongsToWorkspace;

/** دادهٔ هر فضا جداست: Query خودکار محدود به فضای جاری و workspace_id خودکار پر می‌شود */
class Post extends Model
{
    use BelongsToWorkspace;

    protected $table = 'blog_posts';

    protected $fillable = ['title', 'body']; // workspace_id عمداً fillable نیست
}
