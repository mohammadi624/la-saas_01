@extends('sazeh::layouts.dashboard')
@section('heading', 'مطالب')
@section('content')
<div class="grid g75">
<div class="card"><h2>مطالب {{ $sazehCtx->workspace()->name }}</h2>
    <div class="tw"><table><thead><tr><th>عنوان</th><th>تاریخ</th><th></th></tr></thead><tbody>
    @forelse ($posts as $p)
        <tr><td>{{ $p->title }}</td><td class="small">{{ $p->created_at }}</td>
        <td>@can('posts.manage')<form method="post" action="{{ route('blog.posts.destroy', $p) }}">@csrf @method('delete')<button class="btn sm dng">حذف</button></form>@endcan</td></tr>
    @empty
        <tr><td colspan="3" class="muted">هنوز مطلبی نیست.</td></tr>
    @endforelse
    </tbody></table></div>
</div>
@can('posts.manage')
<div class="card"><h2>مطلب جدید</h2>
<form method="post" action="{{ route('blog.posts.store') }}">@csrf
    <label class="f"><span>عنوان</span><input type="text" name="title" required></label>
    <label class="f"><span>متن</span><textarea name="body" rows="6" style="width:100%"></textarea></label>
    <button class="btn pri">ذخیره</button>
</form></div>
@endcan
</div>
@endsection
