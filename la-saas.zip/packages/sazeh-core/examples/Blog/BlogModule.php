<?php

namespace App\Modules\Blog;

use Sazeh\Core\Modules\Module;

/**
 * نمونهٔ کامل یک ماژول. این پوشه را در app/Modules/Blog کپی کنید، سپس:
 *  1) در config/sazeh.php → 'modules' => [..., \App\Modules\Blog\BlogModule::class]
 *  2) php artisan migrate --path=app/Modules/Blog/database
 *  3) php artisan sazeh:sync
 * مجوزها، صفحه‌ها و منوی ماژول خودکار در منوساز و ماتریس نقش‌ها ظاهر می‌شوند.
 */
class BlogModule extends Module
{
    public function key(): string
    {
        return 'blog';
    }

    public function title(): string
    {
        return 'وبلاگ';
    }

    public function permissions(): array
    {
        return [
            ['key' => 'posts.view', 'panel' => 'workspace', 'label' => 'مشاهدهٔ مطالب', 'feature' => 'blog'],
            ['key' => 'posts.manage', 'panel' => 'workspace', 'label' => 'نوشتن و ویرایش مطالب', 'is_write' => true, 'feature' => 'blog'],
        ];
    }

    public function pages(): array
    {
        return [
            ['route' => 'blog.posts', 'panel' => 'workspace', 'title' => 'مطالب', 'permission' => 'posts.view'],
        ];
    }

    public function menu(): array
    {
        return [
            ['key' => 'w.blog', 'panel' => 'workspace', 'title' => 'وبلاگ', 'icon' => 'edit', 'route' => 'blog.posts', 'sort' => 20],
        ];
    }

    public function roles(): array
    {
        // نقش جدید برای همهٔ فضاها (اختیاری)
        return [
            ['key' => 'writer', 'panel' => 'workspace', 'title' => 'نویسنده', 'start' => 'blog.posts', 'permissions' => ['posts.view', 'posts.manage']],
        ];
    }

    public function features(): array
    {
        return ['blog' => 'وبلاگ'];
    }

    public function views(): ?string
    {
        return __DIR__.'/views';
    }

    public function routes(): ?string
    {
        return __DIR__.'/routes.php';
    }
}
