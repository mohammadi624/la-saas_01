<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * تکمیل جدول users بر اساس ساختار پروژهٔ قبلی — فقط افزایشی.
 *
 * عمداً اضافه نشده‌اند (جایگزین در هسته دارند):
 *   role_id    → users.platform_role_id  و  core_memberships.role_id
 *   parent_id  → core_memberships (زیرمجموعهٔ کدام خریدار)
 *   is_active  → users.status  (یک منبع حقیقت)
 *   expires_at → متعلق به اشتراک/فضای کاری است، نه کاربر
 *   token      → توکن‌ها جدول جدا و هش‌شده دارند (OTP، بازیابی رمز)
 *
 * اطلاعات بانکی و secret دو مرحله‌ای رمزنگاری‌شده ذخیره می‌شوند (cast encrypted) ← ستون text.
 */
return new class extends Migration
{
    public function up(): void
    {
        $add = function (string $col, callable $def) {
            if (! Schema::hasColumn('users', $col)) {
                Schema::table('users', fn (Blueprint $t) => $def($t));
            }
        };

        // معرفی (Referral)
        $add('referral_code', fn ($t) => $t->string('referral_code', 12)->nullable()->unique());
        $add('referred_by_user_id', fn ($t) => $t->foreignId('referred_by_user_id')->nullable()->constrained('users')->nullOnDelete());
        $add('referral_balance', fn ($t) => $t->decimal('referral_balance', 15, 2)->default(0));
        $add('referral_earned_total', fn ($t) => $t->decimal('referral_earned_total', 15, 2)->default(0));

        // امنیت
        $add('mobile_verified_at', fn ($t) => $t->timestamp('mobile_verified_at')->nullable());
        $add('two_factor_enabled', fn ($t) => $t->boolean('two_factor_enabled')->default(false));
        $add('two_factor_secret', fn ($t) => $t->text('two_factor_secret')->nullable());
        $add('password_changed_at', fn ($t) => $t->timestamp('password_changed_at')->nullable());

        // اطلاعات هویتی
        $add('first_name', fn ($t) => $t->string('first_name', 100)->nullable());
        $add('last_name', fn ($t) => $t->string('last_name', 100)->nullable());
        $add('father_name', fn ($t) => $t->string('father_name', 100)->nullable());
        $add('national_code', fn ($t) => $t->string('national_code', 10)->nullable()->unique());
        $add('birth_date', fn ($t) => $t->date('birth_date')->nullable());
        $add('gender', fn ($t) => $t->string('gender', 10)->nullable());

        // تماس و نشانی
        $add('phone', fn ($t) => $t->string('phone', 11)->nullable());
        $add('country', fn ($t) => $t->string('country', 100)->nullable());
        $add('province', fn ($t) => $t->string('province', 100)->nullable());
        $add('city', fn ($t) => $t->string('city', 100)->nullable());
        $add('postal_code', fn ($t) => $t->string('postal_code', 10)->nullable());
        $add('address', fn ($t) => $t->string('address', 500)->nullable());

        // بانکی (رمزنگاری‌شده)
        $add('bank_name', fn ($t) => $t->string('bank_name', 100)->nullable());
        $add('account_holder', fn ($t) => $t->string('account_holder', 100)->nullable());
        $add('account_number', fn ($t) => $t->text('account_number')->nullable());
        $add('card_number', fn ($t) => $t->text('card_number')->nullable());
        $add('sheba_number', fn ($t) => $t->text('sheba_number')->nullable());

        // مدیریتی
        $add('notes', fn ($t) => $t->text('notes')->nullable());
        $add('meta', fn ($t) => $t->json('meta')->nullable());
        $add('deleted_at', fn ($t) => $t->softDeletes());
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $t) {
            if (Schema::hasColumn('users', 'referred_by_user_id')) {
                $t->dropConstrainedForeignId('referred_by_user_id');
            }
        });
        $cols = ['referral_code', 'referral_balance', 'referral_earned_total', 'mobile_verified_at', 'two_factor_enabled',
            'two_factor_secret', 'password_changed_at', 'first_name', 'last_name', 'father_name', 'national_code', 'birth_date',
            'gender', 'phone', 'country', 'province', 'city', 'postal_code', 'address', 'bank_name', 'account_holder',
            'account_number', 'card_number', 'sheba_number', 'notes', 'meta', 'deleted_at'];
        foreach ($cols as $c) {
            if (Schema::hasColumn('users', $c)) {
                if (in_array($c, ['referral_code', 'national_code'], true)) {
                    Schema::table('users', fn (Blueprint $t) => $t->dropUnique('users_'.$c.'_unique'));
                }
                Schema::table('users', fn (Blueprint $t) => $t->dropColumn($c));
            }
        }
    }
};
